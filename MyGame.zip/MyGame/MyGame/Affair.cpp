#include "Affair.h"
#include<iostream>
#include <tchar.h>
using namespace std;
float f(float x, float y, float z) {
	float a = x * x + 9.0f / 4.0f * y * y + z * z - 1;
	return a * a * a - x * x * z * z * z - 9.0f / 80.0f * y * y * z * z * z;
}

float h(float x, float z) {
	for (float y = 1.0f; y >= 0.0f; y -= 0.001f)
		if (f(x, y, z) <= 0.0f)
			return y;
	return 0.0f;
}
void AffairChose(int affairId)
{
	switch (affairId)
	{
	case 1:
		Affair1();
		break;
	case 2:
		Affair2();
		break;
	case 3:
		Affair3();
		break;
	case 4:
		Affair4();
		break;
	case 5:
		Affair5();

		break;
	case 6:
		Affair6();

		break;
	case 7:
		Affair7();

		break;
	case 8:
		Affair8();

		break;
	case 9:
		Affair9();

		break;
	case 10:
		Affair10();

		break;
	case 11:
		Affair11();

		break;
	case 12:
		Affair12();

		break;
	case 13:
		Affair7();

		break;
	}
}

void Affair1()
{
	
	PaintTalkBackground();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	//RenewTheScreen();
	SetConsolePosition(20, 32);
	cout << "hello";
	GReadAndWrite();
	int t = 0;
	//Sleep(100);
	if (GetAsyncKeyState(VK_RETURN))//���ڵ�����һ�εİ���enter
	{

	}
	while (true)
	{
		Sleep(100);
		if (GetAsyncKeyState(VK_SPACE))
		{
			t = 1;
			break;
		}
		else if (GetAsyncKeyState(VK_RETURN))
		{
			SetConsolePosition(20, 32);
			cout << "hello SB";
			GReadAndWrite();
			break;
		}
	}
	while (true)
	{
		if (t == 1)break;
		else
		{
			Sleep(100);
			if (GetAsyncKeyState(VK_SPACE))
			{
				t = 1;
				break;
			}
			else if (GetAsyncKeyState(VK_RETURN))
			{
				SetConsolePosition(20, 32);
				cout << "hello SB ffff";
				GReadAndWrite();
				break;
			}
		}

	}
	while (true)
	{
			if (GetAsyncKeyState(VK_RETURN))
			{
				break;
			}
	}
	GSetConsoleAttribute(128);
}
void Affair2()
{
	SetConsolePosition(10, 20);
	cout << "hahahahahahahha";
}
void Affair3()
{
	SetConsolePosition(10, 20);
	cout << "hahahahahahahha";
}
void Affair4()
{

}
void Affair5()
{

}
void Affair6()
{

}
void Affair7()
{

}
//level 1ͨ��
void Affair8()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "�����˷�ӡ�ı߽� ����������һ���ն��ɽ�� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(200);
	GSetConsoleAttribute(128);
}
//level 2 ͨ��
void Affair9()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "����֪�����ֻ�ʯ�Ĵ��� ��Ҳ��ʼ���ӡ�ۼ� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(200);
	GSetConsoleAttribute(128);
}
//level 3 ͨ��
void Affair10()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "ħͷ�ķ�ӡ���쵽�� ��Ȼ���ܱߵĹ���ҲԽ��Խ�� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(200);
	GSetConsoleAttribute(128);
}
//level 4 ͨ��
void Affair11()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "�ɹ���Ƭ��հ� ���㽫�ҵ�ħ�������� ����˵��������������������޺Ͷ�� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(200);
	GSetConsoleAttribute(128);
}
//level 5 ͨ��
void Affair12()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "���� ����������ħ���ķ�ӡ� ����˵ֻҪ��ħ�����ķ�ӡ�� �����ܷ�ӡħ��  ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(200);
	GSetConsoleAttribute(128);
}
//level 6 ͨ��
void Affair13()
{
	HANDLE o = GetStdHandle(STD_OUTPUT_HANDLE);
	_TCHAR buffer[25][80] = { _T(' ') };
	_TCHAR ramp[] = _T(".:-=+*#%*");
	Man mm;
	int x = 80, y = 30;
	int kx = 70; int ky = 27;
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
		for (float t = 0.0f;; t += 0.1f) {
		GSetConsoleAttribute(15);
		int sy = 0;
		float s = sinf(t);
		float a = s * s * s * s * 0.2f;
		for (float z = 1.3f; z > -1.2f; z -= 0.1f) {
			_TCHAR* p = &buffer[sy++][0];
			float tz = z * (1.2f - a);
			for (float x = -1.5f; x < 1.5f; x += 0.05f) {
				float tx = x * (1.2f + a);
				float v = f(tx, 0.0f, tz);
				if (v <= 0.0f) {
					float y0 = h(tx, tz);
					float ny = 0.01f;
					float nx = h(tx + ny, tz) - y0;
					float nz = h(tx, tz + ny) - y0;
					float nd = 1.0f / sqrtf(nx * nx + ny * ny + nz * nz);
					float d = (nx + ny - nz) * nd * 0.5f + 0.5f;
					*p++ = ramp[(int)(d * 5.0f)];
				}
				else
					*p++ = ' ';
			}
		}
		//

		//
		for (sy = 0; sy < 25; sy++) {
			COORD coord = { 0, sy };
			SetConsoleCursorPosition(o, coord);
			WriteConsole(o, buffer[sy], 79, NULL, 0);
		}
		//
		SetConsolePosition(x - 4, y);
		cout << "��";
		GSetConsoleAttribute(64);
		SetConsolePosition(x - 4, y + 1);
		cout << "��";
		GSetConsoleAttribute(15);
		SetConsolePosition(x + 1 - 4, y + 2);
		cout << "��";

		SetConsolePosition(x - 2, y + 1);
		cout << "  ";
		SetConsolePosition(x, y + 2);
		cout << "  ";

		SetConsolePosition(x - 2, y);
		cout << "��";
		SetConsolePosition(x, y);
		cout << "��";
		SetConsolePosition(x, y + 1);
		cout << "��";
		SetConsolePosition(x - 2, y + 1);
		cout << "��";
		//
		SetConsolePosition(kx, ky);
		cout << "�I";
		SetConsolePosition(kx + 2, ky + 1);
		cout << "�v";

		GReadAndWrite();
		SetConsolePosition(kx, ky);
		cout << "  ";
		SetConsolePosition(kx + 2, ky + 1);
		cout << "  ";
		if (kx >= 40)
		{
			kx -= 2;
			ky--;
		}
		else
		{
			break;
		}

		Sleep(33);
	}

		Sleep(1000);
		GSetConsoleAttribute(128);
		RenewTheScreen();
		GReadAndWrite();
		string m = "���ӡ��ħ�� ����Ҫ�����ֻ�ʯ ����������һƬ����֮��  ......";
		for (int i = 0; i < m.size(); i++)
		{
			SetConsolePosition(35 + i, 10);
			if (m[i] == ' ')continue;
			cout << m[i];
			GReadAndWrite();
			Sleep(40);
		}
		Sleep(1000);
		GSetConsoleAttribute(128);
}
