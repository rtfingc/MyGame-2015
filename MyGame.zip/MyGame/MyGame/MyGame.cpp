﻿#include<iostream>
#include<Windows.h>
#include<direct.h>
#include<fstream>
#include<string>
#include"Paint.h"
#include"SetColor.h"
#include"NPC.h"
#include"SetColor.h"
#include"GameLevel.h"
#include<direct.h>
#include<ctime>
#include"Affair.h"
#include<time.h>
/*要额外附加一个机关系统*/
using namespace std;
int main()
{srand(time(0));
	//跳跃问题迟迟木有解决
	/*
	待添加
	获取系统时间

	SYSTEMTIME sys;
	GetLocalTime(&sys);
	cout << sys.wHour << endl;
	cout << sys.wMinute << endl;

	用于对人物寿命的判断
	*/

	/*人物的跳跃有卡顿现象，*/
	/*人物的向前向后走也有卡顿现象，待优化*/
	/*怪物的移动会出现两个画面重叠的现象，待优化*/

	//还未解决问题
	/*
	*  人物技能的实现
	*  如何进行随机的事件发生
	*  人物的轮回的实现
	* 人物要以什么方式获得造善业。恶业，结善缘。恶缘
	
	*开机动画的实现

	*新游戏开始时的剧情绘制

	* 第一个关卡的背景画面的实现//仿照引火精灵

	* 第二个关卡的背景画面的实现//第二个关卡为事件关卡，相当于一个中转站，可以触发一定的事件

	* 第三个关卡的背景画面的实现//名为悲惨世界 到处充满欺骗

	* 第四个关卡的背景画面的实现//名为杀戮之都 随时可能死亡

	* 第五个关卡的背景画面的实现//仿照游戏绝唱 为机关型关卡，目的是打开通往最后一个世界的大门

	* 第六个关卡的背景画面的实现//最后一个关卡是迷宫游戏，在这里设置随机的选择，对不同的选择会通向不同的房间
	
	*通关的动画绘制

	*各个阶段的affair的实现

	*机关中的齿轮和开关的实现还没有完成

	*在飞行关卡中的键盘检测

	*在点灯时存档时没有保存当前的灯的状态 待优化

	游戏的最后是到达魔王的房间
	但是魔王是不可能打败的
	目标是找到魔王的心所在的房间
	当找到魔王的心所在的房间是游戏结束
	*人物相对于不同背景色对于自身的背景色的变换，待解决

	*四个道中人物不同形象的绘制
	       *其中人道已完成，并确定为该种形象
		   *畜生道已成
		   *现在进行恶鬼道和修罗道的实现

	* Paint 背景画面时对颜色的实时改变

	* 人物碰到特定对象时血量的变化

	*NPC形象的实现1

	*moster形象的实现

	* 人物对话的实现

	*/
	/////临时想法  可以吧背景色换成绿色

		_mkdir("d:\\MyGame");
		ChangeTheWindow();
		GMoreBuffer();

		
		//GSetConsoleAttribute(128);
		//RenewTheScreen();
		//GReadAndWrite();
		SetConsoleTitle("                                                                                                                                                                                   -- 轮回  1.0 --");
		GSetConsoleAttribute(128);
		paintStartFilm();
		while (true)
		{
		GameRun();
		}
		//Paintman(10, 10);
	
}
//moster在人物移动时的刷新问题