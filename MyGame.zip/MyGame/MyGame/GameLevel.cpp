#include "GameLevel.h"
#include"Paint.h"
#include"Affair.h"
#include"moster.h"
#include<iostream>
#include<Windows.h>
#include<string>
#include<fstream>
#include<climits>
using namespace std;
HANDLE Ghout = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE GhNewScreenBuffer;
SMALL_RECT GsrctReadRect;
SMALL_RECT GsrctWriteRect;
CHAR_INFO GchiBuffer[172 * 52] = { 0 };
//CHAR_INFO EchiBuffer[20*42] = { 0 };
COORD GcoordBufSize;
COORD GcoordBufCoord;
//int man_x = 28; int man_y = 28;
int StartCurrentID = GStartGame;

SYSTEMTIME sys;

Man man_in;
string Record = "d:\\MyGame\\MyGameRecord";
string MyRecordID[7] = {
	"1.txt","2.txt","3.txt","4.txt","5.txt","6.txt"
};

Background background[7];
//
moster *mosterin[10];
moster1 moster1_in[20];
moster2 moster2_in[20];
moster3 moster3_in;
moster4 moster4_in[20];
//
Npc *npcmoniter[10];
Npc1 npc1;
Npc2 npc21, npc22, npc23,npc24,npc25,npc26;
Npc3 npc3;

Jiguang *JiguangMonitor[15];
Jiguang1 jg1[40]; 

Jiguang2 jg2[200];
Jiguang3 jg3[200];
Jiguang4 jg4[200];
Jiguang5 jg5[200];
Jiguang6 jg6[500];
Jiguang7 jg7[10];
//
#define man_x 28
#define man_y 27
#define man_RLnum 2
#define man_UDnum 1
//Ҫ���һ���������ɫ��� ͬʱ�ڴ�����ɫ��ʱ��Ҫ���ض������ڵ�color ���г�ʼ��



void GMoreBuffer()
{


	GhNewScreenBuffer = CreateConsoleScreenBuffer(
		GENERIC_READ |           // read/write access 
		GENERIC_WRITE,
		FILE_SHARE_READ |
		FILE_SHARE_WRITE,        // shared 
		NULL,                    // default security attributes 
		CONSOLE_TEXTMODE_BUFFER, // must be TEXTMODE 
		NULL);                   // reserved; must be NULL 

								 // Make the new screen buffer the active screen buffer. 
	SetConsoleActiveScreenBuffer(GhNewScreenBuffer);
	CONSOLE_CURSOR_INFO cci;
	GetConsoleCursorInfo(GhNewScreenBuffer, &cci);
	cci.bVisible = 0;
	cci.dwSize = 1;
	SetConsoleCursorInfo(Ghout, &cci);
	SetConsoleCursorInfo(GhNewScreenBuffer, &cci);

}
void RenewTheScreen()
{
	for (int i = 0; i < 180; i++)
	{
		for (int j = 0; j < 60; j++)
		{
			SetConsolePosition(i, j);
			cout << ' ';
		}
	}
}
/*����̨��Ϸ���沿��˫�����д*/
void GReadAndWrite()
{
	GsrctReadRect.Top = 0;    // top left: row 0, col 0 
	GsrctReadRect.Left = 0;
	GsrctReadRect.Bottom = 40; // bot. right: row 1, col 79 
	GsrctReadRect.Right = 160;

	GsrctWriteRect.Top = 0;    // top lt: row 10, col 0 
	GsrctWriteRect.Left = 0;
	GsrctWriteRect.Bottom = 40; // bot. rt: row 11, col 79 
	GsrctWriteRect.Right = 160;

	GcoordBufSize.Y = 40;
	GcoordBufSize.X = 160;


	GcoordBufCoord.X = 0;
	GcoordBufCoord.Y = 0;
	//SetConsolePosition(160, 40);
	//cout << endl;
	//fflush(stdout);
	ReadConsoleOutput(
		Ghout,        // screen buffer to read from 
		GchiBuffer,      // buffer to copy into 
		GcoordBufSize,   // col-row size of chiBuffer 
		GcoordBufCoord,  // top left dest. cell in chiBuffer 
		&GsrctReadRect); // screen buffer source rectangle 
	
	WriteConsoleOutput(
		GhNewScreenBuffer, // screen buffer to write to 
		GchiBuffer,        // buffer to copy from 
		GcoordBufSize,     // col-row size of chiBuffer 
		GcoordBufCoord,    // top left src cell in chiBuffer 
		&GsrctWriteRect);  // dest. screen buffer rectangle 
	//cin.ignore(40*160);
	//cin.ignore(1);
	
	
}

///////���ô�
int IsLightTheDeng()
{
	for (int i = 0; i < 6; i++)
	{
		if (jg1[i].GetLight()== 0)
			return 0;
	}
	return 1;
}
void GSetConsoleAttribute(int color_in)
{
	SetConsoleTextAttribute(Ghout, color_in);
}
bool LevelEndJudge(Man &man_in, int &isfirsttime)
{
	if (man_in.Levelend_judge()&&IsLightTheDeng())
	{
		if (man_in.GetCurrentLevel() == Level_5)
		{
			if (npc1.IsTalk(man_in))
			{
				isfirsttime = 2;
				return 1;
			}
		}
		else
		{
			isfirsttime = 2;
			return 1;
		}
	}
	return 0;
}

int CurrentRecord = 0;
/*������Ϸ��int��Ϊָ����GameLevel*/
void GameRun()//��ͬ��֮���ת��ֻ�Ǽ��̼��������ͬ��ֻҪ�ڼ��̼��Ӹ������ж��Ϳ�����
{
	//man_in.SetEdge(28, 28);
int IsFirstTime = 1;//���ڶ����˵��д浵��ȡ�Ĺ���ʵ��
		int current_id = 1;//��ǰ�Ĳ˵�����
		RunStartMenue();
		int mm;
		GetLocalTime(&sys);
		man_in.SetGameStartTime(sys.wMinute);
		while (true)
		{
			
			if (current_id == 0)break;//���ڷ�����һ��
			switch (StartCurrentID)
			{
			case GStartGame:

				if (IsFirstTime==1)//�������ͨ�� �µ���Ϸ ��ť����� �����г�ʼ�����ɴ�ʵ�ִ浵�Ķ�ȡ
				{//
					//jg1.SetLight(0);

					GetLocalTime(&sys);
					man_in.SetGameStartTime(sys.wMinute);
					InitialLight();
					man_in.InitialMan();
					InitBackground(man_in.GetCurrentLevel());

					IsFirstTime = 0;
					paintStartFilm1();
					paintStartFilm2();
					paintStartFilm3();
					paintStartFilm4();
					paintStartFilm5();
					paintStartFilm6();
					GSetConsoleAttribute(128);
					
				}
				else if (IsFirstTime == 2)
				{
					GetLocalTime(&sys);
					man_in.SetGameStartTime(sys.wMinute);
					InitialLight();
					InitialtheSwitch();
					//man_in.InitialMan();
					InitBackground(man_in.GetCurrentLevel());

					IsFirstTime = 0;
				}
				RenewTheScreen();
				PaintLevelBackground(man_in,0);
				if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
				{
					
					//WrapLevelBackground();
				
					man_in.Paintman(man_x+30, man_y-10, 2);
					
				}
				else
				{
				WrapLevelBackground();
				
					man_in.Paintman(man_x, man_y, 2);//GReadAndWrite();
				}
				GReadAndWrite();
				//WrapLevelBackground();
				//int t = 0;
				// mm = 0;
				while (true)
				{
					Sleep(20);
					
					//�������
					LifeJudge(man_in);	
					//ͨ�ؼ��
					if (LevelEndJudge(man_in, IsFirstTime))
					{
						switch (man_in.GetCurrentLevel())
						{
						case Level_1:
							Affair8();
							InitialLight();
							InitialtheSwitch();
							break;
						case Level_2:
							InitialLight();
							InitialtheSwitch();
							Affair9();
							break;
						case Level_3:
							InitialLight();
							InitialtheSwitch();
							Affair10();
							break;
						case Level_4:
							InitialLight();
							InitialtheSwitch();
							Affair11();
							break;
						case Level_5:
							
								Affair12();
							//break;*/
							
							InitialLight();
							InitialtheSwitch();
							
							break;
						case Level_6:
							Affair13();
	                       current_id = 0;
							break;
						}
						
					
						man_in.SetCurrentLevel(man_in.GetCurrentLevel()+1);
						if(man_in.GetCurrentLevel()==Level_6)man_in.RunManDie();
						break;
					}
					else if(man_in.Levelend_judge()&&!IsLightTheDeng())
					{
						if (man_in.GetCurrentLevel() != Level_5)
						{
							PaintTalkBackground();
						GSetConsoleAttribute(15);
						SetConsolePosition(30, 33);
						cout << "�㻹û����ȫ���·�ӡ ����";
						GReadAndWrite();
						while (1)
						{
							if (GetAsyncKeyState(VK_RETURN))
							{
								break;
							}
						}
						background[man_in.GetCurrentLevel()].Max_left-=10;
						background[man_in.GetCurrentLevel()].Max_right-=10;
						GSetConsoleAttribute(128);
						RenewTheScreen();
						
						PaintLevelBackground(man_in,0);
						}
						
						
					}

					if (man_in.GetCurrentLevel() != Level_5&&man_in.GetCurrentLevel() != Level_6)
					{
						while (!IsStopDown(man_in))
						{
							WrapLevelBackground(40);
							b_1_ManMoveDown(); PaintLevelBackground(man_in, 30);
							man_in.Paintman(man_x, man_y, 2); //cout << endl;

							GReadAndWrite();
						}
					}/*���ո��������δ���ƣ�Ӧ������һ���˵�ѡ��*/
					if (GetAsyncKeyState(VK_SPACE))
					{
						//if (GetAsyncKeyState(VK_SPACE)) {}
						int t = RunStopMenue(man_in);
						if (t == 1)
						{
							current_id = 0;
							break;
						}
						else if (t == 2)
						{
							
							//current_id == 0;
							break;
						}

					}
					/*�����Ϸ���*/
					else if (GetAsyncKeyState(VK_RIGHT) && GetAsyncKeyState(VK_UP))
					{
						if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							man_in.Paintman(man_x+30, man_y-10, 2);
							if (man_in.GetDao() == 1 || man_in.GetDao() == 3)
							{
								for (int i = 0; i < 1; i++)//�����1�ٶȵ�����
								{
									man_in.Paintman(man_x + 30, man_y - 10, 2);

									if (!IsStopRightAndUp(man_in))
									{
										WrapLevelBackground(32);
										for (int i = 0; i < man_RLnum; i++)
										{
											//if (!IsStopRight(man_in))
											b_1_ManMoveRight();
										}
										for (int i = 0; i < man_UDnum; i++) {
											//if (!IsStopUp(man_in))
											b_1_ManMoveUp();
										}
										PaintLevelBackground(man_in, 32);
										man_in.Paintman(man_x + 30, man_y - 10, 3);
										GReadAndWrite();
									}
								}
							}
							else
							{
								man_in.Paintman(man_x+30, man_y-10, 2);
								for (int i = 0; i < 10; i++)//�����1�ٶȵ�����
								{
									man_in.Paintman(man_x+30, man_y-10, 2);

									if (!IsStopRightAndUp(man_in))
									{
										WrapLevelBackground(32);
										for (int i = 0; i < man_RLnum; i++)
										{
											//if (!IsStopRight(man_in))
											b_1_ManMoveRight();
										}
										for (int i = 0; i < man_UDnum; i++) {
											//if (!IsStopUp(man_in))
											b_1_ManMoveUp();
										}
										PaintLevelBackground(man_in, 32);
										man_in.Paintman(man_x+30, man_y-10, 3);
										GReadAndWrite();
									}
								}

								//Sleep(50);
								int t = 0;
								while (!IsStopRightAndDown(man_in))
								{
									t++;
									if (t >= 16)break;
									WrapLevelBackground(42);
									for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown(); //WrapLevelBackground();
									PaintLevelBackground(man_in, 42);
									man_in.Paintman(man_x+30, man_y-10, 3);
									GReadAndWrite();
								}
								while (!IsStopDown(man_in))
								{
									WrapLevelBackground(40);
									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown();
									PaintLevelBackground(man_in, 40);
									man_in.Paintman(man_x+30, man_y-10, 3);
									GReadAndWrite();
								}
							}
						}
						else
						{
							JumpUpAndRight(man_in);
						}

					}
					/*�����Ϸ�*/
					else if (GetAsyncKeyState(VK_LEFT) && GetAsyncKeyState(VK_UP))
					{
						
						if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							if (man_in.GetDao() == 1 || man_in.GetDao() == 3)
							{
								int t = 0;
								for (int i = 0; i < 1; i++)//�����1�ٶȵ�����
								{
									man_in.Paintman(man_x + 30, man_y - 10, 1);

									if (!IsStopLeftAndUp(man_in))
									{
										WrapLevelBackground(31);
										for (int i = 0; i < man_RLnum; i++)b_1_ManMoveLeft();
										for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
										PaintLevelBackground(man_in, 31);
										man_in.Paintman(man_x + 30, man_y - 10, 3);
										GReadAndWrite();
									}

								}
							}
							else
							{
								int t = 0;
								for (int i = 0; i < 10; i++)//�����1�ٶȵ�����
								{
									man_in.Paintman(man_x+30, man_y-10, 1);

									if (!IsStopLeftAndUp(man_in))
									{
										WrapLevelBackground(31);
										for (int i = 0; i < man_RLnum; i++)b_1_ManMoveLeft();
										for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
										PaintLevelBackground(man_in, 31);
										man_in.Paintman(man_x+30, man_y-10, 3);
										GReadAndWrite();
									}
									//man_in.Painman(29, 29);


								}
								//Sleep(50);


								//Sleep(50);
								t = 0;
								while (!IsStopLeftAndDown(man_in))
								{
									t++;
									if (t >= 16)break;
									WrapLevelBackground(41);
									for (int i = 0; i < man_RLnum; i++)b_1_ManMoveLeft();
									for (int i = 0; i < man_UDnum; i++)b_1_ManMoveDown();
									PaintLevelBackground(man_in, 41);
									man_in.Paintman(man_x+30, man_y-10, 3);
									GReadAndWrite();
								}

								//man_in.Painman(29, 29);


								while (!IsStopDown(man_in))
								{
									WrapLevelBackground(40);

									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)	//if (!IsStopDown(man_in))
										b_1_ManMoveDown();
									PaintLevelBackground(man_in, 40);
									man_in.Paintman(man_x+30, man_y-10, 3);
									GReadAndWrite();
								}
								//t = 0;
							}
							
						}
						else
						{
							JumpUpAndLeft(man_in);
						}

					}
				
					/*������*/
					else if (GetAsyncKeyState(VK_RIGHT))
					{
						if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							if (man_in.GetDao() == 1 || man_in.GetDao() == 3)
							{
								if (!IsStopRight(man_in))
								{
									WrapLevelBackground(2);
									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopRight(man_in))
										b_1_ManMoveRight();

									}

									//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
									PaintLevelBackground(man_in, 2);
									man_in.Paintman(man_x + 30, man_y - 10, 2);
									//	cout << endl;
									GReadAndWrite();
								}
							}
							else
							{
								int t = 0;

								if (!IsStopRight(man_in))
								{
									WrapLevelBackground(2);
									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopRight(man_in))
										b_1_ManMoveRight();

									}

									//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
									PaintLevelBackground(man_in, 2);
									man_in.Paintman(man_x+30, man_y-10, 2);
									//	cout << endl;
									GReadAndWrite();
								}


								//�˴�Ϊ���������ķ�����ʱ����������������������֮��Ҫ�ǵû�ԭ
								t = 0;
								while (!IsStopRightAndDown(man_in))
								{
									t++;
									if (t >= 3)break;
									WrapLevelBackground(42);

									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopRight(man_in))
										b_1_ManMoveRight();
									}
									for (int i = 0; i < man_UDnum; i++)
									{
										//if (!IsStopDown(man_in))
										b_1_ManMoveDown();
									}
									PaintLevelBackground(man_in, 42);
									// PaintLevelBackground(man_in, 41);
									man_in.Paintman(man_x+30, man_y-10, 2);// cout << endl;
									GReadAndWrite();//Sleep(50);
								}
								while (!IsStopDown(man_in))
								{
									//t++;
									//if(t%2==0)
									WrapLevelBackground(40);
									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)
									{
										//if(!IsStopDown(man_in))
										b_1_ManMoveDown();
									}
									//if (t % 2 == 0);

									PaintLevelBackground(man_in, 40);
									man_in.Paintman(man_x+30, man_y-10, 2); //cout << endl;


									GReadAndWrite();
								}
							}
						}
						else
						{
							RunRight(man_in);
							
						}
					}
					/*������*/
					else if (GetAsyncKeyState(VK_LEFT))
					{
					if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							if (man_in.GetDao() == 1 || man_in.GetDao() == 3)
							{
								if (!IsStopLeft(man_in))
								{
									WrapLevelBackground(1);
									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopLeft(man_in))
										b_1_ManMoveLeft();
									}
									//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
									PaintLevelBackground(man_in, 1);
									man_in.Paintman(man_x + 30, man_y - 10, 1);


									GReadAndWrite();
								}
							}
							else
							{
								int t = 0;

								if (!IsStopLeft(man_in))
								{
									WrapLevelBackground(1);
									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopLeft(man_in))
										b_1_ManMoveLeft();
									}
									//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
									PaintLevelBackground(man_in, 1);
									man_in.Paintman(man_x+30, man_y-10, 1);


									GReadAndWrite();
								}
								//Sleep(50);
								//�˴�Ϊ���������ķ�����ʱ����������������������֮��Ҫ�ǵû�ԭ
								t = 0;
								while (!IsStopLeftAndDown(man_in))
								{
									t++;
									if (t >= 3)break;
									WrapLevelBackground(41);

									for (int i = 0; i < man_RLnum; i++)
									{
										//if (!IsStopLeft(man_in))
										b_1_ManMoveLeft();
									}
									for (int i = 0; i < man_UDnum; i++) {
										b_1_ManMoveDown();
									}

									PaintLevelBackground(man_in, 41);
									man_in.Paintman(man_x+30, man_y-10, 1);
									GReadAndWrite();//Sleep(50);
								}
								while (!IsStopDown(man_in))
								{
									WrapLevelBackground(40);

									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)
									{
										//if (!IsStopDown(man_in))
										b_1_ManMoveDown();
									}

									PaintLevelBackground(man_in, 40);
									man_in.Paintman(man_x+30, man_y-10, 1);
									GReadAndWrite();
								}
							}
						}
						else
						//{
							RunLeft(man_in);
						//}

					}
					/*������*/
					else if (GetAsyncKeyState(VK_UP))
					{
						
						if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							if (man_in.GetDao() == 1 || man_in.GetDao() == 3)
							{
								if (!IsStopUp(man_in))
								{
									WrapLevelBackground(30);

									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)
									{
										//if (!IsStopUp(man_in))
										b_1_ManMoveUp();
									}

									PaintLevelBackground(man_in, 30);
									man_in.Paintman(man_x + 30, man_y - 10, 3);
									GReadAndWrite();
								}
							}
							else
							{
								int t = 0;
								for (int i = 0; i < 10; i++)
								{
									if (!IsStopUp(man_in))
									{
										WrapLevelBackground(30);

										//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
										for (int i = 0; i < man_UDnum; i++)
										{
											//if (!IsStopUp(man_in))
											b_1_ManMoveUp();
										}

										PaintLevelBackground(man_in, 30);
										man_in.Paintman(man_x+30, man_y-10, 3);
										GReadAndWrite();
									}
								}

								

								
								

								while (!IsStopDown(man_in))
								{

									WrapLevelBackground(40);
									//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
									for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown();

									PaintLevelBackground(man_in, 40);
									man_in.Paintman(man_x+30, man_y-10, 3);

									GReadAndWrite();
								}
							}
						}
						else
						//{
							JumpUp(man_in);
						//}


					}
				

					else {
						
						if (man_in.GetCurrentLevel() == Level_5|| man_in.GetCurrentLevel() == Level_6)
						{
							if (!IsStopDown(man_in))
							{
								WrapLevelBackground(40);
								b_1_ManMoveDown();
								//WrapLevelBackground(40);
								//b_1_ManMoveDown();
								PaintLevelBackground(man_in, 40);
								man_in.Paintman(man_x+30, man_y-10, 2); //cout << endl;

								GReadAndWrite();
							}
							else
							{
								WrapLevelBackground(0);
								//b_1_ManMoveDown();
								PaintLevelBackground(man_in, 0);
								man_in.Paintman(man_x + 30, man_y - 10, 2); //cout << endl;

								GReadAndWrite();
							}
						}
						else
						{
							//RenewTheScreen();
							WrapLevelBackground(0);
							PaintLevelBackground(man_in, 0);
							man_in.Paintman(man_x, man_y , 5);
							GReadAndWrite();
						}
					}
				}
					//Sleep(50);*
				//PaintLevelBackground(0);
				break;
				/*�浵��ʵ�֣�δ���*/
			case GReadRecrd:

				WrapStartMenue();
				PiantReadRecordMenue();
				GReadAndWrite();
				if (RunSeletSave()==false)
				{
					
				current_id = 0;

				}
				else
				{
					int light[7];
					int Switch[7];
					ifstream MyRecordi;
					////////////////////////////////
					
					//////////////////////////////////////////
					MyRecordi.open(Record + MyRecordID[CurrentRecord], ios::binary);
					MyRecordi.read(reinterpret_cast<char*>(&man_in), sizeof(Man));
					//for (int i = 0; i < 6;i++)
					MyRecordi.read(reinterpret_cast<char*>(&background[man_in.GetCurrentLevel()]), sizeof(Background));
				
					//�����level 1 �Ƶ�״̬����
					for (int i = 0; i < 6; i++)
					{
						MyRecordi.read(reinterpret_cast<char*>(&light[i]), sizeof(int));

						jg1[i].SetLight(light[i]);
						//break;

					}
					for (int i = 0; i < 6; i++)
					{
						MyRecordi.read(reinterpret_cast<char*>(&Switch[i]), sizeof(int));

						jg7[i].setstate(Switch[i]);
						//break;

					}
					
					MyRecordi.close();
					StartCurrentID = GStartGame;
					GetLocalTime(&sys);
					man_in.SetGameStartTime(sys.wMinute);

					IsFirstTime = 0;
					WrapReadRecordMenue();

					WrapPaintChose(CurrentRecord);
					GReadAndWrite();
				}
				
				//GameRun();
				break;
				
				/*�����˵�ѡ�񣬼򵥣�������*/
			case GHelp:
				GSetConsoleAttribute(0);
				RenewTheScreen();
				GSetConsoleAttribute(15);
				SetConsolePosition(20, 10);
				cout << "������������������� ";
				SetConsolePosition(20, 11);
				cout << "�ո���˳� ���س�����";
				SetConsolePosition(20, 12);
				cout << "���������Ϸ���й��������ڵ�Դѡ����ѡ�������";
				GReadAndWrite();
				while (1)
				{
					Sleep(100);
					if (GetAsyncKeyState(VK_SPACE))
					{
						break;
					}
				}
				GSetConsoleAttribute(128);
				current_id = 0;
				break; 
				/*��Esc�˳���Ϸ*/
			case GEsc:
				exit(0);
				break;
			}
		}
}
//�浵ѡ���ܵ�ʵ��
	bool RunSeletSave()
	{
		PiantReadRecordMenue();
		PaintChose(CurrentRecord);
		GReadAndWrite();
		int t = 0;
		while (true)
		{
			Sleep(200);
			man_in.PaintMessage();
			switch (man_in.GetDao())
			{
			case 0:
				if (t == 0)
				{
					man_in.Paintworld_1_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_1_man_R2(10, 10);
					t = 0;
				}
				break;
			case 1:
				if (t == 0)
				{
					man_in.Paintworld_2_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_2_man_R2(10, 10); t = 0;

				}
				break;
			case 2:
				if (t == 0)
				{
					man_in.Paintworld_3_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_3_man_R2(10, 10); t = 0;
				}
				break;
			case 3:
				if (t == 0)
				{
					man_in.Paintworld_4_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_4_man_R2(10, 10); t = 0;
				}
				break;
			}
			//WrapPaintChose(CurrentRecord);
			GReadAndWrite();
			if (GetAsyncKeyState(VK_DOWN))
			{
				WrapPaintChose(CurrentRecord);
				GReadAndWrite();
				CurrentRecord++;
				if (CurrentRecord > Record_6)
				{
					CurrentRecord = Record_1;
				}
				PaintChose(CurrentRecord);
				GReadAndWrite();
			}
			else if (GetAsyncKeyState(VK_UP))
			{
				WrapPaintChose(CurrentRecord);
				GReadAndWrite();
				CurrentRecord--;
				if (CurrentRecord < Record_1)
				{
					CurrentRecord = Record_6;
				}
				PaintChose(CurrentRecord);
				GReadAndWrite();
			}
			else if (GetAsyncKeyState(VK_RETURN))//������һ��
			{
				return 1;
			}
			else if (GetAsyncKeyState(VK_SPACE))//������һ��
			{
				return 0;
			}
		}
		return 0;
	}


bool IsStopDown(Man &man_in)
{
	
		//GreatGameLevel_1();
		for (int i = 0; i <=man_in.GetR_edge()-man_in.GetL_edge(); i++)
		{/*����ע��Ҫ�������ߵĲ���һ��*/
			
			for (int j = 0; j < 8; j++)
			{
				if ((background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetR_edge() - i-j][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetD_edge()-1 ].paint_type == 4 &&
					background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetR_edge() - i-j][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetD_edge()-1 ].innner_type == 2))
				{
					return 1;
				
				}
			}
			
				if (background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetL_edge()+i][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetD_edge()-1].paint_type ==1||
					background[man_in.GetCurrentLevel()].backgroundmod[background[man_in.GetCurrentLevel()].Max_left + man_in.GetL_edge() + i][background[man_in.GetCurrentLevel()].Max_up - man_in.GetD_edge() - 1].paint_type == 6)
			{
				return 1;
			}
				
		}
			return 0;
	
	
}

bool IsStopUp( Man &man_in)
{
	
		//GreatGameLevel_1();
	//for (int i = man_in.GetR_edge() - man_in.GetL_edge(); i>=0; i--)
		for (int i = 0; i <= man_in.GetR_edge()-man_in.GetL_edge(); i++)
		{/*����ע��Ҫ�������ߵĲ���һ��*/
			if (background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetL_edge() + i][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetU_edge()+1].paint_type == 1||
				background[man_in.GetCurrentLevel()].backgroundmod[background[man_in.GetCurrentLevel()].Max_left + man_in.GetL_edge() + i][background[man_in.GetCurrentLevel()].Max_up - man_in.GetU_edge() + 1].paint_type == 6
				)
			{	
				return 1;
			}
		}

		return 0;

	
}

bool IsStopLeft( Man &man_in)
{
	//GreatGameLevel_1();
		for (int i = 0; i <=man_in.GetD_edge()-man_in.GetU_edge(); i++)
		{/*����ע��Ҫ�������ߵĲ���һ��*/
			
			if (background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetL_edge()-1][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetU_edge() - i].paint_type == 1
				|| background[man_in.GetCurrentLevel()].backgroundmod[background[man_in.GetCurrentLevel()].Max_left + man_in.GetL_edge() - 1][background[man_in.GetCurrentLevel()].Max_up - man_in.GetU_edge() - i].paint_type == 6)
			{
				return 1;
			}
			

			
	}return 0;
}

bool IsStopRight( Man &man_in)
{
	//GreatGameLevel_1();
	
			for (int i = 0; i <= man_in.GetD_edge()-man_in.GetU_edge(); i++)
			{/*����ע��Ҫ�������ߵĲ���һ��*/
				if (background[man_in.GetCurrentLevel() ].backgroundmod[background[man_in.GetCurrentLevel() ].Max_left + man_in.GetR_edge()+1 ][background[man_in.GetCurrentLevel() ].Max_up - man_in.GetU_edge() - i].paint_type ==1
					|| background[man_in.GetCurrentLevel()].backgroundmod[background[man_in.GetCurrentLevel()].Max_left + man_in.GetR_edge() + 1][background[man_in.GetCurrentLevel()].Max_up - man_in.GetU_edge() - i].paint_type == 6)
				{
					return 1;
				}
				
               
			}
		 return 0;


}

bool IsStopRightAndUp( Man &man_in)
{
	if ( IsStopRight( man_in)||IsStopUp(man_in))
		return 1;
	return 0;
}

bool IsStopRightAndDown( Man &man_in)
{
	if (IsStopDown( man_in) || IsStopRight( man_in))
		return 1;
	return 0;
}

bool IsStopLeftAndUp( Man &man_in)
{
	if (IsStopUp( man_in) || IsStopLeft( man_in))
		return 1;
	return 0;
}

bool IsStopLeftAndDown( Man &man_in)
{
	if (IsStopDown(man_in) || IsStopLeft( man_in))
		return 1;
	return 0;
}

void RunStartMenue()
{
	GSetConsoleAttribute(128);
	RenewTheScreen();
	GSetConsoleAttribute(0);
	PaintStart(); //GReadAndWrite();
	GSetConsoleAttribute(128);
	
	
	StartCurrentID = GStartGame;
	//PaintStart();
	//SetAllBackgroundcolor();
	PaintStartMenue();
	GReadAndWrite();
	int t = 0;
	int k = 0;
	//��ʼ�˵��ļ��̼��
	while (true)
	{
		GSetConsoleAttribute(128);
		
		Sleep(100);
		GSetConsoleAttribute(143);
		PaintChose(StartCurrentID);
		GSetConsoleAttribute(128);
		GReadAndWrite();
		if (GetAsyncKeyState(VK_DOWN))
		{
			WrapPaintChose(StartCurrentID);
			StartCurrentID++;
			if (StartCurrentID > GEsc)
			{
				StartCurrentID = GStartGame;
			}
			GSetConsoleAttribute(143);
			PaintChose(StartCurrentID);
			GSetConsoleAttribute(128);
			GReadAndWrite();
		}

		else if (GetAsyncKeyState(VK_UP))
		{
			WrapPaintChose(StartCurrentID);
			StartCurrentID--;
			if (StartCurrentID < GStartGame)
			{
				StartCurrentID = GEsc;
			}
			GSetConsoleAttribute(143);
			PaintChose(StartCurrentID);
			GSetConsoleAttribute(128);
			GReadAndWrite();
		}
		else if (GetAsyncKeyState(VK_RETURN))
		{
			break;
		}
		
			if (t == 0)
			{
				man_in.Paintworld_1_man_R(7, 8); t = 1;
			}
			else if (t == 1)
			{
				man_in.Paintworld_1_man_R2(7, 8); t = 0;

			}
			if (k == 0||k==1)
			{
				SetConsolePosition(110 + 1, 33);
				cout << "  ";
				SetConsolePosition(110 + 1, 34);
				cout << "  ";
				SetConsolePosition(110 + 1, 35);
				cout << "  ";
				man_in.WrapWorld_3_man_R(110 + 2, 35);

				SetConsolePosition(110, 33);
				cout << "�u";
				SetConsolePosition(110 - 2, 34);
				cout << "�u";
				man_in.Paintworld_3_man_R(110 - 2, 34);
				k ++;
			}
			else if (k == 2||k==3)
			{
				SetConsolePosition(110, 33);
				cout << "  ";
				SetConsolePosition(110 - 2, 34);
				cout << "  ";
				man_in.WrapWorld_3_man_R(110 - 2, 34);

				SetConsolePosition(110+1, 33);
				cout << "��";
				SetConsolePosition(110+1, 34);
				cout << "��";
				SetConsolePosition(110 + 1, 35);
				cout << "��";
				man_in.Paintworld_3_man_R(110+2, 35);
				k  ++;
			}
			else if (k == 4||k==5)
			{
				SetConsolePosition(110 + 1, 33);
				cout << "  ";
				SetConsolePosition(110 + 1, 34);
				cout << "  ";
				SetConsolePosition(110 + 1, 35);
				cout << " ";
				man_in.WrapWorld_3_man_R(110 + 2, 35);
				SetConsolePosition(110 + 2, 33);
				cout << "�v";
				SetConsolePosition(110 + 4, 34);
				cout << "�v";
				man_in.Paintworld_3_man_R(110 + 6, 34);
				k ++;
			}
			else if (k == 6||k==7)
			{
				SetConsolePosition(110 + 2, 33);
				cout << "  ";
				SetConsolePosition(110 + 4, 34);
				cout << "  ";
				man_in.WrapWorld_3_man_R(110 + 6, 34);
				SetConsolePosition(110 + 1, 33);
				cout << "��";
				SetConsolePosition(110 + 1, 34);
				cout << "��";
				SetConsolePosition(110 + 1, 35);
				cout << "��";
				man_in.Paintworld_3_man_R(110 + 2, 35);
				k ++;
				if (k > 7)k = 0;
			}
			SetConsolePosition(130 , 20);
			cout << "��";
			SetConsolePosition(130+2, 20);
			cout << "�z";
			SetConsolePosition(130 + 4, 20);
			cout << "��";
			SetConsolePosition(130 -2, 20);
			cout << "�O";
			SetConsolePosition(130-2, 21);
			cout << "���ʵ����";
		

	}
}



void b_1_ManMoveLeft()
{
	
		if (background[man_in.GetCurrentLevel() ].Max_left > 1)
		{
			background[man_in.GetCurrentLevel() ].Max_right -= 1;
			background[man_in.GetCurrentLevel() ].Max_left -= 1;
		}
	
}

void b_1_ManMoveRight()
{
	
		if (background[man_in.GetCurrentLevel() ].Max_right <background[man_in.GetCurrentLevel() ].Max_x - 1)
		{
			background[man_in.GetCurrentLevel() ].Max_right += 1;
			background[man_in.GetCurrentLevel() ].Max_left +=1;
		}
}

void b_1_ManMoveUp()
{
	
		if (background[man_in.GetCurrentLevel() ].Max_up<background[man_in.GetCurrentLevel() ].Max_y - 1)
		{
			background[man_in.GetCurrentLevel() ].Max_up +=1;
			background[man_in.GetCurrentLevel() ].Max_down +=1;
		}
		
}
void b_1_ManMoveDown()
{
	
		if (background[man_in.GetCurrentLevel() ].Max_down >= 1)
		{
			background[man_in.GetCurrentLevel() ].Max_up -=1;
			background[man_in.GetCurrentLevel() ].Max_down -=1;
		}
	
}
void b_1_ManMoveUpAndLeft()
{
	b_1_ManMoveLeft();
	b_1_ManMoveUp();
}

void b_1_ManMoveUpAndRight()
{
	b_1_ManMoveUp();
	b_1_ManMoveRight();
}
void b_1_ManMoveDownAndLeft()
{
	b_1_ManMoveDown();
	b_1_ManMoveLeft();
}
void b_1_ManMoveDownAndRight()
{
	b_1_ManMoveDown();
	b_1_ManMoveRight();
}
//

/*������������*///direction �������һ���ϰ��1 ��������� 2 ���Ҽ���ұ� 30������ ����ϱ� 31 ���� 32 ���� 40 �¼���±ߣ�41 ���£�42 ����
void PaintLevelBackground(Man&man_in,int direction)//paintֻ��paint��wrap���Ĳ��� ����Ч��
{
	
	//mosterin[0] = &moster1_in;mosterin[1] = &moster2_in;
	npcmoniter[0] =&npc1;
	
	npcmoniter[1] = &npc21; npcmoniter[3] = &npc22; npcmoniter[4] = &npc23; npcmoniter[5] = &npc24; npcmoniter[6] = &npc25;

	npcmoniter[2] = &npc3;
	
	//��ʼ��ָ��
	//GreatGameLevel_1();
	SetConsoleTextAttribute(Ghout, 0);
	
		man_in.SetMax_D(background[man_in.GetCurrentLevel() ].Max_down);
		man_in.SetMax_U(background[man_in.GetCurrentLevel() ].Max_up);
		man_in.SetMax_L(background[man_in.GetCurrentLevel() ].Max_left);
		man_in.SetMax_R(background[man_in.GetCurrentLevel() ].Max_right);
		//������������д�ӡ������moster ���أ�һ���ϰ���
    for (int i = 0; i <160; i++)
		{
			for (int j = 0; j <40; j++)
			{
				//
				//SetConsoleTextAttribute(Ghout, 0);
				if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left]
					[background[man_in.GetCurrentLevel() ].Max_up - j].paint_type != 0)
				{
					

			
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 1
						||background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type == 6)// 1 Ϊһ���ϰ���//6Ϊ�ܿ��ϰ���
					{
							
						
						if (direction == 0)
						{	GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
							SetConsolePosition(i, j);
							cout << "#";
						}
						else if (direction == 1)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left + man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left + man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								//SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 2)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left-man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type !=1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left - man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
                                   cout << "#";
							}
						}
						else if (direction == 30)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j - man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 31)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left+man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j - man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left + man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 32)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left-man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j - man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left - man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 40)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j +man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j + man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 41)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left+man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 1
								&&background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left + man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
						else if (direction == 42)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left-man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 1//||
								&&background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left - man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 6)
							{
								GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
								SetConsolePosition(i, j);
								cout << "#";
							}
						}
					
					}
                   //2 Ϊ����*/
					else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type == 2)
					{
						GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
						//if (i >= 0 + 3 && i <= 160 - 3 && j >= 0 + 1 && j <= 40 - 1)
							//ʵ�ֹ�������»������ƶ�
						if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 1)//�����ƶ�moster
						{
							
							if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 2)//����
							{
								//int t = j--;
								int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);
								moster1_in[t1].InitialEdge(i, j);
								//	if (moster1_in[t1].GetMax_R()<160 - 1 && moster1_in[t1].GetMax_L()>0 + 1 && moster1_in[t1].GetMax_D()<40 - 1 && moster1_in[t1].GetMax_U()>0 + 1)
								moster1_in[t1].PaintMoster(i, j, 2);
								background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num--;

								if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num <= 0)
								{
									//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
									background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 1;
								}
								else {
								CopyBackGroudPoint(i, j, i, j - 1);
								initialBackGroundPoint(i, j);
								}
							}
							//}
							//	mosterin[0]->PaintMoster(i, j);
							int t = 0; int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{

								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);

								if (i >= moster1_in[t1].GetMax_L() && i <= moster1_in[t1].GetMax_R())
								{
									t++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{

								if (i >= moster1_in[t1].GetMax_U() && i <= moster1_in[t1].GetMax_D())
								{
									t++;
									break;
								}
							}
							if (t == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 2);
							}
						}
						else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 2)//�����ƶ�moster
						{
							int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							moster2_in[t1].InitialEdge(i, j);
							if (moster2_in[t1].GetMax_R() < 160 - 2 && moster2_in[t1].GetMax_L() > 0 + 2 && moster2_in[t1].GetMax_D() < 40 - 2 && moster2_in[t1].GetMax_U() > 2)
							{
								if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 3)//����
								{


									moster2_in[t1].PaintMoster(i, j, 1);

									background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num--;

									if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num < 0)
									{
										//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
										background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 4;
									}
									//else{
									CopyBackGroudPoint(i, j, i - 1, j);
									initialBackGroundPoint(i, j);
									//}

								}
							
								//mosterin[1]->PaintMoster(i, j);
								int t = 0;
								for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
								{
									if (i >= moster2_in[t1].GetMax_L() && i <= moster2_in[t1].GetMax_R())
									{
										t++;
										break;
									}
								}
								for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
								{
									if (i >= moster2_in[t1].GetMax_U() && i <= moster2_in[t1].GetMax_D())
									{
										t++;
										break;
									}
								}
								if (t == 2)	//if(i<28&&j<28)
								{
									man_in.SetBlood(man_in.GetBlood() - 2);
								}

							}
						}
						else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 4)//�����ƶ�moster
						{

							if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 2)//����
							{
								//int t = j--;
								int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);
								moster4_in[t1].InitialEdge(i, j);
								//	if (moster1_in[t1].GetMax_R()<160 - 1 && moster1_in[t1].GetMax_L()>0 + 1 && moster1_in[t1].GetMax_D()<40 - 1 && moster1_in[t1].GetMax_U()>0 + 1)
								moster4_in[t1].PaintMoster(i, j, 2);
								background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num--;

								if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num <= 0)
								{
									//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
									background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 1;
								}
								else {
									CopyBackGroudPoint(i, j, i, j - 1);
									initialBackGroundPoint(i, j);
								}
							}
							//}
							//	mosterin[0]->PaintMoster(i, j);
							int t = 0; int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{

								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);

								if (i >= moster4_in[t1].GetMax_L() && i <= moster4_in[t1].GetMax_R())
								{
									t++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{

								if (i >= moster4_in[t1].GetMax_U() && i <= moster4_in[t1].GetMax_D())
								{
									t++;
									break;
								}
							}
							if (t == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 2);
							}
						}
						else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 3)//���ƶ�moster
						{

						}


					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 4)//4 Ϊ����//��ͬ���صı߽��鲻һ��
					{
						GSetConsoleAttribute(background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].color);
						if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 1)//�ƣ�
						{
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg1[t - 1].SetEdge(i, j);
							if(jg1[t-1].GetMaxR_edge()<160&&jg1[t-1].GetMaxL_edge()>0&&jg1[t-1].GetMaxU_edge()>2&&jg1[t-1].GetMaxD_edge()<40)
								jg1[t - 1].PaintJiGuang(i, j, man_in);
						}
						else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 2)//����
						{
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg2[t].SetEdge(i, j);
							if (jg2[t].GetMaxR_edge()<160 - 2 && jg2[t].GetMaxL_edge()>0 + 1 && jg2[t].GetMaxD_edge()<40 - 1 && jg2[t].GetMaxU_edge()>0 + 1)
								jg2[t].PaintJiGuang(i, j, man_in);
						}
						else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 3)//����
						{
							
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg3[t].SetEdge(i, j);
							if (jg3[t].GetMaxR_edge()<160 - 1 && jg3[t].GetMaxL_edge()>0 + 1 && jg3[t].GetMaxD_edge()<40 - 1 && jg3[t].GetMaxU_edge()>0 + 1)
								jg3[t].PaintJiGuang(i, j, man_in);
							int m = 0;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{
								if (i >= jg3[t].GetMaxL_edge() && i <= jg3[t].GetMaxR_edge())
								{
									m++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{
								if (i >= jg3[t].GetMaxU_edge() && i <= jg3[t].GetMaxD_edge())
								{
									m++;
									break;
								}
							}
							if (m == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 1);
							}
						}
						else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 4)//�ҽ�
						{

							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg4[t].SetEdge(i, j);
							if (jg4[t].GetMaxR_edge()<160 - 1 && jg4[t].GetMaxL_edge()>0 + 1 && jg4[t].GetMaxD_edge()<40 -1 && jg4[t].GetMaxU_edge()>0 + 1)
								jg4[t].PaintJiGuang(i, j, man_in);
							//��������ȥѪ
							int m = 0;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{
								if (i >= jg4[t].GetMaxL_edge() && i <= jg4[t].GetMaxR_edge())
								{
									m++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{
								if (i >= jg4[t].GetMaxU_edge() && i <= jg4[t].GetMaxD_edge())
								{
									m++;
									break;
								}
							}
							if (m == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 1);
							}
						}
						else	if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 5)//����
						{
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg5[t].SetEdge(i, j);
							if (jg5[t].GetMaxR_edge()<160 - 1 && jg5[t].GetMaxL_edge()>0 + 1 && jg5[t].GetMaxD_edge()<40 + 1 && jg5[t].GetMaxU_edge()>0 + 1)
								jg5[t].PaintJiGuang(i, j, man_in);
							int m = 0;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{
								if (i > jg5[t].GetMaxL_edge() && i < jg5[t].GetMaxR_edge())
								{
									m++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{
								if (i<jg5[t].GetMaxD_edge() && i>jg5[t].GetMaxU_edge())
								{
									m++;
									break;
								}
							}
							if (m == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 1);
							}
							
						}
						else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 6)//����
						{
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg6[t].SetEdge(i, j);
							if(jg6[t].GetMaxR_edge()<160-1&&jg6[t].GetMaxL_edge()>0+1&&jg6[t].GetMaxD_edge()<40-1&&jg6[t].GetMaxU_edge()>0+1)
								jg6[t].PaintJiGuang(i, j, man_in);
							int m = 0;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{
								if (i > jg6[t].GetMaxL_edge() && i < jg6[t].GetMaxR_edge())
								{
									m++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{
								if (i > jg6[t].GetMaxU_edge() && i < jg6[t].GetMaxD_edge())
								{
									m++;
									break;
								}
							}
							if (m == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 1);
							}
						}
//
						else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 7)//����
						{
							int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							jg7[t].SetEdge(i, j);
							if (jg7[t].Isman_in(man_in))
							{
								jg7[t].setstate(1);
							}
							if (jg7[t].GetMaxR_edge()<160 - 1 && jg7[t].GetMaxL_edge()>0 + 1 && jg7[t].GetMaxD_edge()<40 - 1 && jg7[t].GetMaxU_edge()>0 + 1)
								jg7[t].PaintJiGuang(i, j, man_in);
						}
					}
				}
			}
		}
	//�ȶ�����������д�ӡ Ȼ�����NPC���е������ж�����ΪNPC�Ի���Ҫ�Ȼ�����������
	for (int i = 160; i >=0; i--)
	{
		for (int j = 40; j >=0; j--)
		{
			if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type == 6)
			{
				int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
				if (jg7[t].GetState())
				{
					background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type = 0;
					GSetConsoleAttribute(128);
					SetConsolePosition(i, j);
					cout << " ";
				}
			}
			else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type == 2)//moster����1�ƶ������ƣ���֤��һ��paintlevelbackground����paint��һ��moster
			{


				if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 2)
				{
					int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
					moster2_in[t1].InitialEdge(i, j);
					if (moster2_in[t1].GetMax_R() < 160 - 2 && moster2_in[t1].GetMax_L() > 0 + 2 && moster2_in[t1].GetMax_D() < 40 - 2 && moster2_in[t1].GetMax_U() > 2)
					{

						if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 4)//����
						{

							moster2_in[t1].PaintMoster(i, j, 2);
							background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num++;

							if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num >= background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].Totalmove_num)
							{
								//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
								background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 3;

							}
							//	else
							//	{
							CopyBackGroudPoint(i, j, i + 1, j);
							initialBackGroundPoint(i, j);
							//}
							//	mosterin[0]->PaintMoster(i, j);
							int t = 0; int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{

								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);

								if (i >= moster2_in[t1].GetMax_L() && i <= moster2_in[t1].GetMax_R())
								{
									t++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{

								if (i >= moster2_in[t1].GetMax_U() && i <= moster2_in[t1].GetMax_D())
								{
									t++;
									break;
								}
							}
							if (t == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 2);
							}
							//	}

						}
					}
				}
				else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 1)
				{
					int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
					moster1_in[t1].InitialEdge(i, j);
					if (moster1_in[t1].GetMax_R() < 160 - 2 && moster1_in[t1].GetMax_L() > 0 + 2 && moster1_in[t1].GetMax_D() < 40 - 2 && moster1_in[t1].GetMax_U() > 2)
					{

						if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 1)
						{

							//int t = j ++;

							moster1_in[t1].PaintMoster(i, j, 1);

							background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num++;

							if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num > background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].Totalmove_num)
							{
								//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
								background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 2;
							}
							else {
							CopyBackGroudPoint(i, j, i, j + 1);
							initialBackGroundPoint(i, j);
							}
							//	mosterin[0]->PaintMoster(i, j);
							int t = 0; int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{

								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);

								if (i >= moster1_in[t1].GetMax_L() && i <= moster1_in[t1].GetMax_R())
								{
									t++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{

								if (i >= moster1_in[t1].GetMax_U() && i <= moster1_in[t1].GetMax_D())
								{
									t++;
									break;
								}
							}
							if (t == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 2);
							}
						}

					}
				}
				else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 4)
				{
					int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
					moster4_in[t1].InitialEdge(i, j);
					if (moster4_in[t1].GetMax_R() < 160 - 2 && moster4_in[t1].GetMax_L() > 0 + 2 && moster4_in[t1].GetMax_D() < 40 - 2 && moster4_in[t1].GetMax_U() > 2)
					{

						if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to == 1)
						{

							//int t = j ++;

							moster4_in[t1].PaintMoster(i, j, 1);

							background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num++;

							if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_num > background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].Totalmove_num)
							{
								//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].Totalmove_num;
								background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].move_to = 2;
							}
							else {
								CopyBackGroudPoint(i, j, i, j + 1);
								initialBackGroundPoint(i, j);
							}
							//	mosterin[0]->PaintMoster(i, j);
							int t = 0; int t1 = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
							for (int i = man_in.GetL_edge(); i <= man_in.GetR_edge(); i++)
							{

								//moster1_in.WrapMoster(i, j - 2);
								//moster1_in.WrapMoster(i, j+2);

								if (i >= moster4_in[t1].GetMax_L() && i <= moster4_in[t1].GetMax_R())
								{
									t++;
									break;
								}
							}
							for (int i = man_in.GetU_edge(); i <= man_in.GetD_edge(); i++)
							{

								if (i >= moster4_in[t1].GetMax_U() && i <= moster4_in[t1].GetMax_D())
								{
									t++;
									break;
								}
							}
							if (t == 2)	//if(i<28&&j<28)
							{
								man_in.SetBlood(man_in.GetBlood() - 2);
							}
						}

					}
				}


			}
			else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 3)//3 ΪNPC
			{
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 1)//�ش������NPC
					{
						
						npc1.SetL1(jg1[0].GetLight()); npc1.SetL2(jg1[1].GetLight()); npc1.SetL3(jg1[2].GetLight());
						npc1.SetL4(jg1[3].GetLight()); npc1.SetL5(jg1[4].GetLight()); npc1.SetL6(jg1[5].GetLight());
						//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].cna_Paint = 1;
						//GSetConsoleAttribute(background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].color);
						npc1.SetEdge(i, j);
						if (npc1.GetMaxL_edge() > 0 && npc1.GetMaxR_edge() < 160 && npc1.GetMaxU_edge() > 0&&npc1.GetMaxD_edge()<40)
						 npc1.PaintNPC(i, j);
						//cout << "#";
						//int t = 0;
						
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 2)//�ṩ�鱨��NPC
					{
						//GSetConsoleAttribute(background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].color);
						npcmoniter[1]->PaintNPC(i, j);
						//cout << "#";
						int t = 0;
						if (npcmoniter[1]->IsTalk(man_in))
						{
							npcmoniter[1]->PaintTalk();//����Ի�
													   //�����ƶ�һС��֤���������ѭ��
							while (true)
							{
								if (GetAsyncKeyState(VK_RETURN))break;
							}
							if (man_in.GetR_edge() == npcmoniter[0]->GetMaxL_edge() - 1)
							{
								background[man_in.GetCurrentLevel() ].Max_left--;
								background[man_in.GetCurrentLevel() ].Max_right--;
								if (GetAsyncKeyState(VK_LEFT)) {}
							}
							else if (man_in.GetL_edge() == npcmoniter[0]->GetMaxR_edge() + 1)
							{

								background[man_in.GetCurrentLevel() ].Max_left++;
								background[man_in.GetCurrentLevel() ].Max_right++;
								if (GetAsyncKeyState(VK_RIGHT)) {}

							}
							RenewTheScreen();
							//WrapLevelBackground();
							PaintLevelBackground(man_in,0);

							//GReadAndWrite();
						}//break;
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 3)//������NPC
					{
						//GSetConsoleAttribute(background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].color);
						npcmoniter[2]->PaintNPC(i, j);
						Sleep(100);
						if (GetAsyncKeyState(VK_RETURN))//���ڵ�����һ�εİ���enter
						{

						}
						//cout << "#";
						int t = 0;
						if (npcmoniter[2]->IsTalk(man_in))
						{
							npcmoniter[2]->PaintTalk();//����Ի�
													   //�����ƶ�һС��֤���������ѭ��
							while (true)
							{
								Sleep(100);
								if (GetAsyncKeyState(VK_RETURN))break;
							}
							if (man_in.GetR_edge() == npcmoniter[0]->GetMaxL_edge() - 1)
							{
								background[man_in.GetCurrentLevel() ].Max_left--;
								background[man_in.GetCurrentLevel() ].Max_right--;
								if (GetAsyncKeyState(VK_LEFT)) {}
							}
							else if (man_in.GetL_edge() == npcmoniter[0]->GetMaxR_edge() + 1)
							{

								background[man_in.GetCurrentLevel() ].Max_left++;
								background[man_in.GetCurrentLevel() ].Max_right++;
								if (GetAsyncKeyState(VK_RIGHT)) {}

							}
							RenewTheScreen();
							//WrapLevelBackground();
							PaintLevelBackground(man_in,0);

							//GReadAndWrite();
						}//break;
						 //NPC����Ի���ʵ��//���ǻ�������˰ɶ�Ӹ���
					}
			}
		}
	}
	
		SetConsoleTextAttribute(Ghout, 128);
}

void CopyBackGroudPoint(/*Background background */int x1, int y1, int x2, int y2)
{
	
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].Blood = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].Blood;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].can_move = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].can_move;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].color = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].color;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].innner_type = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].innner_type;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].move_num = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].move_num;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].move_to = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].move_to;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].paint_type = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].paint_type;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].Totalmove_num = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].Totalmove_num;
		background[man_in.GetCurrentLevel() ].backgroundmod[x2 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y2].cna_Paint = background[man_in.GetCurrentLevel() ].backgroundmod[x1 + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y1].cna_Paint;
		
	
}
void initialBackGroundPoint(/*Background background*/int x, int y)
{
		background[man_in.GetCurrentLevel() ].backgroundmod[x + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y].paint_type = 0;
		
}
//�ж����������Ƿ����
void LifeJudge(Man & man_in)
{
	GetLocalTime(&sys);
      int Gtime = sys.wMinute;
	if (Gtime > man_in.GetGameStartTime())
	{
		man_in.SetLife(man_in.GetLife() + Gtime - man_in.GetGameStartTime());
	}
	else if (Gtime < man_in.GetGameStartTime())
	{
		man_in.SetLife(man_in.GetLife() + Gtime + 60 - man_in.GetGameStartTime());
	}
	man_in.SetGameStartTime(Gtime);
	if (man_in.GetLife() >= 49)
	{
		InitBackground(man_in.GetCurrentLevel());
		man_in.SetLife(0);
		man_in.PaintManDie();
		man_in.NewLife();
		man_in.RunManDie();
		RenewTheScreen();
	}
	if (man_in.GetBlood() <= 0)
	{
		InitBackground(man_in.GetCurrentLevel());
		man_in.SetLife(0);

		man_in.PaintManDie();
		
		man_in.NewLife();
		man_in.RunManDie();
		RenewTheScreen();
		PaintLevelBackground(man_in, 0);
		
	}

}
int GetBackGroundPoint(int x, int y)
{
	
		 if (background[man_in.GetCurrentLevel() ].backgroundmod[x + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y].paint_type == 2)//����
		{
			return 0;
		}
		else
		{

		}
		return background[man_in.GetCurrentLevel() ].backgroundmod[x + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - y].color;
		
}

//���õ����Ϣ
void SetBackgrouundPoint(int x, int y, int Painttype, int innerType, int can_move, int move_to, int Blood, int totalmoveNum, int movenum, int color, int canpaint)
{
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type=Painttype;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = innerType;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].can_move=can_move;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].move_to = move_to;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].Blood = Blood;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].Totalmove_num = totalmoveNum;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].move_num = movenum;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = color;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].cna_Paint = canpaint;

}


void WrapLevelBackground(int direction)//direction �������һ���ϰ��1 ��������� 2 ���Ҽ���ұ� 30������ ����ϱ� 31 ���� 32 ���� 40 �¼���±ߣ�41 ���£�42 ����
{

	man_in.WrapBlood();
	
		for (int i = 0; i<160; i++)
		{
			for (int j = 0; j < 40; j++)
			{
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type== 1
						|| background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].paint_type == 6)//һ���ϰ���
					{
						//GSetConsoleAttribute(128);
						if (direction == 0)
						{
							SetConsolePosition(i, j); cout << " ";
						}
						else if (direction == 1)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left - man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type!=1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left - man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j].paint_type != 6)// ||
								//background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left + man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 0)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						if (direction == 2)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left +man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type !=1
								&&background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left + man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type !=6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 30)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j+man_UDnum].paint_type!=1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j + man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 31)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left-man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left - man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j + man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 32)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left +man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j + man_UDnum].paint_type != 1
								&&background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left + man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j + man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 40)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j -man_UDnum ].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 41)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left-man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j - man_UDnum].paint_type != 1
								&&background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left - man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}
						else if (direction == 42)
						{
							if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left + man_RLnum][background[man_in.GetCurrentLevel() ].Max_up - j - man_UDnum].paint_type != 1
								&& background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left + man_RLnum][background[man_in.GetCurrentLevel()].Max_up - j - man_UDnum].paint_type != 6)
							{
								SetConsolePosition(i, j);
								cout << ' ';
							}
						}

				}

					//��wrapmosterʱҪ��һ�����
				else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 2)//moster
				{
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 1)
					{
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						//moster1_in.WrapMoster(i, j - 2);
						//moster1_in.WrapMoster(i, j+2);
						moster1_in[t].WrapMoster(i, j - 1);
						moster1_in[t].WrapMoster(i, j + 1);
						moster1_in[t].WrapMoster(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 2)
					{
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						//moster2_in[t].WrapMoster(i, j - 2);
						//moster2_in[t].WrapMoster(i, j+2);
						moster2_in[t].WrapMoster(i, j - 1);
						moster2_in[t].WrapMoster(i, j + 1);
						moster2_in[t].WrapMoster(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 3)
					{
						moster3_in.WrapMoster(i, j);
					}
					else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 4)
					{
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						//moster2_in[t].WrapMoster(i, j - 2);
						//moster2_in[t].WrapMoster(i, j+2);
						moster4_in[t].WrapMoster(i, j - 1);
						moster4_in[t].WrapMoster(i, j + 1);
						moster4_in[t].WrapMoster(i, j);
					}
				}
				else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 3)//NPC
				{
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 1)
					{
						SetConsolePosition(i, j);
						npc1.WrapNPC(i, j);
					}
				}
				else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].paint_type == 4)//����
				{
					GSetConsoleAttribute(128);
					if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 1) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;

							jg1[t-1].WrapJigung(i, j);


					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 2)
					{
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						if(jg2[t].GetMaxR_edge()<160)
						jg2[t].WrapJigung(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 3) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						if (jg3[t].GetMaxR_edge()<160)
						jg3[t].WrapJigung(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 4) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						if (jg4[t].GetMaxR_edge()<160)
						jg4[t].WrapJigung(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 5) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						jg5[t].WrapJigung(i, j);
					}
					else if (background[man_in.GetCurrentLevel() ].backgroundmod[i + background[man_in.GetCurrentLevel() ].Max_left][background[man_in.GetCurrentLevel() ].Max_up - j].innner_type == 6) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						jg6[t].WrapJigung(i, j);
					}
					else if (background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].innner_type == 7) {
						int t = background[man_in.GetCurrentLevel()].backgroundmod[i + background[man_in.GetCurrentLevel()].Max_left][background[man_in.GetCurrentLevel()].Max_up - j].inner_type2;
						jg7[t].WrapJigung(i, j);
					}
				}
			
			}
		}

}

enum StopMenue{ Return_game,Save_record,Read_record,MainMenue,Stop_help};
int RunStopMenue(Man& man_in)
{
	RenewTheScreen();
	//WrapLevelBackground();
	int Currentb = 1;int t = 0;
	while (true)
	{
		if (Currentb == 0)break;
		SetConsoleTextAttribute(Ghout, 128);
	//	WrapLevelBackground();
		RenewTheScreen();
		PaintStopMenue();
		PaintChose(0);
		for (int i = 0; i < 40; i++)
		{
			SetConsolePosition(75, i);
			cout << "|";
		}
		//����
		GSetConsoleAttribute(128);
		
		
		man_in.PaintMessage();
		GReadAndWrite();
		int CurrentStopId = 0;
		while (true)
		{
			Sleep(200);
			if (GetAsyncKeyState(VK_DOWN))
			{
				WrapPaintChose(CurrentStopId);
				CurrentStopId++;
				if (CurrentStopId > 4)
					CurrentStopId = 0;

			}
			else if (GetAsyncKeyState(VK_UP))
			{
				WrapPaintChose(CurrentStopId);
				CurrentStopId--;
				if (CurrentStopId < 0)
					CurrentStopId = 4;
			}
			else if (GetAsyncKeyState(VK_RETURN))
			{
				
				break;
			}
			PaintChose(CurrentStopId);
			switch (man_in.GetDao())
			{
			case 0:
				if (t == 0)
				{
					man_in.Paintworld_1_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_1_man_R2(10, 10);
					t = 0;
				}
				break;
			case 1:
				if (t == 0)
				{
					man_in.Paintworld_2_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_2_man_R2(10, 10); t = 0;

				}
				break;
			case 2:
				if (t == 0)
				{
					man_in.Paintworld_3_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_3_man_R2(10, 10); t = 0;
				}
				break;
			case 3:
				if (t == 0)
				{
					man_in.Paintworld_4_man_R(10, 10);
					t = 1;
				}
				else if (t == 1)
				{
					man_in.Paintworld_4_man_R2(10, 10); t = 0;
				}
				break;
			}
			GReadAndWrite();
		}
		WrapStopMenue();
		WrapPaintChose(CurrentStopId);
	
		GReadAndWrite();
		switch (CurrentStopId)
		{
		case Return_game:
			//RenewTheScreen();
			//PaintLevelBackground(man_in, 0);
			//GReadAndWrite();
		Currentb = 0;
			//�������˵�
			//RunStartMenue(StartCurrentID );
			break;
		case Save_record:
			WrapStopMenue();
			
			PiantReadRecordMenue();
			GReadAndWrite();

			while (RunSeletSave())
			{
				int light[7];
				int Switch[7];
				
				ofstream MyRecord(Record + MyRecordID[CurrentRecord], ios::binary);
			
				MyRecord.write(reinterpret_cast<const char*>(&man_in), sizeof(Man));
				MyRecord.write(reinterpret_cast<const char *>(&background[man_in.GetCurrentLevel() ]), sizeof(Background));
				
				for (int i = 0; i <6; i++)
				{
						light[i] = jg1[i].GetLight();
					MyRecord.write(reinterpret_cast<const char *>(&light[i]), sizeof(int));
				}
				
				for (int i = 0; i <6; i++)
				{
					Switch[i] = jg7[i].GetState();
					MyRecord.write(reinterpret_cast<const char *>(&Switch[i]), sizeof(int));
				}

				MyRecord.close();
			
				RenewTheScreen();
				//WrapPaintChose(CurrentRecord);
				//WrapReadRecordMenue();
				GReadAndWrite();
				
				SetConsolePosition(50, 20);
				cout << "�浵�ɹ�";
				GReadAndWrite();
				Sleep(1000);
				SetConsolePosition(50, 20);
				cout << "       ";
				GReadAndWrite();
			}
			
			Currentb = 1;
			break;
		case Read_record:
			//WrapStopMenue();
			RenewTheScreen();
			PiantReadRecordMenue();
			GReadAndWrite();
			if (RunSeletSave())
			{
				int light[7];
				int Switch[7];
				int State;
				ifstream MyRecord1(Record + MyRecordID[CurrentRecord],ios::binary);
				

					MyRecord1.read(reinterpret_cast<char*>(&man_in), sizeof(Man));
 





					MyRecord1.read(reinterpret_cast<char*>(&background[man_in.GetCurrentLevel()]), sizeof(Background));

					for (int i = 0; i < 6; i++)
					{
						MyRecord1.read(reinterpret_cast<char*>(&light[i]), sizeof(int));
						//	jg11.SetLight(light[i]);
						jg1[i].SetLight(light[i]);
					}
					for (int i = 0; i < 6; i++)
					{
						MyRecord1.read(reinterpret_cast<char*>(&Switch[i]), sizeof(int));
						//	jg11.SetLight(light[i]);
						jg7[i].setstate(Switch[i]);
					}

					MyRecord1.close();
					Currentb = 0;
					return 2;
				
			}

			GetLocalTime(&sys);
			man_in.SetGameStartTime(sys.wMinute);
		
			break;
		case MainMenue:
			return 1;
			break;
		case Stop_help:
			GSetConsoleAttribute(0);
			RenewTheScreen();
			GSetConsoleAttribute(15);
			SetConsolePosition(20, 10);
			cout << "������������������� ";
			SetConsolePosition(20, 11);
			cout << "�ո���˳� ���س�����";
			SetConsolePosition(20, 12);
			cout << "���������Ϸ���й��������ڵ�Դѡ����ѡ�������";
			GReadAndWrite();
			while (1)
			{
				Sleep(100);
				if (GetAsyncKeyState(VK_SPACE))
				{
					break;
				}
			}
			GSetConsoleAttribute(128);
			break;
		}
		RenewTheScreen();
		GReadAndWrite();
		
	}
	return 0;
}

//���ٶ�����̫���ˣ�Ҫ���е���
void JumpUpAndRight(Man&man_in)
{
	//man_in.Paintman(man_x, man_y, 2);
	for (int i = 0; i < 10; i++)//�����1�ٶȵ�����
	{
		man_in.Paintman(man_x, man_y, 2);

		if (!IsStopRightAndUp(man_in))
		{
			WrapLevelBackground(32);
			for (int i = 0; i < man_RLnum; i++)
			{
				//if (!IsStopRight(man_in))
				b_1_ManMoveRight();
			}
			for (int i = 0; i < man_UDnum; i++) {
				//if (!IsStopUp(man_in))
				b_1_ManMoveUp();
			}
			PaintLevelBackground(man_in, 32);
			man_in.Paintman(man_x, man_y, 3);
			GReadAndWrite();
		}
	}

	//Sleep(50);
	int t = 0;
		while (!IsStopRightAndDown(man_in))
		{
			t++;
			if (t >= 16)break;
			WrapLevelBackground(42);
			for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
			for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown(); //WrapLevelBackground();
              PaintLevelBackground(man_in,42); 
		  man_in.Paintman(man_x, man_y, 3);
		   GReadAndWrite();
		}
		while (!IsStopDown(man_in))
		{
			WrapLevelBackground(40);
			//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
			for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown();
			PaintLevelBackground(man_in,40);
			man_in.Paintman(man_x, man_y, 3);
			GReadAndWrite();
		}

}
void JumpUpAndLeft(Man&man_in)
{
	
	int t = 0;
	for (int i = 0; i < 10; i++)//�����1�ٶȵ�����
	{
		man_in.Paintman(man_x, man_y, 1);
		
		if (!IsStopLeftAndUp(man_in))
		{
              WrapLevelBackground(31);
			  for (int i = 0; i < man_RLnum; i++)b_1_ManMoveLeft();
			  for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
         PaintLevelBackground(man_in,31);
            	man_in.Paintman(man_x, man_y, 3);
		 GReadAndWrite();
		}
		//man_in.Painman(29, 29);
	
		
	}
	//Sleep(50);

	
	//Sleep(50);
	t = 0;
	while (!IsStopLeftAndDown(man_in))
	{
		t++;
		if (t >= 16)break;
		WrapLevelBackground(41);
		for (int i = 0; i < man_RLnum; i++)b_1_ManMoveLeft();
		for (int i = 0; i < man_UDnum; i++)b_1_ManMoveDown();
		PaintLevelBackground(man_in,41);
		man_in.Paintman(man_x, man_y, 3);
		GReadAndWrite();
	}

		//man_in.Painman(29, 29);
		
	
	while (!IsStopDown(man_in))
	{
		WrapLevelBackground(40);
	
		//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
		for (int i = 0; i < man_UDnum; i++)	//if (!IsStopDown(man_in))
			b_1_ManMoveDown();
		PaintLevelBackground(man_in,40);
		man_in.Paintman(man_x, man_y, 3);
		GReadAndWrite();
	}
	//t = 0;

}

void RunRight(Man&man_in)
{
	int t = 0;

	if (!IsStopRight(man_in))
	{
		WrapLevelBackground(2);
		for (int i = 0; i < man_RLnum; i++)
		{
			//if (!IsStopRight(man_in))
			b_1_ManMoveRight();

		}

		//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
		PaintLevelBackground(man_in, 2);
		man_in.Paintman(man_x, man_y, 2);
		//	cout << endl;
		GReadAndWrite();
	}

		
		//�˴�Ϊ���������ķ�����ʱ����������������������֮��Ҫ�ǵû�ԭ
	t = 0;
		while (!IsStopRightAndDown(man_in))
		{
			t++;
			if (t >= 3)break;
			WrapLevelBackground(42);
			
			for (int i = 0; i < man_RLnum; i++)
			{
				//if (!IsStopRight(man_in))
				b_1_ManMoveRight();
			}
			for (int i = 0; i < man_UDnum; i++)
			{
				//if (!IsStopDown(man_in))
				b_1_ManMoveDown();
			}
				 PaintLevelBackground(man_in,42);
				// PaintLevelBackground(man_in, 41);
			man_in.Paintman(man_x, man_y, 2);// cout << endl;
			GReadAndWrite();//Sleep(50);
		}
			while (!IsStopDown(man_in))
			{
				//t++;
				//if(t%2==0)
				WrapLevelBackground(40);
				//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
				for (int i = 0; i < man_UDnum; i++)
				{
					//if(!IsStopDown(man_in))
					b_1_ManMoveDown();
				}
				//if (t % 2 == 0);
				
					PaintLevelBackground(man_in, 40);
					man_in.Paintman(man_x, man_y, 2); //cout << endl;

				
				GReadAndWrite();
			}
		
}
	

void RunLeft(Man&man_in)
{
	int t = 0;

	if (!IsStopLeft(man_in))
	{
		WrapLevelBackground(1);
		for (int i = 0; i < man_RLnum; i++)
		{
			//if (!IsStopLeft(man_in))
			b_1_ManMoveLeft();
		}
		//for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveUp();
		PaintLevelBackground(man_in,1);
		man_in.Paintman(man_x, man_y, 1);


		GReadAndWrite();
	}
		//Sleep(50);
		//�˴�Ϊ���������ķ�����ʱ����������������������֮��Ҫ�ǵû�ԭ
	 t = 0;
		while (!IsStopLeftAndDown(man_in))
		{
			t++;
			if (t >= 3)break;
			WrapLevelBackground(41);
			
			for (int i = 0; i < man_RLnum; i++)
			{
				//if (!IsStopLeft(man_in))
				b_1_ManMoveLeft();
			}
			for (int i = 0; i < man_UDnum; i++) {
				b_1_ManMoveDown(); }

			PaintLevelBackground(man_in,41);
			man_in.Paintman(man_x, man_y, 1);
			GReadAndWrite();//Sleep(50);
		}
		while (!IsStopDown(man_in))
		{
			WrapLevelBackground(40);

			//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
			for (int i = 0; i < man_UDnum; i++)
			{
				//if (!IsStopDown(man_in))
				b_1_ManMoveDown();
			}

			PaintLevelBackground(man_in,40);
			man_in.Paintman(man_x, man_y, 1);
			GReadAndWrite();
		}
}
void JumpUp(Man&man_in)
{
	int t = 0; 
	for (int i = 0; i < 10; i++)
	{
		if (!IsStopUp(man_in))
		{
			WrapLevelBackground(30);

			//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
			for (int i = 0; i < man_UDnum; i++)
			{
				//if (!IsStopUp(man_in))
				b_1_ManMoveUp();
			}

			PaintLevelBackground(man_in,30);
			man_in.Paintman(man_x, man_y, 3);
			GReadAndWrite();
		}
	}
		
		//b_1_ManMoveRight();
		
	
		//Sleep(50);
		
		if (GetAsyncKeyState(VK_UP))
		{
			for (int i = 0; i < 3; i++)
			{
				if (!IsStopUp(man_in))
				{
					WrapLevelBackground(30);

					//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
					for(int i = 0; i < man_UDnum; i++) {
						b_1_ManMoveUp();
					}
					PaintLevelBackground(man_in,30); man_in.Paintman(man_x, man_y, 3);
					GReadAndWrite();

				}
			}
			//WrapLevelBackground();
			
		}
		
		//�˴�Ϊ���������ķ�����ʱ����������������������֮��Ҫ�ǵû�ԭ
	
		while (!IsStopDown(man_in))
		{
			
			WrapLevelBackground(40);
			//for (int i = 0; i < man_RLnum; i++)b_1_ManMoveRight();
			for (int i = 0; i < man_UDnum; i++)	b_1_ManMoveDown();

			PaintLevelBackground(man_in,40);
			man_in.Paintman(man_x, man_y, 3);
			
			GReadAndWrite();
		}
}
void InitBackground(int Level)
{
	switch (Level)
	{
	case Level_1:
		GreatGameLevel_1();
		background[0].Max_x = 1350;
		background[0].Max_y = 160;
		background[0].Max_up = 60;
		background[0].Max_left = 30;
		background[0].Max_right = 160 + 30;
		background[0].Max_down = 20;
		
	
		break;
	case Level_2:
		GreatGameLevel_2();
		background[1].Max_x = 1350;
		background[1].Max_y = 160;
		background[1].Max_up = 60;
		background[1].Max_left= 15;
		background[1].Max_right = 160 + 15;
		background[1].Max_down = 60;
		break;
	case Level_3:
		background[2].Max_x = 1350;
		background[2].Max_y = 160;
		background[2].Max_up = 60;
		background[2].Max_left = 30;
		background[2].Max_right = 160 +30;
		background[2].Max_down = 20;
		GreatGameLevel_3();
		break;
	case Level_4:
		background[3].Max_x = 1350;
		background[3].Max_y = 160;
		background[3].Max_up = 60;
		background[3].Max_left = 20;
		background[3].Max_right = 160+20;
		background[3].Max_down =20;
		GreatGameLevel_4();
		break;
	case Level_5:
		background[4].Max_x = 1350;
		background[4].Max_y = 500;
		background[4].Max_up = 110;
		background[4].Max_left = 430;
			background[4].Max_right = 160 +430;
		background[4].Max_down = 70;
		GreatGameLevel_5();
		break;
	case Level_6:
		background[5].Max_x = 1300;
		background[5].Max_y = 300;
		background[5].Max_up = 90;
		background[5].Max_left = 30;
		background[5].Max_right = 160+30;
		background[5].Max_down = 50;
		GreatGameLevel_6();
		break;
	}
}
/*��������1�ı���*/
//���gamelevel 1
//level 1 ��level 2 �� ����Ҫ�����Ż�
//���Ĳ���
void GreatGameLevel_1()//�ؿ��Ĵ���Ҫ���մ����Ҵ��µ��ϵĹ���
{
	
//���վ̨
PaintFangkuai(0, 1000, 29, 0);
PaintFangkuai(0, 30, 100, 0);
//����վ̨
PaintFangkuai(50, 65, 30, 29);
PaintFangkuai(50 - 2, 65 + 2, 31, 30);

for (int i = 0; i < 10; i++)
{
	PaintFangkuai(30, 40-i, 30 + i, 29 + i);

}
PaintFangkuai(0, 34, 40, 28);
for (int i = 0; i < 20; i++)
{
	PaintFangkuai(30, 32 + i, 40 + i, 39 + i);
}
PaintFangkuai(30, 45, 70, 45);
PaintFangkuai(30, 65, 100, 55);
WrapFangkuai(45, 49, 65,61);
WrapFangkuai(35, 39, 55, 51);
PaintFangkuai(30, 70, 100, 70);
//�ұ�
WrapFangkuai(65, 250, 29, 28);
WrapFangkuai(100, 210, 28, 27);

WrapFangkuai(280, 310, 28, 10);
WrapFangkuai(280+1, 310-2, 30, 28);
PaintFangkuai(310-2, 320, 30, 28);
int B = 0;
for (int i = 0; i < 3; i++)
{
	PaintBox(280+i*10, 25, B); B++;
	PaintBox(280 + i * 10, 21, B); B++;
}
PaintFangkuai(310 - 1, 370, 30, 29);
WrapFangkuai(370, 415, 29, 13);
WrapFangkuai(370 - 4, 370, 28, 13);

//�����ұߵ�box
for (int i = 0; i < 3; i++)
{
	PaintBox(370 - 4, 26-4*i, B); B++;
	PaintBox(380 - 5, 26-4*i, B); B++;
}
//��1
PaintDeng(370 - 4, 30, 1);
int DC = 0;
for (int i = 0; i < 8; i++)
{
	PaintDici(414 - 10, 22-i, DC); DC++;
}
//��u
PaintFangkuai(415 - 2, 530, 30, 29);
PaintFangkuai(500, 505, 40, 30);
PaintFangkuai(510, 515, 40, 30); 
PaintFangkuai(500, 515, 42, 40);

PaintFangkuai(515, 600, 34, 29);
PaintFangkuai(470, 485, 41, 40);
PaintFangkuai(600, 650, 40, 29);
PaintFangkuai(600 +1, 650, 40, 40-1);
PaintFangkuai(90, 105, 37, 36);
//��2
PaintDeng(640, 40, 2);
WrapFangkuai(650, 700-10, 30, 13);
PaintFangkuai(130, 145, 42, 41);
//����
int T = 0;
for (int i = 0; i < 10; i++)
{
	PaintTrap(651 + i * 4, 20, T); T++;
	PaintTrap(651 + i * 4, 14, T); T++;
}

for (int i = 0; i < 6; i++)
{
	PaintBox(132, 42 + 4+i*4, B); B++;
}
for (int i = 0; i < 7; i++)
{
	PaintBox(152+i*45, 69, B); B++;
	PaintBox(162 + i *45, 69, B); B++;
}
PaintBox(450, 69, B); B++;
PaintBox(460, 69, B); B++;
PaintFangkuai(0, 1000, 100, 85);
//��3
PaintDeng(780, 29, 3);
PaintFangkuai(740, 755, 38, 37);
PaintFangkuai(830, 900, 45, 29);
PaintFangkuai(900, 950, 39, 29);
PaintFangkuai(774, 790, 46, 45);
PaintFangkuai(1000, 1300, 20, 0);
//��4
PaintDeng(890, 45, 4);
//����
for (int i = 0; i < 3; i++)
{
	PaintDici(900+i*10, 39, DC); DC++;
	PaintDici(900 + i * 10, 40, DC); DC++;
}
PaintFangkuai(930, 1040, 41, 29);
PaintFangkuai(950, 1040, 45, 41);
PaintFangkuai(980, 1010, 52, 45);
//��5
PaintDeng(1030, 45, 5);
PaintFangkuai(1040, 1140, 36, 25);
PaintFangkuai(1140, 1200, 40, 29);
//moater
PaintMosterLR(1060, 38, 1, 2, 30);
//��6
PaintDeng(1080, 36, 6);

PaintFangkuai(1060, 1075, 51, 50);
PaintFangkuai(1100, 1300, 56, 0);
PaintFangkuai(1150, 1300, 100, 66);
}
//den3

//���gamelevel 1
void GreatGameLevel_2()//����2
{
	PaintFangkuai(0, 20, 100, 0);
	PaintFangkuai(10, 1000, 20, 0);
	PaintFangkuai(380, 1000, 160, 110);
	/////
	
	//
	/////////////////////////////////
PaintFangkuai(26, 90, 28, 20);
	PaintFangkuai(40-2,50-2, 31,26);
	PaintFangkuai(40-4-2-6, 50+4-2, 29, 28);
	PaintFangkuai(10, 26, 40, 20);
	////////////////////////////////
	PaintFangkuai(10, 30, 43, 40);
	PaintFangkuai(10, 28, 46, 43);
	PaintFangkuai(10, 40, 100, 40);
	for (int i = 0; i < 6;i++)
	PaintFangkuai(10, 29+i*2, 47+i, 46+i);
	for (int i = 0; i < 20; i++)
	PaintFangkuai(10, 60,44+i, 43+i);
	for (int i = 0; i < 2; i++)////�Ϸ�
		PaintFangkuai(60, 90, 44 + i, 43+ i);
	int Y = 0;

	//�ҽ�
	for (int i = 0; i <= 3; i++)
	{
		PaintYanjiang(90+i*10, 20, Y);
		Y++;
	}
	PaintFangkuai(132, 170, 37, 20);
	for (int i = 0; i < 2; i++)////�Ϸ�
		PaintFangkuai(105, 170, 36+i, 35 + i);
	PaintFangkuai(140, 180, 50, 20);
	PaintFangkuai(120, 180, 54, 50);
	PaintFangkuai(110, 180, 54, 52);
	////��
	int D = 1;
	PaintDeng(130, 54, D); D++;

	PaintFangkuai(170, 180, 65, 0);
	PaintFangkuai(0, 200, 120, 90);
	////box
	int B = 0;
	PaintBox(170 - 10, 54+4, B); B++;
	PaintBox(170 - 10, 54 + 8, B); B++;
	PaintBox(170 - 10, 54 + 12, B); B++;
	PaintBox(170 - 10, 54 + 16, B); B++;
	PaintBox(170 - 10, 54 + 20, B); B++;
	//box���ұ�
	PaintFangkuai(80, 170 - 10 - 1, 54 + 19, 54 + 10);
	//��Ծyong
	PaintFangkuai(210, 225, 65, 64);
	PaintFangkuai(180, 252, 44, 20);
	PaintFangkuai(252, 257, 54, 20);
	PaintFangkuai(257, 400, 48, 20);
	//�ҽ�
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 1; j++)
		{
	PaintYanjiang(180+i*10, 44+j*4, Y); Y++;
		}
	}
	//��
	PaintDeng(254, 54, D); D++;
	//box
	PaintBox(257, 48+ 4, B); B++;
	PaintBox(257+8, 48 + 4, B); B++;
	//xianj
	int C = 0;
	PaintDici(257 + 10+8, 48, C); C++;
	//box
	PaintBox(257+20+8, 48 + 4, B); B++;
	//PaintBox(257+36, 48 + 4, B); B++;
	PaintFangkuai(275 + 20, 275 +20+15, 48 + 6, 48);
	PaintFangkuai(310, 310 + 10, 48 + 27, 48);
	//Box
	for (int i = 0; i < 7; i++)
	{
		PaintBox(275+24, 48 + 10+i*4, B); B++;
	}
	PaintFangkuai(275+24-40, 275+24, 48+52, 48+18);
	//moster
	PaintMosterLR(275 + 24 - 30, 48 + 52 + 3, 1, 2, 15);
	//den

	PaintDeng(275 + 24 - 30, 48 + 52, D); D++;

	PaintFangkuai(275 + 24 - 30-40, 275 + 24-30, 100, 48 + 30);

	PaintFangkuai(275, 310, 100, 85);
	PaintFangkuai(0, 400, 140, 120);
	//box
	for (int i = 0; i < 6; i++)
	{
		PaintBox(310, 48+31+i*4, B); B++;
	}
	PaintFangkuai(360, 350 + 40, 90, 20);
	////�����Ϲ�������
	PaintFangkuai(346,360, 55, 54);
	PaintFangkuai(315, 326, 63, 62);
	PaintFangkuai(346, 360, 70, 69);
	//
	PaintDeng(365, 90, D); D++;
	//����
	PaintDici(320, 48, C); C++;
	PaintDici(330, 48, C); C++;
	PaintDici(340, 48, C); C++;
	//����
	int CL = 0;
	for (int i = 0; i < 5; i++)
	{
		PaintChilun(390 + 4+i*5, 65, CL); CL++;
	}
	for (int i = 0; i < 7; i++)
	{
		PaintChilun(390 + 4 + i * 5, 62, CL); CL++;
	}
	//////////////////////////////
	//��Ծ
	PaintFangkuai(410, 420, 85,84);
	PaintFangkuai(430 + 32+20, 500, 85, 84);
	//PaintFangkuai(430 + 32 + 40, 520, 78, 77);
	//
	PaintFangkuai(380, 430 + 32, 60 ,20);
	PaintFangkuai(418, 430 + 32, 75, 20);
	//chilun
	PaintChilun(468, 36, CL); CL++;
	PaintFangkuai(430, 430 + 32, 80, 20);
	PaintFangkuai(430 + 32,480, 35, 20);
	PaintFangkuai(480, 490, 40, 20);
	//box
	PaintBox(480, 40 + 4, B); B++;
	PaintBox(480, 40 + 8, B); B++;
	PaintBox(480, 40 + 12, B); B++;
	//��
	PaintDeng(505, 50, D); D++;
	/////
	for (int i = 0; i < 5; i++)
	{
		PaintDici(380+i*10 , 20, C); C++;
	}
//
	int T=0;
	for (int i = 0; i < 3; i++)
	{
		PaintTrap(521, 21 + i * 8, T); T++;
		PaintTrap(525, 21+i*8, T); T++;
		PaintTrap(517, 26+i*8, T); T++;
	}
	//
	PaintDeng(440, 80, D); D++;
	for (int i = 0; i < 4; i++)
	{
		PaintBox(490, 50 + 4 + i * 4, B); B++;
	}
	PaintFangkuai(490, 490 + 25, 50, 20);

	PaintDici(490 + 25, 20, C); C++;
	PaintDici(490 + 25+2, 20, C); C++;
	PaintBox(530, 70+4, B); B++;
	PaintBox(530, 70+8, B); B++;
	PaintBox(530, 70 + 12, B); B++;
	PaintFangkuai(490+40, 700, 70, 20);
	PaintFangkuai( 700,1000, 140, 20);
	PaintFangkuai(700, 1000, 140, 20);
	PaintFangkuai(550, 700, 140, 80);

	//��һ������

}

void GreatGameLevel_3()//����3
{
	PaintFangkuai(0, 500, 29, 0);
	PaintFangkuai(0, 1000, 15, 0);
	PaintFangkuai(0, 40, 150, 0);
	for (int i = 0; i < 3; i++)
		PaintFangkuai(40, 50 - i, 30 + i, 29 + i);
	PaintFangkuai(40, 50 - 2, 150, 29 + 3);
	//��ʼ�������
	//վ̨
	PaintFangkuai(54, 64, 30, 29);
	PaintFangkuai(52, 66, 31, 30);
	//վ̨
	int CL = 0;
	for (int i = 0; i < 20; i++)
		PaintFangkuai(40, 48 + i, 38 + i, 37 + i);
	for (int i = 0; i < 20; i++)
		PaintFangkuai(40, 48 + 20, 38 + 19 + i, 37 + 19 + i);
	//chilun
	PaintChilun(66, 45, CL); CL++;
	PaintChilun(69, 43, CL); CL++;
	PaintChilun(62, 45, CL); CL++;
	PaintChilun(62, 42, CL); CL++;
	PaintChilun(57, 42, CL); CL++;
	//chilun
	//�����ұߵķ���
	PaintFangkuai(74, 120, 47, 43);
	PaintFangkuai(80, 120, 48, 47);
	PaintFangkuai(90, 105, 47, 33 + 1);
	PaintFangkuai(80, 111, 47, 39);
	//�������������
	int B = 0;
	PaintBox(95, 31 + 2, B); B++;
	//�����ұߵ�����
	for (int i = 0; i < 4; i++)
	{
		PaintBox(130, 31 + 2 + i * 4, B); B++;
	}
	PaintFangkuai(60, 90, 70, 60);
	PaintFangkuai(60, 100, 80, 70);

	PaintFangkuai(115, 140, 100, 58);
	PaintFangkuai(140, 200, 100, 55);
	PaintFangkuai(165, 300, 100, 50);
	PaintFangkuai(185, 300, 100, 45);
	PaintFangkuai(205, 300, 100, 40);
	PaintFangkuai(225, 300, 100, 35);
	//box
	PaintBox(225, 31 + 2, B); B++;
	PaintBox(225, 31 + 3, B); B++;
	WrapFangkuai(240, 285, 40, 35);
	WrapFangkuai(243, 315, 31, 26);
	PaintBox(290, 31 + 2, B); B++;
	PaintBox(290, 31 + 3, B); B++;
	PaintBox(290 - 1, 31, B); B++;
	//��1
	int D = 1;
	PaintDeng(115 - 4, 60, D); D++;
	//�����ϱߵĳ���
	PaintChilun(90 + 3, 70 - 3, CL); CL++;
	PaintChilun(90 + 3, 60, CL); CL++;
	PaintChilun(90 + 3 + 5, 65, CL); CL++;
	PaintChilun(90 + 3 + 5, 62, CL); CL++;
	PaintChilun(90 + 3 + 10, 65, CL); CL++;
	//PaintMosterLR(200, 13 + 3,1, 2,20);
	//GreatGameLevel_1();
	PaintFangkuai(335, 500, 35, 28);//�ұ�̨��
	PaintFangkuai(300, 315, 44, 43);
	PaintFangkuai(300, 313, 43, 42);//���̨��
	//��2
	PaintDeng(340, 35, D); D++;
	PaintFangkuai(360, 500, 51, 35);

	PaintFangkuai(340, 500, 51, 50);
	PaintFangkuai(342, 500, 50, 49);
	PaintFangkuai(344, 500, 49, 48);//����̨��
	for (int i = 0; i < 40; i++)
		PaintFangkuai(300, 310 + i * 10, 66 + i, 65 + i);
	//����
	PaintChilun(400, 51 + 12 + 10, CL); CL++;
	PaintChilun(409, 51 + 12 + 10, CL); CL++;
	//վ̨�Ϸ�
	PaintBox(400, 51 + 4, B); B++;
	PaintBox(400, 51 + 8, B); B++;
	PaintBox(400, 51 + 12, B); B++;
	//PaintBox(400-5, 51 + 14, B); B++;
	//�ұ�վ̨
	PaintFangkuai(420, 470, 67, 51);
	PaintFangkuai(470, 485, 64, 51);
	WrapFangkuai(471, 480, 60, 51);
	PaintFangkuai(480, 530, 49, 20);
	PaintFangkuai(480, 534, 51, 49);
	//deng3
	PaintDeng(510, 51, D); D++;
	//
	PaintChilun(470, 79, CL); CL++;
	PaintChilun(480, 79, CL); CL++;
	//վ̨�±�
	PaintFangkuai(530, 700, 30, 10);
	PaintFangkuai(565, 580, 34, 10);
	PaintFangkuai(545, 580, 32, 10);
	PaintFangkuai(560, 580, 36, 10);

	PaintChilun(530 + 5, 45, CL); CL++;
	PaintChilun(530 + 8, 45, CL); CL++;
	PaintChilun(530 + 8, 40, CL); CL++;
	PaintChilun(530 + 4, 40, CL); CL++;
	PaintChilun(530 + 8, 37, CL); CL++;
	PaintChilun(530 + 4, 37, CL); CL++;
	PaintChilun(530 + 8, 34, CL); CL++;
	PaintChilun(530 + 4, 34, CL); CL++;
	//�ұ�box
	PaintBox(610, 34, B); B++;
	PaintBox(610, 34 + 4, B); B++;
	PaintBox(610, 34 + 8, B); B++;
	PaintBox(610, 34 + 10, B); B++;
	PaintBox(610 - 4, 34 + 12, B); B++;
	//�ұ߷���
	PaintFangkuai(620, 900, 48, 37);
	//��������ĵ�4
	PaintDeng(655, 30, D); D++;
	for (int i = 0; i < 5; i++)
	{
		PaintBox(620 + i * 8, 34, B); B++;
	}
	for (int i = 0; i < 5; i++)
	{
		PaintBox(620 + i * 8, 36, B); B++;
	}

	//���ұߵķ���
	PaintFangkuai(665, 900, 37, 10);
	//���Աߵ�moster
	int MOS_LR = 0;
	PaintMosterLR(592, 30 + 2, MOS_LR, 2, 22);
	//�������������
	WrapFangkuai(645, 900, 48, 44); MOS_LR++;
	int DC = 0;
	PaintDici(621, 48, DC); DC++;
	PaintDici(621 + 6, 48, DC); DC++;
	//ͷ���ķ���
	PaintFangkuai(520, 1000, 100, 70);
	PaintFangkuai(611, 640, 70, 60);
	PaintFangkuai(600, 640 + 10, 70, 64);
	PaintFangkuai(611 - 22, 640 + 22, 70, 67);
	PaintFangkuai(611 - 32, 640 + 32, 70, 69);
	//�ϱߵĵ�5
	PaintDeng(680, 44, D); D++;
	//moster
	PaintMosterLR(660, 44 + 2, MOS_LR, 2, 18); MOS_LR++;
	//
	WrapFangkuai(690, 900, 44, 33);
	PaintBox(690, 33 + 4, B); B++;
	PaintBox(690, 33 + 8, B); B++;
	PaintBox(690, 33 + 10, B); B++;
	PaintFangkuai(730, 745, 47, 46);
	//wrap����ķ���
	WrapFangkuai(760, 900, 90, 70);
	PaintFangkuai(760, 800, 50, 33);
	//mo's'te'r
	int MOS_UD = 0;
	PaintMosterUD(810, 80, MOS_UD, 1, 21);
	PaintBox(790, 50 + 4, B); B++;
	PaintBox(790, 50 + 8, B); B++;
	PaintBox(790 - 3, 50 + 8, B); B++;
	PaintBox(820, 60 + 4, B); B++;
	PaintBox(829, 60 + 4, B); B++;

	//6
	PaintDeng(825, 65, D); D++;
	PaintFangkuai(865, 1000, 55, 0);
	PaintFangkuai(1000, 1200, 100, 0);

	int T = 0;
	for (int i = 0; i < 13; i++)
	{
		PaintTrap(800 + i * 5, 34, T); T++;
	}
	for (int i = 0; i < 13; i++)
	{
		PaintTrap(802 + i * 5, 39, T); T++;
	}
}

void GreatGameLevel_4()//����4
{
	int B = 0;//װ����box
	PaintFangkuai(0, 1000, 20, 0);
	PaintFangkuai(0, 25, 150, 0);
	PaintFangkuai(0, 200, 29, 0);
	PaintFangkuai(44, 56, 30, 29);
	PaintFangkuai(43, 57, 31, 30);
	PaintFangkuai(0, 34, 30, 29);
	PaintFangkuai(0, 35, 31, 30);
	PaintFangkuai(0, 37, 32, 31);
	PaintFangkuai(0, 40, 40, 32);
	PaintFangkuai(0, 38, 42, 40);
	PaintFangkuai(0, 36, 44, 42);
	PaintFangkuai(0, 32, 47, 44);
	for (int i = 0; i < 11; i++)
	{
		PaintFangkuai(0, 30 + i * 5, 48 + i, 47 + i);
	}
	for (int i = 0; i < 11; i++)
	{
		PaintFangkuai(0, 85 - i, 58 + i, 57 + i);
	}
	PaintFangkuai(0, 75, 140, 68);
	PaintFangkuai(0, 500, 140, 80);
	//���￪ʼ������ߵķ���
	//�ұ߷���
	PaintFangkuai(0, 75, 140, 68);
	PaintFangkuai(140, 190, 32, 29);
	//�����ϵ�moster
	int MOS_UD = 0;
	PaintMosterUD(143, 45, MOS_UD, 4, 10); MOS_UD++;
	PaintMosterUD(160, 46, MOS_UD, 4, 11); MOS_UD++;
	//moster����ķ���
	PaintFangkuai(143, 170, 100, 49);
	PaintFangkuai(138, 170, 55, 50);
	PaintFangkuai(135, 170, 67, 60);
	PaintFangkuai(0, 170, 100, 80);
	PaintFangkuai(170, 180, 90, 52);
	WrapFangkuai(171, 177, 88, 54);
	//�ұߵķ���
	PaintFangkuai(215, 235, 32, 20);
	//������ߵĳ���
	int CL = 0;
	PaintChilun(190 + 4, 30, CL); CL++;
	PaintChilun(190 + 10, 30, CL); CL++;
	for (int i = 0; i < 3; i++)
	{
		PaintChilun(190 + 15, 30 - i * 4, CL); CL++;
		PaintChilun(190 + 19, 30 - i * 4, CL); CL++;
	}
	//PaintFangkuai(143, 170, 100, 49);
	//��������ĵ�1
	int D = 1;
	PaintDeng(220, 32, D); D++;
	//�����ұߵĳ���

	for (int i = 0; i < 3; i++)
	{
		PaintChilun(237 + 4, 30 - i * 4, CL); CL++;
		PaintChilun(237 + 10, 30 - i * 4, CL); CL++;
		PaintChilun(237 + 15, 30 - i * 4, CL); CL++;
		//PaintChilun(237 + 19, 30 - i * 4, CL); CL++;
	}
	//�����ұߵķ���
	PaintFangkuai(259, 280, 39, 20);
	PaintFangkuai(280, 310, 34, 20);
	//���ϱߵķ���
	PaintFangkuai(215, 235, 100, 50);
	//���ϱߵĳ���
	PaintChilun(215, 50 - 2, CL); CL++;
	PaintChilun(215, 50 - 4, CL); CL++;
	PaintChilun(211, 50 - 3, CL); CL++;
	PaintChilun(210, 50 - 1, CL); CL++;
	PaintChilun(217, 50 - 5, CL); CL++;
	PaintChilun(220, 50 - 4, CL); CL++;
	PaintChilun(215, 50 - 7, CL); CL++;
	//���ұߵ�moster
	PaintMosterUD(240, 50, MOS_UD, 1, 12); MOS_UD++;
	//moster����ı߽�
	PaintFangkuai(230, 400, 100, 65);
	PaintFangkuai(240, 260, 100, 62);
	PaintFangkuai(273, 280, 100, 60);
	PaintFangkuai(284, 300, 100, 64);
	PaintFangkuai(340, 370, 100, 63);
	PaintFangkuai( 400,700, 100, 73);
	//�ұߵ�box
	
	for (int i = 0; i < 6; i++)
	{
		PaintBox(340, 20 + 4+i*4, B); B++;
		PaintBox(349, 20 + 4+i*4, B); B++;
	}
	//�ұߵķ���
	PaintFangkuai(360, 400, 50, 20);
	//box��ߵĳ���
	for (int j = 0; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			PaintChilun(315 + i * 4, 30-j*3, CL); CL++;
		}
	}
	//box����moster
	PaintMosterUD(315, 50, MOS_UD, 4, 12); MOS_UD++;
	//�����ϵĵ�2
	PaintDeng(380, 50, D); D++;
	//�ұߵķ���
	PaintFangkuai( 400, 550, 43,20);
	//�����ϵ�box
	PaintBox(425, 43 + 4, B); B++;
	PaintBox(428, 43 + 4, B); B++;
	PaintBox(435, 43 + 4, B); B++;
	PaintBox(435, 43 + 8, B); B++;
	//�ұߵķ���
	PaintFangkuai(475,490, 52, 20);
	//������ߵ�moster
	int MOS_LR = 0;
	PaintMosterLR(420, 43 + 5, MOS_LR, 2, 22); MOS_LR++;
	PaintMosterLR(440, 43 + 4, MOS_LR, 2, 22); MOS_LR++;
	PaintMosterLR(412, 43 + 3, MOS_LR, 2, 12); MOS_LR++;
	PaintMosterLR(450, 43 + 2, MOS_LR, 2, 12); MOS_LR++;
	//�ұߵ�box
	PaintBox(490, 43 + 4, B); B++;
	PaintBox(490, 43 + 8, B); B++;
	//box�ұߵĵ�3
	PaintDeng(480, 52, D); D++;
	//box�ұߵķ���
	WrapFangkuai(520, 600, 43, 30);
	//�ұߵķ���
	PaintFangkuai(550, 565, 43,20);
	//�м����
	for (int j = 0; j < 4; j++)
	{
		for (int i = 0; i < 5; i++)
		{
			PaintChilun(520 + 3 + i * 5, 40-j*3, CL); CL++;
		}
	}
	PaintFangkuai(600, 615, 43,20);
	//�м�����
	int T = 0;
	for (int j = 0; j < 2; j++)
	{
		for (int i = 0; i < 10; i++)
		{
			PaintTrap(566 + 3 * i+j*3, 22+j*5, T); T++;
		}
	}
	for (int j = 0; j < 1; j++)
	{
		for (int i = 0; i < 10; i++)
		{
			PaintTrap(566 + 3 * i, 32 + j * 5, T); T++;
		}
	}	//�м�����
	int DC = 0;
	for (int i = 0; i < 4; i++)
	{
		PaintDici(615, 20+i, DC); DC++;
		PaintDici(625, 20+i, DC); DC++;
		PaintDici(629, 20+i, DC); DC++;
	}
	PaintFangkuai(640, 700, 47, 20);
	PaintFangkuai(640, 665, 52, 20);
	PaintBox(627, 50, B); B++;
	PaintChilun(640 - 4, 47, CL); CL++;
	PaintChilun(640 - 4, 47-4, CL); CL++;
	//��4
	PaintDeng(680, 47, D); D++;
	//�ұ߷���
	PaintFangkuai(725, 750, 52, 20);
	PaintMosterUD(730, 68, MOS_UD, 4, 12); MOS_UD++;
	PaintFangkuai(700, 1000,  140,85);
	//�����ϵ�moster

	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			PaintChilun(700 + 3+j*5, 22 + i*3, CL); CL++;
		}
		
	}
	//�ұ߷���
	PaintFangkuai(750, 1200, 40, 20);
	//�ϱ�����
	for (int j = 0; j < 2; j++)
	{
		for (int i = 0; i < 17; i++)
		{
			PaintChilun(750 + 3 + i * 5, 42+j*3, CL); CL++;
		}
	}
	//̨��
	PaintFangkuai(780, 795, 52, 51);
	PaintFangkuai(810, 825, 57, 56);

	PaintFangkuai(840, 890, 55, 20);
	PaintFangkuai(860, 890, 57, 20);
	//�ϱߵĵ�
	PaintDeng(880, 57, D); D++;
	//�ұߵ�վ̨
	PaintFangkuai(920, 940, 55, 0);
	WrapFangkuai(890, 920, 50, 20);
	for (int j = 0; j < 3; j++)
	{
		PaintDici(890, 20, DC); DC++;
		PaintDici(900, 20, DC); DC++;
		PaintDici(910, 20, DC); DC++;
	}
	WrapFangkuai(940, 960, 50, 20);
	PaintFangkuai(960, 990,  57,20);
	for (int j = 0; j < 2; j++)
	{
		PaintDici(940, 20, DC); DC++;
		PaintDici(950, 20, DC); DC++;
	}
	//PaintDici(910, 30, DC); DC++;
	PaintFangkuai(975, 990,  140,66);
	PaintFangkuai( 990,1010, 53, 10);
	PaintFangkuai(1004, 1200, 68, 10);
	//box
	for (int i = 0; i < 5; i++)
	{
		PaintBox(992, 58+i*4, B); B++;
	}
	WrapFangkuai(990, 1010, 90, 70);
	//�ϱߵ�moster
	PaintMosterUD(900, 70, MOS_UD, 4, 12); MOS_UD++;
	PaintMosterUD(995, 83, MOS_UD, 4, 12); MOS_UD++;
	PaintFangkuai(1000, 1200, 140, 90);
	//deng6
	PaintDeng(1030, 68, D); D++;
	PaintFangkuai(1130, 1300, 110, 20);

}

//
void GreatGameLevel_5()//����5
{
	PaintFangkuai(0, 1200, 22, 0);
	PaintFangkuai(0, 1200, 500, 475);
	
	//�����м��NPC
	PaintNPC1(590 - 100, 210);
	//����߿�ʼ���ұ���չ
	//����ߵı߽�
	PaintFangkuai(0, 100, 27, 22);
	PaintFangkuai(0, 70, 40, 27);
	PaintFangkuai(0, 75, 42, 40);
	PaintFangkuai(0, 80, 100, 42);
	for (int i = 0; i < 3; i++)
		PaintFangkuai(0, 80 - 1 - i, 101 + i, 100 + i);
	PaintFangkuai(0, 60, 140, 103);
	PaintFangkuai(0, 40, 200, 140);
	PaintFangkuai(0, 30, 500, 200);
	//����ߵı߽�
	//����
	PaintFangkuai(82, 160, 42, 41, 143);
	PaintFangkuai(155, 156, 40, 26, 143);
	for (int i = 0; i < 7; i++)
		PaintFangkuai(85 + i * 11, 87 + i * 11, 44, 39, 143);
	//��һյ��
	PaintDeng(80, 27, 1);
	//��һ����
	PaintSwitch(85, 27, 1);
	//������ؿ��Ƶķ���
	PaintSwitch_fangkuai(155, 156, 34, 27, 5, 143);
	//PaintSwitch(170, 23, 5);
	//PaintSwitch_fangkuai(185, 188,  34,27, 5);
	//��ߵļ���
	//���ϵ�����
	int CL = 0;
	for (int i = 0; i < 120; i++)
	{
		PaintChilun(105 + i * 4, 23, CL); CL++;
		PaintChilun(107 + i * 4, 24, CL); CL++;
	}
	//�����ϱߵķ���

	for (int i = 0; i <= 33; i++)
	{
		PaintFangkuai(0, 75 + i * 4, 48 + i, 47 + i);
	}
	WrapFangkuai(80, 84, 57, 54);
	WrapFangkuai(90, 94, 69, 65);
	WrapFangkuai(50, 54, 34, 30);

	PaintFangkuai(165, 190, 100 + 3, 78 + 3);
	PaintFangkuai(160, 195, 100 - 4, 78 + 3 + 10);
	PaintFangkuai(0, 130, 90 + 3, 78 + 3);

	WrapFangkuai(90, 120, 87 + 3, 80);

	//��һ���ؿ��Ƶķ���
	PaintSwitch_fangkuai(100, 115, 90 + 3, 87 + 3, 5);
	//PaintSwitch(110, 90 + 3, 3);
	//�ڶ���
	PaintDeng(115, 80, 2);
	PaintSwitch(110, 80, 2);
	//�����ϱߵķ���
		//�ϱ߷�����ϱ�
	PaintFangkuai(0, 400, 200, 190);
	PaintFangkuai(0, 380, 190, 180);
	PaintFangkuai(0, 340, 180, 170);
	PaintFangkuai(40, 200 - 2, 200 + 6, 200 + 5, 143);
	PaintFangkuai(250 + 2, 380, 200 + 6, 200 + 5, 143);
	for (int i = 0; i < 17; i++)
	{
		PaintFangkuai(45 + i * 20, 47 + i * 20, 210, 201, 143);
	}
	//�����м�ķ���

	PaintFangkuai(200, 250, 220, 170);
	WrapFangkuai(210, 214, 210 + 4, 210);
	WrapFangkuai(230, 234, 210 + 4, 210);
	WrapFangkuai(225, 229, 184, 180);
	WrapFangkuai(226, 231, 184 + 10, 180 + 10);
	for (int i = 0; i < 5; i++)
		WrapFangkuai(70 + i * 20, 74 + i * 20, 178, 174);
	for (int i = 0; i < 5; i++)
		WrapFangkuai(180 + i * 20, 184 + i * 20, 180, 180 - 4);

	PaintFangkuai(0, 80 - 2, 168, 167);
	PaintFangkuai(0, 80 - 1, 167, 166);
	PaintFangkuai(0, 80, 166, 156);
	PaintFangkuai(0, 80 - 1, 156, 155);
	PaintFangkuai(0, 80 - 2, 155, 154);

	WrapFangkuai(40, 44, 104, 100);
	WrapFangkuai(40, 44, 104 + 20, 100 + 20);
	WrapFangkuai(40, 44, 104 + 35, 100 + 35);
	PaintFangkuai(0, 70, 154, 140);
	WrapFangkuai(40, 44, 34, 30);
	WrapFangkuai(46, 50, 34 + 20, 30 + 20);
	WrapFangkuai(46, 50, 34 + 35, 30 + 35);
	WrapFangkuai(46 + 20, 50 + 20, 34 + 35, 30 + 35);
	WrapFangkuai(46 + 80, 50 + 80, 34 + 36, 30 + 36);
	PaintFangkuai(160 + 1, 194, 91, 90);
	PaintFangkuai(160 + 1, 194, 100 + 4, 100 + 3);

	PaintFangkuai(95, 160, 170, 166);
	PaintFangkuai(96, 120 - 1, 166, 165);
	PaintFangkuai(97, 120 - 2, 165, 164);

	PaintFangkuai(155, 220, 170, 155);
	PaintFangkuai(141, 220, 155, 154);
	PaintFangkuai(140, 220, 154, 150);
	PaintFangkuai(121, 220, 150, 150 - 1);
	PaintFangkuai(120, 220, 150 - 1, 145);
	PaintFangkuai(101, 220, 145, 144);
	PaintFangkuai(100, 220, 144, 135);
	PaintFangkuai(91, 220, 135, 134);
	PaintFangkuai(90, 220, 134, 130);
	PaintFangkuai(110, 220, 130, 127);
	PaintFangkuai(111, 220, 127, 126);

	PaintMosterUD(190, 121, 1, 1, 12);

	WrapFangkuai(118, 118 + 4, 134, 130);
	WrapFangkuai(118 + 20, 118 + 4 + 20, 135, 130);
	WrapFangkuai(118 + 45, 118 + 4 + 45, 134, 130);
	WrapFangkuai(182, 220, 140, 126);
	WrapFangkuai(188, 190 + 6, 140, 140 - 1);
	WrapFangkuai(190, 190 + 4, 140 - 1, 140 - 2);

	PaintFangkuai(220, 330, 180, 165);
	WrapFangkuai(220, 330 - 1, 165, 164);
	WrapFangkuai(200, 204, 148 + 5, 144 + 5);
	WrapFangkuai(200, 204, 148 + 15, 144 + 15);
	WrapFangkuai(230 + 10, 244, 148 + 27, 144 + 27);
	WrapFangkuai(230 + 30, 274, 148 + 27, 144 + 27);
	WrapFangkuai(240 + 60, 244 + 60, 148 + 27, 144 + 27);
	WrapFangkuai(240 + 80, 244 + 80, 148 + 40, 144 + 40);
	WrapFangkuai(240 + 100, 244 + 100, 148 + 40, 144 + 40);
	WrapFangkuai(240 + 120, 244 + 120, 148 + 40, 144 + 40);

	PaintFangkuai(210, 212, 250, 220);
	PaintFangkuai(210 - 4, 212 + 4, 250, 250 - 1);


	//�ϱ߷������6
	//���ϱߵķ���
	for (int i = 0; i <= 80; i++)
	{
		PaintFangkuai(0, 50 + i * 4, 225 + i, 224 + i);
	}
	for (int i = 0; i < 14; i++)
		WrapFangkuai(60 + i * 17, 64 + i * 17, 234 + i * 5, 230 + i * 5);
	PaintFangkuai(0, 350, 500, 305);
	PaintFangkuai(0, 360 - 1, 345 + 1, 345);
	PaintFangkuai(0, 360, 345, 340);
	PaintFangkuai(0, 360 - 1, 340, 340 - 1);
	for (int i = 0; i < 10; i++)
	{
		WrapFangkuai(335, 339, 314 + i * 15, 310 + i * 15);
	}
	PaintFangkuai(0, 500, 500, 400);
	PaintFangkuai(0, 410, 400, 400 - 10);
	PaintFangkuai(0, 410, 400 - 10, 400 - 11);
	PaintFangkuai(0, 400 - 1, 400 - 30, 400 - 31);

	PaintFangkuai(0, 400 - 20, 400 - 31, 400 - 32);
	PaintFangkuai(500 - 10, 800, 500, 400 - 50);
	PaintFangkuai(0, 500, 500, 400 - 21);
	for (int i = 0; i < 10; i++)
	{
		WrapFangkuai(400 + i * 20, 404 + i * 20, 390, 390 - 4);
	}
	for (int i = 0; i < 20; i++)
	{
		WrapFangkuai(520 + i * 25, 524 + i * 25, 360, 356);
	}
	PaintFangkuai(500 - 40, 600, 350, 300);
	for (int i = 0; i < 30; i++)
	{
		WrapFangkuai(500 - 40 + 12, 500 - 40 + 16, 314 + i * 15, 310 + i * 15);
	}
	//��3
	PaintDeng(475, 350, 3);
	//���Ƶ�������Ŀ���
	PaintSwitch(480, 350, 3);
	//�ڶ����ؿ��Ƶķ���
	PaintSwitch_fangkuai(460, 465, 400 - 35, 350, 2);
	PaintFangkuai(460, 500, 400 - 35 + 3, 400 - 35);
	//////////////////////
	PaintFangkuai(500 - 60, 800, 300, 290);

	PaintFangkuai(500 - 90 + 1, 800, 290, 290 - 1);
	PaintFangkuai(500 - 90, 800, 290 - 1, 285);

	PaintFangkuai(500 - 120 + 1, 600, 285, 284);
	PaintFangkuai(500 - 120, 600, 284, 280);

	PaintFangkuai(500 - 140 + 1, 400, 280, 280 - 1);
	PaintFangkuai(500 - 140, 400, 280 - 1, 275);

	PaintFangkuai(500 - 186 + 1, 400, 275, 274);
	PaintFangkuai(500 - 186, 400, 274, 270);



	////T�ͷ����ϱ�
	PaintFangkuai(200, 350, 265, 262);
	PaintFangkuai(170, 190, 262, 240);
	PaintFangkuai(170 + 1, 190 - 1, 240, 240 - 1);
	PaintFangkuai(170 + 2, 190 - 2, 240 - 1, 240 - 2);
	PaintFangkuai(200, 350, 265, 262);
	PaintFangkuai(240, 360, 262, 261);
	PaintFangkuai(240, 360, 261, 260 - 3);
	PaintFangkuai(280, 360, 260 - 3, 260 - 6);
	PaintFangkuai(280 + 1, 360, 260 - 6, 260 - 7);
	PaintFangkuai(320, 400, 260 - 7, 260 - 13);
	PaintFangkuai(320 + 1, 400, 260 - 13, 260 - 14);
	PaintFangkuai(320 + 2, 400, 260 - 14, 260 - 15);
	PaintFangkuai(350, 500, 260 - 15, 260 - 19);
	PaintFangkuai(350 + 1, 500, 260 - 19, 260 - 20);
	PaintFangkuai(350 + 3, 500, 260 - 20, 260 - 21);
	PaintFangkuai(450, 500, 270, 260 - 15);
	PaintFangkuai(450 + 1, 500 - 1, 271, 270);

	WrapFangkuai(460, 464, 264, 260);
	WrapFangkuai(480, 484, 264, 260);
	for (int i = 0; i < 10; i++)
	{
		WrapFangkuai(450 + i * 25, 454 + i * 25, 290, 290 - 4);
	}
	//moster
	PaintMosterUD(405, 270, 2, 1, 13);

	//�ұߵķ���
	PaintFangkuai(570 - 5, 585 + 5, 260, 250);
	PaintFangkuai(570, 585, 500, 200);
	PaintFangkuai(570 - 1, 585 + 1, 260 - 1, 250 + 1);
	PaintFangkuai(570 - 2, 585 + 2, 260 - 2, 250 + 2);
	PaintFangkuai(590, 800, 500, 280);
	PaintFangkuai(540, 620, 280, 278);
	PaintFangkuai(546, 610, 278, 277);
	PaintFangkuai(540, 600, 240, 190);
	for (int i = 0; i < 4; i++)
	{
		WrapFangkuai(548, 548 + 4, 234-i*15, 230-i*15);
	}
	

	for (int i = 0; i < 10;i++)
	PaintFangkuai(500+i*40, 560+i*40, 41+i,40+i);

	for (int i = 0; i < 20; i++)
		PaintFangkuai(620 + i*2, 622 + i*2, 51 + i * 8, 41 + i * 8);
	for (int i = 0; i < 10; i++)
		PaintFangkuai(620 + i * 40, 680 + i * 40, 121 + i, 120 + i);

	for (int i = 0; i < 10; i++)
		PaintFangkuai(640 - i * 40, 700 - i * 40, 121 - i, 120-i);

	for (int i = 0; i < 10; i++)
		PaintFangkuai(700+ i * 40, 760 +i * 40, 121 - i, 120 - i);
	PaintFangkuai(800, 900, 500, 0);
	
	PaintDengTai(710, 105);
	PaintDeng(710, 105,4);
	//��һ���ؿ��Ƶ�fk
	PaintSwitch_fangkuai(700, 760, 123, 120-2,1);
	PaintFangkuai(780, 800, 300, 0);
	WrapFangkuai(790, 820, 135, 120);
	//�ڶ����ؿ���
	PaintSwitch_fangkuai(780, 790, 135, 120, 2);
	//��
	PaintDeng(800, 120, 5);
	PaintFangkuai(760, 800, 150, 140);
	PaintFangkuai(760+1, 800, 150-1, 140+1);
	//���忪��
	PaintSwitch(770, 150,  5);
	//��
	PaintDengTai(730, 180);
	PaintDeng(730, 180,6);
	//moster
	PaintMosterUD(460, 230, 3, 1, 20);

	//���￪ʼ��վ̨
	PaintFangkuai(580 - 100, 600 - 100, 74 + 10, 46);
	PaintFangkuai(570 - 100, 610 - 100, 80 + 10, 74 + 10);
}

void GreatGameLevel_6()//����6
{
	//�Թ�������
	PaintFangkuai(0, 1200, 21, 0);
	PaintFangkuai(0,80,200,0);
	//��߽�
	PaintFangkuai(80, 100, 70, 0);
	PaintFangkuai(80, 100, 300, 80);
	//�ڶ���
	PaintFangkuai(100, 140, 84, 80);
	PaintFangkuai(140,150, 130, 30);
	PaintFangkuai(100, 140, 144, 140);
	PaintFangkuai(140, 150, 220, 140);
	PaintFangkuai(0, 1200, 300, 240);
//��1
	PaintDeng(120, 144, 1);

	//������
	PaintFangkuai(190, 200, 240, 80);

	PaintFangkuai(190, 200, 40, 20);
	PaintFangkuai(200, 240, 40, 40-4);

	PaintFangkuai(190, 200, 70, 50);

	PaintFangkuai(200, 200 + 80+10, 54, 50);
	PaintFangkuai(200, 240, 70, 70 - 4);

	PaintFangkuai(240, 250, 160, 60);
	PaintFangkuai(240, 250, 220, 170);

	PaintFangkuai(200, 240, 174, 170);
	//��һ���ؿ��Ƶķ���
	PaintSwitch_fangkuai(202, 240 - 2, 112, 110, 1, 143);
	//����
	PaintFangkuai(240, 280, 30, 30-4);

	PaintFangkuai(280, 290, 100, 30-4);

	PaintFangkuai(280, 320, 100, 100 - 4);
	PaintFangkuai(280, 320 + 10 + 40, 64, 60 );

	PaintFangkuai(280, 290, 190, 110);
	PaintFangkuai(290, 320, 190, 190 - 4);

	PaintFangkuai(290, 320 + 10 + 40 + 10 + 40, 150, 150 - 4);////

	PaintFangkuai(280, 290, 240, 200);
	//����
	PaintFangkuai(320, 330, 220, 160);
	PaintFangkuai(320, 330, 140, 110);
	PaintFangkuai(330, 330 + 40, 114, 110);

	PaintFangkuai(320, 330, 80, 70);
	PaintFangkuai(330, 330 + 40 + 10 + 40, 80, 80 - 4);

	PaintFangkuai(320, 330, 50, 0);
	//��һ����
	PaintSwitch(350, 21, 1);
	//����
	PaintFangkuai(370, 380, 70, 0);
	PaintFangkuai(370, 380, 300, 80);
	PaintFangkuai(380, 380 + 40, 164, 160);
	PaintFangkuai(420, 430, 220, 170);
	PaintFangkuai(420, 430, 140, 30);

	//�ڶ����Լ��ڶ�����
	PaintDeng(340, 150, 2);
	PaintSwitch(310, 170, 2);
	//����
	PaintFangkuai(430, 430 + 90, 174, 170);
	PaintFangkuai(470, 480, 40, 0);
	PaintFangkuai(480, 480+40, 40, 40-4);

	PaintFangkuai(480+40, 520+10, 70, 30);

	PaintFangkuai(470, 480, 170, 50);
	PaintFangkuai(470, 480, 300, 180);

	PaintFangkuai(520, 530, 200, 80);
	PaintFangkuai(520, 530, 300, 220);

	PaintFangkuai(480, 480+40*3+20, 214, 210);
	//������
	PaintDeng(490, 214, 3);
	//�ڶ����ؿ��Ʒ���
	PaintSwitch_fangkuai(430 + 4, 470-2 , 92, 90,2,143);
	//����
	//�������ؿ���
	PaintSwitch_fangkuai(530 + 2, 570 - 2, 142,140, 3, 143);

	PaintFangkuai(570, 580, 80, 30);
	PaintFangkuai(570, 580, 100, 90);
	PaintFangkuai(520, 560, 80+4, 80);
	PaintFangkuai(520, 520 + 20 + 80, 120 , 120-4);
	PaintFangkuai(570, 580, 220, 130);

	PaintFangkuai(580, 630, 90 + 4, 90);
	PaintFangkuai(620, 630, 94, 0);
	PaintFangkuai(620, 630, 190, 100);
	PaintFangkuai(620, 630, 300, 220);

	PaintFangkuai(630, 670, 224, 220);
	PaintFangkuai(630, 670, 204, 200);
	PaintFangkuai(630, 670, 104, 100);
	PaintFangkuai(630, 670 + 40 + 10, 144, 140);
	//�ڰ�
	PaintFangkuai(670,680, 130, 30);
	PaintFangkuai(670, 680, 220, 150);
	//�ھ�
	PaintFangkuai(720, 730, 60, 0);
	PaintFangkuai(720, 730, 100,70);
	PaintFangkuai(730, 770, 74, 70);

	PaintFangkuai(720, 730, 170, 130);
	PaintFangkuai(730, 770, 124, 120);

	PaintFangkuai(730, 770, 100, 100 - 4);
	PaintFangkuai(730, 770, 110, 110 - 4);
	PaintFangkuai(720, 730, 300, 180);
	PaintFangkuai(730, 770, 170, 170-4);

	PaintFangkuai(770, 780, 70, 30);

	PaintFangkuai(780, 820, 90, 90-3);
	PaintFangkuai(770, 780, 90, 80);
	PaintFangkuai(780, 820, 83, 80);

	PaintFangkuai(770, 780, 220, 100);
	PaintFangkuai(780, 820, 220, 220-4);
	PaintFangkuai(780, 820+10+40, 190, 190-4);
	//���ĵƺ͵�������
	PaintDeng(750,110,4);
	PaintSwitch(760, 110, 3);
	//��ʮ
	PaintFangkuai( 820,830, 80,0);
	PaintFangkuai(820, 830, 150, 90);
	PaintFangkuai(820, 830, 180, 160);
	PaintFangkuai(820, 830, 220, 200);

	
	PaintFangkuai(830, 870+50, 160, 160-4);
	PaintFangkuai(830, 870+50, 150, 150 - 4);
	PaintFangkuai(830, 870+50, 30, 30 - 4);

	//��11
	PaintFangkuai(870, 880,140,40);
	PaintFangkuai(870, 880, 220, 170);

	PaintFangkuai(920, 930, 120, 30-4);
	PaintFangkuai(920, 930, 170, 140);
	PaintFangkuai(920, 930, 300, 185);

	PaintFangkuai(880, 880+80+10, 180, 180-4);
	PaintFangkuai(880, 880 + 80 + 10, 130, 130 - 4);

	PaintFangkuai(970, 980, 220, 0);

	PaintFangkuai( 1020,1030, 140, 30);
	PaintFangkuai(1020, 1030, 300, 180);
	PaintFangkuai(980, 120, 150, 150-4);
	PaintFangkuai(1030, 1070, 160, 160-4);
	PaintFangkuai(1030, 1070, 140, 140-4);
	//���Ŀ��ؿ��ƺ͵��Ŀ���
	PaintSwitch_fangkuai(980 + 2, 1020 - 2, 80, 80 - 2,4,143);
	PaintSwitch(940, 30, 4);

	//�ұ߽�
	PaintFangkuai(1070, 1200, 90, 0);
	PaintFangkuai(1070, 1200, 300, 100);
	//	�����
	PaintDeng(1050, 160, 5);
	//������
	PaintDeng(950, 25, 6);
}

void PaintMosterUD(int x, int y, int innertype2, int innertype, int bushu)
{
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].paint_type = 2;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].can_move = 0;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].innner_type = innertype;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].move_num = 0;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].Totalmove_num = bushu;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].move_to = 1;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].cna_Paint = 1;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].color = 0;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}
void PaintFangkuai(int left, int right, int up, int down,int color)
{
	for (int i = left; i < right; i++)
	{
		for (int j = down; j < up; j++)
		{
			
				background[man_in.GetCurrentLevel() ].backgroundmod[i][j].paint_type = 1;
				background[man_in.GetCurrentLevel() ].backgroundmod[i][j].color = color;
			
		}
	}
}

void PaintLeftTi(int left, int right, int up, int down,int wide,int hight)
{
	int n = 0;
	for (int i = left; i < right; i+=wide)
	{
		for (int j = down; j < up-n; j++)
		{
			for (int m = 0; m < wide; m++)
			{
				
			
					background[man_in.GetCurrentLevel() ].backgroundmod[i + m][j].paint_type = 1;
					background[man_in.GetCurrentLevel() ].backgroundmod[i + m][j].color = 0;
				
			}
		}
		n += hight;

	}
}

void PaintRightTi(int left, int right, int up, int down, int wide, int hight)
{
	int n = 0;
	for (int i = right; i >left; i -= wide)
	{
		for (int j = down; j < up - n; j++)
		{
			for (int m = 0; m < wide; m++)
			{
				
					background[man_in.GetCurrentLevel() ].backgroundmod[i - m][j].paint_type = 1;
					background[man_in.GetCurrentLevel() ].backgroundmod[i - m][j].color = 0;
				
			}
		}
		n += hight;

	}
}

void PaintBox(int x, int y, int innertype2)//����up-down Ϊ4�ı��� right-left Ϊ8 �ı���
{
	
			
			background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 4;
			background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 128;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = 2;
		background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
	
}

void PaintYanjiang(int x, int y, int innertype2)//�ҽ������½�Ϊ��㣬����x+10 ����y-4
{
	
				background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 4;
				background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 204;
				background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = 4;
				background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;

}

void PaintDeng(int x, int y,int inner_type2)
{
	
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 4;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 128;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = 1;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].inner_type2 = inner_type2;
	
}

void PaintDici(int x, int y,int innertype2)
{
	
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 4;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 140;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = 3;
		background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}

void PaintMosterLR(int x, int y,int innertype2,int innertype ,int bushu)
{
	
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 2;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].can_move = 0;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = innertype ;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].move_num = 0;
		background[man_in.GetCurrentLevel()].backgroundmod[x][y].Totalmove_num = bushu;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].move_to = 4;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].cna_Paint = 1;
		background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 0;
		background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}

void PaintNPC1(int x, int y)
{
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].paint_type = 3;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].color = 143;
	background[man_in.GetCurrentLevel() ].backgroundmod[x][y].innner_type = 1;
}

void PaintNPC2(int x, int y, int innertype)
{
	background[2].backgroundmod[x][y].paint_type = 3;
	background[2].backgroundmod[x][y].color = 15;
	background[2].backgroundmod[x][y].innner_type =2;
	background[2].backgroundmod[x][y].inner_type2 = innertype;
}

void PaintSanjiaoxing(int x, int y,int length)
{
	for (int t = 0; t < 3; t++)
	{
		x += 2;
		for (int i = 0; i < 20 - t * 6; i++)
		{

			background[man_in.GetCurrentLevel()].backgroundmod[x ][y].paint_type = 1;
			background[man_in.GetCurrentLevel()].backgroundmod[x][y].color = 0;

		}y++;
	}
}

void PaintChilun(int x, int y,int innertype2)
{
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].paint_type = 4;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].color = 128;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].innner_type = 6;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}

void PaintTrap(int x, int y, int innertype2)
{
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].paint_type = 4;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].color = 140;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].innner_type = 5;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}

void WrapFangkuai(int left, int right, int up, int down)
{
	for (int i = left; i < right; i++)
	{
		for (int j = down; j < up; j++)
		{

			background[man_in.GetCurrentLevel()].backgroundmod[i][j].paint_type = 0;
			background[man_in.GetCurrentLevel()].backgroundmod[i][j].color = 275;

		}
	}
}

void InitialLight()
{
	for (int i = 0; i < 6; i++)
	{
		jg1[i].SetLight(0);
	}
}

void PaintSwitch(int x, int y, int innertype2)
{
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].paint_type = 4;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].color = 128;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].innner_type = 7;
	background[man_in.GetCurrentLevel()].backgroundmod[x][y].inner_type2 = innertype2;
}

void PaintSwitch_fangkuai(int left, int right, int up, int down,int innertype2,int color)
{
	for (int i = left; i < right; i++)
	{
		for (int j = down; j < up; j++)
		{

			background[man_in.GetCurrentLevel()].backgroundmod[i][j].paint_type = 6;
			background[man_in.GetCurrentLevel()].backgroundmod[i][j].color = color;
			background[man_in.GetCurrentLevel()].backgroundmod[i][j].inner_type2 = innertype2;
		}
	}
}
void PaintDengTai(int x, int y)
{
	PaintFangkuai(x-9, x+9, y, y-1);
	PaintFangkuai(x-13, x+13, y-1, y-2);
	PaintFangkuai(x-4, x+4, y-2, y-4);
}

void InitialtheSwitch()
{
	for (int i = 0; i < 10; i++)
	{
		jg7[i].setstate(0);
	}
}
