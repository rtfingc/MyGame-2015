#include "NPC.h"
#include"GameLevel.h"
#include"Paint.h"
#include"Affair.h"
#include<ctime>
#include<Windows.h>
#include<iostream>
using namespace std;
//1 Ϊ�˵� 2 Ϊ���޵� 3 Ϊ������ 4 Ϊ������ 5 λ������ 6 Ϊ���
enum World { world_1, world_2, world_3,world_4,world_5,world_6 };

Man::Man()
{
	current_level = 0;

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			manDot[i][j] = 0;
		}
	}
	for (int i = 0; i < 3; i++)
	{
		manDot[i][1] = 1;
	}
	for (int j = 0; j < 4; j++)
	{
		manDot[1][j] = 1; 
	}
	Dao = world_1;
	SetEdge(28, 27);
	Blood = 40;
	Life = 0;
	Goodtime = 0;
	Badtime = 0;
	GoodtimeRand = 0;
	BadtimeRand = 0;
	
	money = 21;
	
}

Man::Man(int x, int y)
{
	SetEdge(x, y);
}


void Man::Paintman(int x, int y, int direction)//direction 1 ���� 2���� 3 ���ϣ�4 ����
{


	//PaintPower();
	//WrapBlood();
	PaintBlood();
	
	//GReadAndWrite();
	GSetConsoleAttribute(0);
	switch (GetDao())//walk ����λ���ֱ�ʾ ʮλ��ʾ����1 Ϊ�� 2 Ϊ�Ҿ����ô�������ʱ�ķ����ʾ
	{
	case world_1:
		SetEdge(x, y);
		switch (direction)
		{
		case 1:
			if (walk == 21 || walk == 11)
			{
				Paintworld_1_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12 || walk == 22)
			{
				Paintworld_1_man_L2(x, y);
				walk = 11;
			}

			break;
		case 2:
			if (walk == 21 || walk == 11)
			{
				Paintworld_1_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22||walk==12)
		   {
		        Paintworld_1_man_R2(x, y);
				walk=21;
			}
			break;
		case 3:
			if (walk == 21)
			{
				Paintworld_1_man_R2(x, y);
				walk = 22;
			}
			else if (walk == 22)
			{
				Paintworld_1_man_R2(x, y);
				walk = 21;
			}
			else if (walk == 11)
			{
				Paintworld_1_man_L2(x, y);
				walk = 12;
			}
			else if (walk == 12)
			{
				Paintworld_1_man_L2(x, y);
				walk = 11;
			}
			break;
		case 4://down �������ʱ��������
			if (walk == 11||walk==12)
			{
				Paintworld_1_man_L(x, y);
				walk = 12;
			}
			else if (walk == 22||walk==21)
			{
				Paintworld_1_man_R(x, y);
				walk = 22;
			}
			break;
		case 5:
			if (walk == 21 || walk == 22)
			{
				Paintworld_1_man_R(x, y);
			}
			else if (walk == 11 || walk == 12)
			{
				Paintworld_1_man_L(x, y);
			}
			break;
		}
		break;
	case world_2:
		SetEdge(x, y);
		switch (direction)
		{
		case 1:
			if (walk == 21 || walk == 11)
			{
				Paintworld_2_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12 || walk == 22)
			{
				Paintworld_2_man_L2(x, y);
				walk = 11;
			}

			break;
		case 2:
			if (walk == 21 || walk == 11)
			{
				Paintworld_2_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22 || walk == 12)
			{
				Paintworld_2_man_R2(x, y);
				walk = 21;
			}
			break;
		case 3:
			if (walk == 21)//�����ҵ�����
			{
				Paintworld_2_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22)//�����ҵ���
			{
				Paintworld_2_man_R2(x, y);
				walk = 21;
			}
			else if (walk == 11)//���������
			{
				Paintworld_2_man_L2(x, y);
				walk = 12;
			}
			else if (walk == 12)//���������
			{
				Paintworld_2_man_L(x, y);
				walk = 11;
			}
			break;
		case 4://down �������ʱ��������
			if (walk == 12||walk==11)
			{
				Paintworld_2_man_R(x, y);
				walk = 1;
			}
			else if (walk == 22||walk==21)
			{
				Paintworld_2_man_L(x, y);
				walk = 0;
			}
			break;
		case 5:
			if (walk == 21 || walk == 22)
			{
				Paintworld_2_man_R(x, y);
			}
			else if (walk == 11 || walk == 12)
			{
				Paintworld_2_man_L(x, y);
			}
			break;
		}
		break;
	case world_3:
		SetEdge(x, y);
		switch (direction)
		{
		case 1:
			if (walk == 21 || walk == 11)
			{
				Paintworld_3_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12 || walk == 22)
			{
				Paintworld_3_man_L2(x, y);
				walk = 11;
			}

			break;
		case 2:
			if (walk == 21 || walk == 11)
			{
				Paintworld_3_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22 || walk == 12)
			{
				Paintworld_3_man_R2(x, y);
				walk = 21;
			}
			break;
		case 3:
			if (walk == 21)
			{
				Paintworld_3_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22)
			{
				Paintworld_3_man_R2(x, y);
				walk = 21;
			}
			else if (walk == 11)
			{
				Paintworld_3_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12)
			{
				Paintworld_3_man_L2(x, y);
				walk = 11;
			}
			break;
		case 4://down �������ʱ��������
			if (walk == 11||walk==12)
			{
				Paintworld_3_man_R(x, y);
				walk = 12;
			}
			else if (walk == 21||walk==22)
			{
				Paintworld_3_man_L(x, y);
				walk = 22;
			}
			break;
		case 5:
			if (walk == 21 || walk == 22)
			{
				Paintworld_3_man_R(x, y);
			}
			else if (walk == 11 || walk == 12)
			{
				Paintworld_3_man_L(x, y);
			}
			break;
		}
		break;

	case world_4:
		SetEdge(x, y);
		switch (direction)
		{
		case 1:
			if (walk == 21 || walk == 11)
			{
				Paintworld_4_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12 || walk == 22)
			{
				Paintworld_4_man_L2(x, y);
				walk = 11;
			}

			break;
		case 2:
			if (walk == 21 || walk == 11)
			{
				Paintworld_4_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22 || walk == 12)
			{
				Paintworld_4_man_R2(x, y);
				walk = 21;
			}
			break;
		case 3:
			if (walk == 21)
			{
				Paintworld_4_man_R(x, y);
				walk = 22;
			}
			else if (walk == 22)
			{
				Paintworld_4_man_R2(x, y);
				walk = 21;
			}
			else if (walk == 11)
			{
				Paintworld_4_man_L(x, y);
				walk = 12;
			}
			else if (walk == 12)
			{
				Paintworld_4_man_L2(x, y);
				walk = 11;
			}
			break;
		case 4://down �������ʱ��������
			if (walk == 0)
			{
				Paintworld_4_man_R(x, y);
				walk = 1;
			}
			else if (walk == 1)
			{
				Paintworld_4_man_L(x, y);
				walk = 0;
			}
			break;
		case 5:
			if (walk == 21 || walk == 22)
			{
				Paintworld_4_man_R(x, y);
			}
			else if (walk == 11 || walk == 12)
			{
				Paintworld_4_man_L(x, y);
			}
			break;
		}
		break;
	case world_5://����͵�������ʱ����ʵ��
		break;
	case world_6:
		break;
	}
//	GSetConsoleAttribute(128);
}
int mm = 0;
void Man::Paintman2(int x, int y)
{
	if (mm == 0)
	{
		Paintman2_1(x, y);
		mm = 1;
	}
	else if (mm == 1)
	{
		Paintman2_2(x, y);
		mm = 0;
	}
}

void Man::Wrapman2(int x, int y)
{
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x - 2, y - 1);
	cout << "  ";
	SetConsolePosition(x + 2, y + 1);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x + 2, y - 1);
	cout << "  ";
}


void Man::Paintman2_1(int x, int y)
{
	SetEdge(x, y);
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x - 2, y - 1);
	cout << "��";
	SetConsolePosition(x + 2, y + 1);
	cout << "��";
}

void Man::Paintman2_2(int x, int y)
{
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x - 2, y +1);
	cout << "��";
	SetConsolePosition(x + 2, y -1);
	cout << "��";
}

bool Man::Levelend_judge()
{
	switch (current_level)
	{
	case Level_1:
		if (Max_R >= 1300)
		{
			
			return 1;
		}
		break;
	case Level_2:
		if (Max_R>=700)/////////////////
		{
			
			return 1;
		}
		break;
	case Level_3:
		if (Max_R >= 1100)/////////////////
		{
			
			return 1;
		}
		break;
	case Level_4:
		if (Max_R >= 1200)/////////////////
		{
			
			return 1;
		}
		break;
	case Level_5:
			return 1;
		
		break;
	case Level_6:
		if (Max_R >= 1200)/////////////////
		{
			return 1;
		}
		break;
	
	}
	return 0;
}

void Man::WrapMan(int x, int y)//û����ô� ��ʱ����Ҫ��
{
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x, y + 1);
	cout << "  ";
	SetConsolePosition(x - 1, y + 1);
	cout << " ";
	SetConsolePosition(x + 2, y + 1);
	cout << " ";
	SetConsolePosition(x - 1, y + 2);
	cout << " ";
	SetConsolePosition(x, y + 2);
	cout << " ";
	SetConsolePosition(x + 1, y + 2);
	SetConsolePosition(x, y + 1);
	cout << "  ";


	SetConsolePosition(x + 4, y + 1);
	cout << "  ";


	SetConsolePosition(x + 5, y + 2);
	cout << "  ";
	SetConsolePosition(x - 1, y + 2);
	cout << "  ";
	cout << " ";
}


void Man::SetEdge(int x, int y)
{
	
	
		switch (Dao)
		{
		case world_1:
			Base_x = x; Base_y = y;
			L_edge = Base_x - 2;
			R_edge = Base_x + 3;
			U_edge = Base_y;
			D_edge = Base_y + 2;
			break;
		case world_2:
			Base_x = x; Base_y = y;
			L_edge = Base_x-4;
			R_edge = Base_x + 2;
			U_edge = Base_y ;
			D_edge = Base_y + 2;
			break;
		case world_3:
			Base_x = x; Base_y = y + 1;
			L_edge = Base_x - 7;
			R_edge = Base_x + 2;
			U_edge = Base_y;
			D_edge = Base_y + 1;
			break;
		case world_4:
			Base_x = x; Base_y = y;
			L_edge = Base_x - 2;
			R_edge = Base_x + 4;
			U_edge = Base_y-1;
			D_edge = Base_y + 1;
			break;
		}
	

}

void Man::PaintPower()
{
	GSetConsoleAttribute(140);
	for (int j = 0; j < 5; j++)
	{
		for (int i = 0; i < 3; i++)
		{
			SetConsolePosition(j * 8, 39 - i - 1);
			SetColor(GetBackGroundPoint(j * 8, 39 - i - 1), 2);
			cout << "��";
		}
	}
	for (int i = 0; i <32; i += 2)
	{
		SetConsolePosition(i, 35);
		SetColor(GetBackGroundPoint(i, 35), 2);
		cout << "�z";
	}
	for (int i = 0; i <= 32; i += 2)
	{
		SetConsolePosition(i, 39);
		SetColor(GetBackGroundPoint(i, 39), 2);
		cout << "��";
	}
	//GReadAndWrite();
}

/*�˵�����������*/
void Man::Paintworld_1_man_L(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
	SetConsolePosition(x - 1, y + 1);
	cout << "~";
	SetConsolePosition(x + 2, y + 1);
	cout << "\\";
	SetConsolePosition(x - 1, y + 2);
	cout << "/";
	SetConsolePosition(x, y + 2);
	cout << " ";
	SetConsolePosition(x + 1, y + 2);
	cout << "\\";
}
void Man::Paintworld_1_man_R(int x, int y)//������1
{
	//SetEdge(x, y);
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y+1);
	cout << "��";
	SetConsolePosition(x-1, y+1);
	cout << "/";
	SetConsolePosition(x+2, y+1);
	cout << "~";
	SetConsolePosition(x-1, y+2);
	cout << "/";
	SetConsolePosition(x, y+2);
	cout << " ";
	SetConsolePosition(x+1, y+2);
	cout << "\\";
	//Sleep(200);
}

void Man::Paintworld_1_man_L2(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
	//SetConsolePosition(19, 21);
	//cout << "|";
	//SetConsolePosition(22, 21);
	//cout << "|";
	SetConsolePosition(x - 1, y + 2);
	cout << " ";
	SetConsolePosition(x, y + 2);
	cout << "|";
	SetConsolePosition(x + 1, y + 2);
	cout << " ";
}
//ֻ������Ϊȷ��
void Man::Paintworld_1_man_R2(int x, int y)
{
	//Sleep(200);
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y+1);
	cout << "��";
	//SetConsolePosition(19, 21);
	//cout << "|";
	//SetConsolePosition(22, 21);
	//cout << "|";
	SetConsolePosition(x-1, y+2);
	cout << " ";
	SetConsolePosition(x, y+2);
	cout << "|";
	SetConsolePosition(x+1, y+2);
	cout << " ";
	//GReadAndWrite();
}

/*�˵�����������*/

/*���޵�*/

void Man::Paintworld_2_man_L(int x, int y)
{
	SetConsolePosition(x - 4, y);
	cout << "��";
	GSetConsoleAttribute(64);
	SetConsolePosition(x - 4, y + 1);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 1 - 4, y + 2);
	cout << "��";

	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x, y + 2);
	cout << "  ";

	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
	SetConsolePosition(x - 2, y + 1);
	cout << "��";
}

void Man::Paintworld_2_man_R(int x, int y)
{
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(64);
	SetConsolePosition(x, y + 1);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 1, y + 2);
	cout << "��";

	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x - 4, y + 2);
	cout << "  ";

	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x - 4, y);
	cout << "��";
	SetConsolePosition(x - 2, y + 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1);
	cout << "��";
}

void Man::Paintworld_2_man_L2(int x, int y)
{
	SetConsolePosition(x - 4, y);
	cout << "��";
	GSetConsoleAttribute(64);
	SetConsolePosition(x - 4, y + 1);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 1 - 4, y + 2);
	cout << "��";



	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x, y + 1);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "��";
	SetConsolePosition(x, y + 2);
	cout << "��";
	
}

void Man::Paintworld_2_man_R2(int x, int y)
{

	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(64);
	SetConsolePosition(x, y + 1);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 1, y + 2);
	cout << "��";

	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x - 4, y);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x - 4, y + 1);
	cout << "  ";

	SetConsolePosition(x - 2, y + 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 2);
	cout << "��";
}


/*���޵�*/
// ������

void Man::Paintworld_3_man_L(int x, int y)
{
	GSetConsoleAttribute(128);
	//SetConsolePosition(20, 20);
	SetConsolePosition(x, y+1);
	cout << "��";
	SetConsolePosition(x - 2, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y+1);
	cout << "��";

	SetConsolePosition(x - 6, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1+1);
	cout << "/";
	SetConsolePosition(x - 1, y + 1+1);
	cout << "\\";
}

void Man::Paintworld_3_man_R(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y+1);
	cout << "��";
	SetConsolePosition(x - 2, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y+1);
	cout << "��";

	SetConsolePosition(x - 6, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1+1);
	cout << "/";
	SetConsolePosition(x - 1, y + 1+1);
	cout << "\\";
}


void Man::Paintworld_3_man_L2(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y+1);
	cout << "��";
	SetConsolePosition(x - 2, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y+1);
	cout << "��";

	SetConsolePosition(x - 6, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1+1);
	cout << "\\";
	SetConsolePosition(x - 1, y + 1+1);
	cout << "/";
}

void Man::Paintworld_3_man_R2(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y+1);
	cout << "��";
	SetConsolePosition(x - 2, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y+1);
	cout << "��";

	SetConsolePosition(x- 6, y+1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1+1);
	cout << "\\";
	SetConsolePosition(x - 1, y + 1+1);
	cout << "/";
}

void Man::WrapWorld_3_man_R(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y + 1);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x - 4, y + 1);
	cout << "  ";

	SetConsolePosition(x - 6, y + 1);
	cout << "  ";
	SetConsolePosition(x - 4, y + 1 + 1);
	cout << " ";
	SetConsolePosition(x - 1, y + 1 + 1);
	cout << " ";
}
/*������*/
/*�����*/

void Man::Paintworld_4_man_L(int x, int y)
{
	GSetConsoleAttribute(140);
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y - 1);
	cout << "�x";

	SetConsolePosition(x + 2, y);
	cout << "��";
	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
}

void Man::Paintworld_4_man_R(int x, int y)
{
	GSetConsoleAttribute(140);
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y - 1);
	cout << "�x";

	SetConsolePosition(x + 2, y);
	cout << "��";
	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
}


void Man::Paintworld_4_man_L2(int x, int y)
{
	GSetConsoleAttribute(140);
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y - 1);
	cout << "�x";

	SetConsolePosition(x + 2, y);
	cout << "��";
	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
}

void Man::Paintworld_4_man_R2(int x, int y)
{
	GSetConsoleAttribute(140);
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y - 1);
	cout << "�x";

	SetConsolePosition(x + 2, y);
	cout << "��";
	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
}


/*�����*/
void Man::InitialMan()
{
	current_level = 0;
	
	
	
	SetEdge(28, 28);
	Blood = 40;
	Life = 0;
	Goodtime = 0;
	Badtime = 0;
	GoodtimeRand = 0;
	BadtimeRand = 0;

	//Dao = world_2;

	money = 0;
	
	walk = 21;
}
void Man::NewLife()
{
	
	
	SetEdge(28, 27);
	Blood = 40;
	Life = 0;
	Goodtime = 0;
	Badtime = 0;
	GoodtimeRand = 0;
	BadtimeRand = 0;

	//Dao = world_4;

	money = 0;

	walk = 21;
}
void Man::PaintManDie()//δ���
{
	//GSetConsoleAttribute(136);
	//WrapMan(28, 28);
	//SetColor(GetBackGroundPoint(28, 28));
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GReadAndWrite();
	GSetConsoleAttribute(15);
	SetConsolePosition(40, 19);
	cout << "You are die !";
	GReadAndWrite();
	while (true)
	{
		if (GetAsyncKeyState(VK_RETURN))break;
	}
	GSetConsoleAttribute(128);
	
	Sleep(100);
}

void Man::RunManDie()//���Ż�
{
	
	int t = rand() % 5 + 1;
	//if (t == 10)Dao = world_5;
	 //if (t == 2 || t == 4 || t == 8)Dao = world_2;
	if (t == 1 ||t==5)Dao = world_1;
	else if (t == 2 )Dao = world_2;
	else if (t == 3)Dao = world_3;
	else if (t == 4)Dao = world_4;
	if (current_level == Level_6)
	{
		Dao = world_2;
	}
	
	//}
//	Dao = world_2;
}
//������������

//����������Ե�Ͷ�Ե��������ĵ���ѡ��



int Man::GetCurrentLevel()
{
	return current_level;
}

void Man::SetCurrentLevel(int in)
{
	current_level = in;
}

int Man::GetL_edge()
{
	return L_edge;
}

int Man::GetR_edge()
{
	return R_edge;
}

int Man::GetU_edge()
{
	return U_edge;
}

int Man::GetD_edge()
{
	return D_edge;
}

void Man::SetMax_L(int in)
{
	Max_L = in;
}

void Man::SetMax_R(int in)
{
	Max_R = in;
}

void Man::SetMax_U(int in)
{
	Max_U = in;
}

void Man::SetMax_D(int in)
{
	Max_D = in;
}

int Man::GetDao()
{
	return Dao;
}

void Man::SetBlood(int in)
{
	Blood = in;
}

int Man::GetBlood()
{
 return Blood;
}

int Man::GetMax_L()
{
	return Max_L;
}

int Man::GetMax_R()
{
	return Max_R;
}

int Man::GetMax_U()
{
	return Max_U;
}

int Man::GetMax_D()
{
	return Max_D;
}

/*δ����*//*���ڲ�ͬ�ı���Ҫ���б任*/
void Man::SetColor(int t,int m)
{
	if (m == 0)
	{
		if (t == 0)GSetConsoleAttribute(11);
		else if (t == 257)
			GSetConsoleAttribute(139);
	}
	else if (m == 1)
	{
		if (t == 0)GSetConsoleAttribute(12);
		else if (t == 257)
			GSetConsoleAttribute(140);
	}
	else if (m == 2)
	{
		if (t == 0)GSetConsoleAttribute(1);
		else if (t == 257)
			GSetConsoleAttribute(129);
	}

}

bool Man::IsManDie()
{
	if(Life<=0)
	return true;
	return false;
}

void Man::PaintBlood()
{
	GSetConsoleAttribute(139);
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(0 + 2 * i, 0);
		SetColor(GetBackGroundPoint(0 + 2 * i, 0));
		cout << "��";
	}
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(0 + 2 * i, 2);
		SetColor(GetBackGroundPoint(0 + 2 * i, 2));
		cout << "��";
	}
	SetConsolePosition(0, 1);
	SetColor(GetBackGroundPoint(0, 1));
	cout << "��";

	SetConsolePosition(4, 1);
	SetColor(GetBackGroundPoint(4, 1), 1);
	for (int i = 0; i < Blood; i+=4)
	{
		cout << "�z";
	}
}
void Man::WrapBlood()
{
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(0 + 2 * i, 0);
		//SetColor(GetBackGroundPoint(0 + 2 * i, 0));
		cout << "  ";
	}
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(0 + 2 * i, 2);
	//	SetColor(GetBackGroundPoint(0 + 2 * i, 2));
		cout << "  ";
	}
	SetConsolePosition(0, 1);
	//SetColor(GetBackGroundPoint(0, 1));
	cout << "  ";

	SetConsolePosition(4, 1);
	//SetColor(GetBackGroundPoint(4, 1), 1);
	for (int i = 0; i < Blood; i += 4)
	{
		cout << "  ";
	}
}
//������Ϣ����� δ����
void Man::PaintMessage()
{
	//��������
	
	
	
	//Ѫ��
	GSetConsoleAttribute(139);
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(30 + 2 * i, 10-5);
		GSetConsoleAttribute(139);
		//SetColor(GetBackGroundPoint(110 + 2 * i, 10-5));
		cout << "��";
	}
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(30 + 2 * i, 12-5);
		//SetColor(GetBackGroundPoint(110 + 2 * i,12-5));
		cout << "��";
	}
	SetConsolePosition(30, 11-5);
	//SetColor(GetBackGroundPoint(110, 11-5));
	cout << "��";

	SetConsolePosition(34, 11-5);
	GSetConsoleAttribute(140);
	//SetColor(GetBackGroundPoint(114, 11-5), 1);
	for (int i = 0; i < Blood; i+=4)
	{
		cout << "�z";
	}
	//�������ڵ�
	SetConsolePosition(30, 10);
	GSetConsoleAttribute(128);
	cout << "����֮��      :";
	switch (GetDao())
	{
	case world_1:
		cout << "�˵�";
		break;
	case world_2:
		cout << "���޵�";
		break;
	case world_3:
		cout << "������";
		break;
	case world_4:
		cout << "�����";
		break;
	case world_5:
		cout << "������";
		break;
	case world_6:
		cout << "���";
		break;
	}
	SetConsolePosition(30, 12);
	cout << "���� :" << GetLife();
	SetConsolePosition(30, 14);
	cout << "���ڹؿ���" << GetCurrentLevel();
}

int Man::GetGameStartTime()
{
	return GameStartTime;
}

void Man::SetGameStartTime(int in)
{
	GameStartTime = in;
}

void Man::SetLife(int in)
{
	Life = in;
}

int Man::GetLife()
{
	return Life;
}


//
Npc1::Npc1()
{
	L1 = 0;
	L2 = 0;
	L3 = 0;
	L4 = 0;
	L5 = 0;
	L6 = 0;
}

void Npc1::PaintTalk(int in)
{
	AffairChose(1);
}

void Npc1::WrapNPC(int x, int y)
{
	SetConsolePosition(x, y - 1);
	cout << "  ";
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x, y + 1);
	cout << "  ";
	SetConsolePosition(x, y + 2);
	cout << "  ";
	SetConsolePosition(x, y + 3);
	cout << "  ";
	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x + 2, y);
	cout << "  ";
	SetConsolePosition(x - 4, y);
	cout << "  ";
	SetConsolePosition(x + 4, y);
	cout << "  ";


	SetConsolePosition(x - 4, y - 2);
	cout << "  ";
	SetConsolePosition(x + 4, y - 2);
	cout << "  ";
	SetConsolePosition(x - 6, y);
	cout << "  ";
	SetConsolePosition(x + 6, y);
	cout << "  ";
	SetConsolePosition(x - 4, y + 2);
	cout << "  ";
	SetConsolePosition(x + 4, y + 2);
	cout << "  ";
}

void Npc1::PaintNPC(int x, int y)
{
	SetEdge(x, y);
	GSetConsoleAttribute(143);
	SetConsolePosition(x, y - 1);
	cout << "��";
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
	SetConsolePosition(x, y + 2);
	cout << "��";
	SetConsolePosition(x, y + 3);
	cout << "��";
	SetConsolePosition(x - 2, y);
	cout << "��";
	SetConsolePosition(x + 2, y);
	cout << "��";
	SetConsolePosition(x - 4, y);
	cout << "��";
	SetConsolePosition(x + 4, y);
	cout << "��";
     GSetConsoleAttribute(128);
	if (L1)
		GSetConsoleAttribute(140);
	SetConsolePosition(x - 4, y - 2);//1
	cout << "��";
	GSetConsoleAttribute(128);

	if (L2)GSetConsoleAttribute(129);
	SetConsolePosition(x + 4, y - 2);//2
	cout << "��";
	GSetConsoleAttribute(128);
	if (L3)GSetConsoleAttribute(132);
	SetConsolePosition(x - 6, y);//3
	cout << "��";
	GSetConsoleAttribute(128);
	if (L4)GSetConsoleAttribute(142);
	SetConsolePosition(x + 6, y);//4
	cout << "��";
	GSetConsoleAttribute(128);
	if (L5)GSetConsoleAttribute(139);
	SetConsolePosition(x - 4, y + 2);//5
	cout << "��";
	GSetConsoleAttribute(128);
	if (L6)GSetConsoleAttribute(141);
	SetConsolePosition(x + 4, y + 2);//6
	cout << "��"; GSetConsoleAttribute(128);
}
bool Npc1::IsTalk(Man&man_in)//������NPC�����������ж�
{
	int t = 0;
	
	if (L1&&L2&&L3&&L4&&L5&&L6)
	{
		t++;
	}
	for (int i = MaxL_edge; i <= MaxR_edge; i++)
	{
		if (i >= man_in.GetL_edge() && i <= man_in.GetR_edge())
		{
			t++;
			break;
		}
	}
	for (int i = MaxU_edge; i <= MaxD_edge; i++)
	{
		if (i >= man_in.GetU_edge() && i <= man_in.GetD_edge())
		{
			t++;
			break;
		}
	}
	if (t == 3)return 1;
	return 0;
}
void Npc1::SetEdge(int x, int y)
{
	MaxL_edge = x - 6;
	MaxR_edge = x + 6;
	MaxU_edge = y - 2;
	MaxD_edge = y+2;
}
void Npc1::SetL1(int in)
{
	L1 = in;
}
void Npc1::SetL2(int in)
{
	L2= in;
}
void Npc1::SetL3(int in)
{
	L3 = in;
}
void Npc1::SetL4(int in)
{
	L4 = in;
}
void Npc1::SetL5(int in)
{
	L5 = in;
}
void Npc1::SetL6(int in)
{
	L6 = in;
}
Npc1::~Npc1()
{
}
//
Npc2::Npc2()
{
}
bool Npc2::IsTalk(Man&man_in)
{
	if (man_in.GetR_edge() == MaxL_edge - 1);
	return 1;
	if (man_in.GetL_edge() == MaxR_edge + 1)
		return 1;
	if (man_in.GetD_edge() == MaxU_edge - 1)
		return 1;
	//if (man_in.GetL_edge() == MaxR_edge + 1)
		//return 1;
	return 0;
}
void Npc2::PaintTalk(int in)
{
	AffairChose(in);
}

void Npc2::WrapNPC(int x, int y)
{
	SetEdge(x, y);
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x + 2, y);
	cout << "  ";
}

void Npc2::PaintNPC(int x, int y)
{
	SetEdge(x, y);
	GSetConsoleAttribute(4);
	SetConsolePosition(x, y);
	cout << "��";
	GSetConsoleAttribute(0);
	SetConsolePosition(x, y-1);
	cout << "#";
	SetConsolePosition(x, y+1);
	cout << "#";
	SetConsolePosition(x-1, y);
	cout << "#";
	SetConsolePosition(x+2, y);
	cout << "#";
	SetConsolePosition(x + 2, y-1);
	cout << "#";
	SetConsolePosition(x + 2, y+1);
	cout << "#";
	SetConsolePosition(x + 1, y +1);
	cout << "#";
	SetConsolePosition(x + 1, y-1);
	cout << "#"; 
	SetConsolePosition(x - 1, y+1);
	cout << "#";
	SetConsolePosition(x - 1, y-1);
	cout << "#";
}

void Npc2::SetEdge(int x, int y)
{
	MaxL_edge = x -2;
	MaxR_edge = x + 2;
	MaxU_edge = y ;
	MaxD_edge = y + 1;
}

Npc2::~Npc2()
{
}
//
Npc3::Npc3()
{
}
bool Npc3::IsTalk(Man&man_in)
{
	if (man_in.GetR_edge() == MaxL_edge - 1);
	return 1;
	if (man_in.GetL_edge() == MaxR_edge + 1)
		return 1;
	return 0;
}
void Npc3::PaintTalk(int in)
{
	AffairChose(in);
}

void Npc3::SetEdge(int x, int y)
{
}

void Npc3::WrapNPC(int x, int y)
{
}

void Npc3::PaintNPC(int x, int y)
{
}

Npc3::~Npc3()
{
}

Npc::Npc()
{
	
}

int Npc::GetMaxL_edge()
{
	return MaxL_edge;
}

int Npc::GetMaxR_edge()
{
	return MaxR_edge;
}

int Npc::GetMaxU_edge()
{
	return MaxU_edge;
}

int Npc::GetMaxD_edge()
{
	return MaxD_edge;
}

Npc::~Npc()
{
}
