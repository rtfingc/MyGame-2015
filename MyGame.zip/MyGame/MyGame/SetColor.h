#pragma once
#ifndef SETCOLOR_H
#define SETCOLOR_H

void SetAllBackgroundcolor();
#endif;
