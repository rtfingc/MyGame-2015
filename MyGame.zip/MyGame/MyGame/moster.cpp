﻿#include "moster.h"

#include<iostream>
using namespace std;
moster::moster()
{
	Max_D = 0;
	Max_L = 0;
	Max_R = 0;
	Max_U = 0;
}


unsigned int moster::GetMax_L()
{
	return Max_L;
}

unsigned int moster::GetMax_R()
{
	return Max_R;
}

unsigned int moster::GetMax_U()
{
	return Max_U;
}

unsigned int moster::GetMax_D()
{
	return Max_D;
}

moster::~moster()
{
}
//*/
//可上下移动的moster
moster1::moster1()//walk
{
	walk = 11;
}

void moster1::PaintMoster(int x, int y,int direction)//walk 1 代表向上 2，代表向下
{
	//InitialEdge(x, y);
	InitialEdge(x, y);
	switch (direction)
	{
	case 1:
		if (walk == 11 || walk == 21)
		{
			PaintMoster1U_1(x, y);

			walk = 12;
		}
		else if (walk == 12 || walk == 22)
		{
			PaintMoster1U_2(x, y);
			walk = 11;
		}

		break;
	case 2:
		if (walk == 21 || walk == 11)
		{
			PaintMoster1D_1(x, y);

			walk = 22;
		}
		else if (walk == 22 || walk == 12)
		{
			PaintMoster1D_2(x, y);
			walk = 21;
		}
		break;
	}
	
}

void moster1::InitialEdge(int x, int y)
{
	Max_L = x - 3; Max_R = x + 11;
	Max_D = y + 2; Max_U = y - 2;
}

void moster1::WrapMoster(int x, int y)
{
	InitialEdge(x, y);
	//GSetConsoleAttribute(12);
GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "  ";
	//GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << " ";
	SetConsolePosition(x + 2, y);
	cout << " ";

	SetConsolePosition(x + 2, y - 1);
	cout << " ";
	SetConsolePosition(x + 1, y + 1);
	cout << " ";
	SetConsolePosition(x + 2, y + 1);
	cout << " ";
	SetConsolePosition(x + 3, y + 1);
	cout << " ";
	
	SetConsolePosition(x + 3, y + 2);
	cout << "  ";
	SetConsolePosition(x + 5, y + 2);
	cout << "  ";
	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y);
	cout << "  ";
	SetConsolePosition(x + 7, y);
	cout << "  ";
	SetConsolePosition(x + 5, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 1);
	cout << "  ";
	SetConsolePosition(x + 9, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 2);
	cout << "  ";
	SetConsolePosition(x + 9, y - 2);
	cout << "  ";
	SetConsolePosition(x + 11, y - 2);
	cout << "  ";

	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y + 1);
	cout << "  ";
	SetConsolePosition(x + 7, y + 2);
	cout << "  ";
	SetConsolePosition(x, y);
	cout << "  ";
	//GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << " ";
	SetConsolePosition(x + 2, y);
	cout << " ";

	SetConsolePosition(x + 2, y - 1);
	cout << " ";
	SetConsolePosition(x + 1, y + 1);
	cout << " ";
	SetConsolePosition(x + 2, y + 1);
	cout << " ";
	SetConsolePosition(x + 3, y + 1);
	cout << " ";
//	GSetConsoleAttribute(128);

	
	SetConsolePosition(x + 3, y + 2);
	cout << "  ";

	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y);
	cout << "  ";
	SetConsolePosition(x + 7, y);
	cout << "  ";
	SetConsolePosition(x + 5, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 1);
	cout << "  ";
	SetConsolePosition(x + 9, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 2);
	cout << "  ";
	SetConsolePosition(x + 9, y - 2);
	cout << "  ";
	SetConsolePosition(x + 11, y - 2);
	cout << "  ";
	
}

void moster1::PaintMoster1U_1(int x, int y)
{
	GSetConsoleAttribute(12);

	SetConsolePosition(x, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";

	SetConsolePosition(x + 2, y - 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 2, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	GSetConsoleAttribute(128);

	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y + 1);
	cout << "  ";
	SetConsolePosition(x + 7, y + 2);
	cout << "  ";

	SetConsolePosition(x + 3, y + 2);
	cout << "▔";

	SetConsolePosition(x + 3, y);
	cout << "◢";
	SetConsolePosition(x + 5, y);
	cout << "▔";
	SetConsolePosition(x + 7, y);
	cout << "▔";
	SetConsolePosition(x + 5, y - 1);
	cout << "◢";
	SetConsolePosition(x + 7, y - 1);
	cout << "▔";
	SetConsolePosition(x + 9, y - 1);
	cout << "▔";
	SetConsolePosition(x + 7, y - 2);
	cout << "◢";
	SetConsolePosition(x + 9, y - 2);
	cout << "▔";
	SetConsolePosition(x + 11, y - 2);
	cout << "▔";
}

void moster1::PaintMoster1U_2(int x, int y)
{
	GSetConsoleAttribute(12);

	SetConsolePosition(x, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";

	SetConsolePosition(x + 2, y - 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 2, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 3, y + 2);
	cout << "▔";
	SetConsolePosition(x + 5, y + 2);
	cout << "  ";
	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y);
	cout << "  ";
	SetConsolePosition(x + 7, y);
	cout << "  ";
	SetConsolePosition(x + 5, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 1);
	cout << "  ";
	SetConsolePosition(x + 9, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 2);
	cout << "  ";
	SetConsolePosition(x + 9, y - 2);
	cout << "  ";
	SetConsolePosition(x + 11, y - 2);
	cout << "  ";

	SetConsolePosition(x + 3, y);
	cout << "◣";
	SetConsolePosition(x + 5, y + 1);
	cout << "◣";
	SetConsolePosition(x + 7, y + 2);
	cout << "◣";
}

void moster1::PaintMoster1D_1(int x, int y)
{
	GSetConsoleAttribute(12);

	SetConsolePosition(x, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";

	SetConsolePosition(x + 2, y - 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 2, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	GSetConsoleAttribute(128);

	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y + 1);
	cout << "  ";
	SetConsolePosition(x + 7, y + 2);
	cout << "  ";

	SetConsolePosition(x + 3, y + 2);
	cout << "▔";

	SetConsolePosition(x + 3, y);
	cout << "◢";
	SetConsolePosition(x + 5, y);
	cout << "▔";
	SetConsolePosition(x + 7, y);
	cout << "▔";
	SetConsolePosition(x + 5, y - 1);
	cout << "◢";
	SetConsolePosition(x + 7, y - 1);
	cout << "▔";
	SetConsolePosition(x + 9, y - 1);
	cout << "▔";
	SetConsolePosition(x + 7, y - 2);
	cout << "◢";
	SetConsolePosition(x + 9, y - 2);
	cout << "▔";
	SetConsolePosition(x + 11, y - 2);
	cout << "▔";
}

void moster1::PaintMoster1D_2(int x, int y)
{
	GSetConsoleAttribute(12);

	SetConsolePosition(x, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x - 1, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";

	SetConsolePosition(x + 2, y - 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 2, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 3, y + 2);
	cout << "▔";
	SetConsolePosition(x + 5, y + 2);
	cout << "  ";
	SetConsolePosition(x + 3, y);
	cout << "  ";
	SetConsolePosition(x + 5, y);
	cout << "  ";
	SetConsolePosition(x + 7, y);
	cout << "  ";
	SetConsolePosition(x + 5, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 1);
	cout << "  ";
	SetConsolePosition(x + 9, y - 1);
	cout << "  ";
	SetConsolePosition(x + 7, y - 2);
	cout << "  ";
	SetConsolePosition(x + 9, y - 2);
	cout << "  ";
	SetConsolePosition(x + 11, y - 2);
	cout << "  ";

	SetConsolePosition(x + 3, y);
	cout << "◣";
	SetConsolePosition(x + 5, y + 1);
	cout << "◣";
	SetConsolePosition(x + 7, y + 2);
	cout << "◣";
}

moster1::~moster1()
{
}

//可左右移动moster
moster2::moster2()//walk 10位数字为1 表示向左 为2 表示向右
{
	
	walk = 11;
}

void moster2::PaintMoster(int x, int y,int direction)
{
	InitialEdge( x,  y);
	switch (direction)
	{
	case 1:
		if (walk == 11 || walk == 21)
		{
			PaintMoster2L_1(x, y);

			walk = 12;
		}
		else if (walk == 12||walk==22)
		{
			PaintMoster2L_2(x, y);
			walk = 11;
		}
		
		break;
	case 2:
		if (walk == 21||walk==11)
		{
			PaintMoster2R_1(x, y);

			walk = 22;
		}
		else if (walk == 22||walk==12)
		{
			PaintMoster2R_2(x, y);
			walk = 21;
		}
			break;
	}
	
}

void moster2::InitialEdge(int x, int y)
{
	Max_L = x - 6; Max_R = x + 1;
	Max_D = y + 2; Max_U = y - 2;
}

void moster2::WrapMoster(int x, int y)
{
	InitialEdge(x, y);
	
	GSetConsoleAttribute(128);
	for (int i = Max_L-1; i <= Max_R+3; i++)
	{
		for (int j = Max_U; j < Max_D; j++)
		{
			SetConsolePosition(i, j);
			cout << ' ';
		}
	}
	
}

void moster2::PaintMoster2L_1(int x, int y)
{
	GSetConsoleAttribute(12);
	SetConsolePosition(x - 2, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x, y);
	cout << "#";
	SetConsolePosition(x + 1, y);
	cout << "#";
	SetConsolePosition(x - 3, y);
	cout << "#";

	SetConsolePosition(x - 5, y);
	cout << "#";
	SetConsolePosition(x - 6, y);
	cout << "#";

	SetConsolePosition(x, y + 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x - 2, y + 1);
	cout << "#";
	SetConsolePosition(x - 4, y + 1);
	cout << "#";

	SetConsolePosition(x - 6, y + 1);
	cout << "#";
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(x - 6 + i, y + 2);
		cout << "#";
	}

	for (int i = 0; i < 6; i++)
	{
		SetConsolePosition(x - 5 + i, y - 1);
		cout << "#";
	}

	SetConsolePosition(x, y - 2);
	cout << "#";
	GSetConsoleAttribute(128);
}

void moster2::PaintMoster2L_2(int x, int y)
{
	GSetConsoleAttribute(128);
	//////////////////
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(x - 6 + i, y + 2);
		cout << " ";
	}
	////////
	GSetConsoleAttribute(12);
	SetConsolePosition(x - 2, y);
	cout << "●";
	GSetConsoleAttribute(0);
	SetConsolePosition(x, y);
	cout << "#";
	SetConsolePosition(x + 1, y);
	cout << "#";
	SetConsolePosition(x - 3, y);
	cout << "#";

	SetConsolePosition(x - 5, y);
	cout << "#";
	SetConsolePosition(x - 6, y);
	cout << "#";

	SetConsolePosition(x, y + 1);
	cout << "#";
	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x - 2, y + 1);
	cout << "#";
	SetConsolePosition(x - 4, y + 1);
	cout << "#";

	SetConsolePosition(x - 6, y + 1);
	cout << "#";


	for (int i = 0; i < 9; i++)
	{
		SetConsolePosition(x - 6 + i, y + 2);
		cout << "#";
	}

	for (int i = 0; i < 6; i++)
	{
		SetConsolePosition(x - 5 + i, y - 1);
		cout << "#";
	}

	SetConsolePosition(x, y - 2);
	cout << "#";
	GSetConsoleAttribute(128);
}

void moster2::PaintMoster2R_1(int x, int y)
{
	GSetConsoleAttribute(128);
	// for (int i = 0; i < 10; i++)
	//  {
	//	  SetConsolePosition(x - 6 + i, y + 2);
	//	  cout << " ";
	//  }
	SetConsolePosition(x - 6, y + 2);
	cout << " ";
	GSetConsoleAttribute(12);
	SetConsolePosition(x - 2, y);
	cout << "●";
	GSetConsoleAttribute(0);
	//GReadAndWrite();
	SetConsolePosition(x, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";
	SetConsolePosition(x + 3, y);
	cout << "#";
	SetConsolePosition(x - 3, y);
	cout << "#";
	SetConsolePosition(x - 4, y);
	cout << "#";

	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	SetConsolePosition(x - 1, y + 1);
	cout << "#";
	SetConsolePosition(x - 3, y + 1);
	cout << "#";
	SetConsolePosition(x - 4, y + 1);
	cout << "#";
	for (int i = 1; i < 10; i++)
	{
		SetConsolePosition(x - 6 + i, y + 2);
		cout << "#";
	}
	for (int i = 0; i < 6; i++)
	{
		SetConsolePosition(x - 3 + i, y - 1);
		cout << "#";
	}
	SetConsolePosition(x - 3, y - 2);
	cout << "#";
	GSetConsoleAttribute(128);
}

void moster2::PaintMoster2R_2(int x, int y)
{
	GSetConsoleAttribute(12);
	SetConsolePosition(x - 2, y);
	cout << "●";
	GSetConsoleAttribute(0);
	//GReadAndWrite();
	SetConsolePosition(x, y);
	cout << "#";
	SetConsolePosition(x + 2, y);
	cout << "#";
	SetConsolePosition(x + 3, y);
	cout << "#";
	SetConsolePosition(x - 3, y);
	cout << "#";
	SetConsolePosition(x - 4, y);
	cout << "#";

	SetConsolePosition(x + 1, y + 1);
	cout << "#";
	SetConsolePosition(x + 3, y + 1);
	cout << "#";
	SetConsolePosition(x - 1, y + 1);
	cout << "#";
	SetConsolePosition(x - 3, y + 1);
	cout << "#";
	SetConsolePosition(x - 4, y + 1);
	cout << "#";
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(x - 6 + i, y + 2);
		cout << "#";
	}
	for (int i = 0; i < 6; i++)
	{
		SetConsolePosition(x - 3 + i, y - 1);
		cout << "#";
	}
	SetConsolePosition(x - 3, y - 2);
	cout << "#";
	GSetConsoleAttribute(128);
}

moster2::~moster2()
{
}

//bossmoster 可攻击
moster3::moster3()
{
}

void moster3::PaintMoster(int, int)
{
}

void moster3::InitialEdge(int, int)
{
}

void moster3::WrapMoster(int, int)
{
}

moster3::~moster3()
{
}

moster4::moster4()
{
}

void moster4::PaintMoster(int x, int y, int)
{
	InitialEdge(x, y);
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "◤";
	SetConsolePosition(x + 2, y);
	cout << "◥";
	SetConsolePosition(x + 2, y + 1);
	cout << "◢";
	SetConsolePosition(x, y + 1);
	cout << "◣";
	SetConsolePosition(x + 1, y - 1);
	cout << "↑";
	SetConsolePosition(x + 1, y + 2);
	cout << "↓";
	SetConsolePosition(x - 2, y);
	cout << "←";
	SetConsolePosition(x - 2, y + 1);
	cout << "←";
	SetConsolePosition(x + 4, y);
	cout << "→";
	SetConsolePosition(x + 4, y + 1);
	cout << "→";
}

void moster4::InitialEdge(int x, int y)
{
	Max_L = x - 2; Max_R = x + 6;
	Max_D = y + 2; Max_U = y - 1;
}

void moster4::WrapMoster(int x, int y)
{
	InitialEdge(x, y);
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x + 2, y);
	cout << "  ";
	SetConsolePosition(x + 2, y + 1);
	cout << "  ";
	SetConsolePosition(x, y + 1);
	cout << "  ";
	SetConsolePosition(x + 1, y - 1);
	cout << "  ";
	SetConsolePosition(x + 1, y + 2);
	cout << "  ";
	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x - 2, y + 1);
	cout << "  ";
	SetConsolePosition(x + 4, y);
	cout << "  ";
	SetConsolePosition(x + 4, y + 1);
	cout << "  ";
}

moster4::~moster4()
{
}




Jiguang::Jiguang()
{
	MaxD_edge = 0;
	MaxL_edge = 0; MaxR_edge = 0; MaxU_edge = 0;
	Base_x = 0; Base_y = 0;
}

int Jiguang::GetMaxL_edge()
{
	return MaxL_edge;
}

int Jiguang::GetMaxR_edge()
{
	return MaxR_edge;
}

int Jiguang::GetMaxU_edge()
{
	return MaxU_edge;
}

int Jiguang::GetMaxD_edge()
{
	return MaxD_edge;
}

Jiguang::~Jiguang()
{
}
//
Jiguang1::Jiguang1()
{
	Light = 0;
}

void Jiguang1::InitialJiguang()
{
	Light = 0;
}

void Jiguang1::PaintJiGuang(int x, int y ,Man&man_in)
{
	SetEdge(x, y);
	GSetConsoleAttribute(128);
	
	SetConsolePosition(x - 2, y - 5);
	cout << "\\";
	SetConsolePosition(x + 2, y - 5);
	cout << "/";
	SetConsolePosition(x - 2, y - 6);
	cout << "/";
	SetConsolePosition(x + 2, y - 6);
	cout << "\\";
	GSetConsoleAttribute(0);
SetConsolePosition(Base_x, Base_y);
	cout << "#";
	for (int i = 0; i < 4; i++)
	{
		SetConsolePosition(Base_x, Base_y-1-i);
		cout << "#";
	}
	SetConsolePosition(x-1, y-4);
	cout << "#";
	SetConsolePosition(x, y - 4);
	cout << "#";
	SetConsolePosition(x+1, y - 4);
	cout << "#";
	
	if (Light == 1)
	{
     SetConsolePosition(Base_x, Base_y - 5);
	GSetConsoleAttribute(204);
	cout << "#";
	}
	else
	{
     if (IsLighted(man_in))
      {
		Light = 1;
		SetConsolePosition(Base_x, Base_y- 5);
		GSetConsoleAttribute(204);
		cout << "#";
     }
	}
	GSetConsoleAttribute(128);
}

void Jiguang1::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = x - 2;
	MaxR_edge = x + 2;
	MaxU_edge = y - 5;
	MaxD_edge = y;
}

void Jiguang1::WrapJigung(int x, int y)
{
	SetEdge(x, y);
	SetConsolePosition(Base_x - 1, Base_y);
	cout << " ";
	SetConsolePosition(Base_x , Base_y);
	cout << " ";
	SetConsolePosition(Base_x + 1, Base_y);
	cout << " ";
	SetConsolePosition(x - 2, y - 6);
	cout << "  ";
	SetConsolePosition(x + 2, y - 6);
	cout << " ";
	for (int i = 0; i < 4; i++)
	{
		SetConsolePosition(Base_x, Base_y - 1 - i);
		cout << " ";
	}
	SetConsolePosition(x - 1, y - 4);
	cout << " ";
	SetConsolePosition(x, y - 4);
	cout << " ";
	SetConsolePosition(x + 1, y - 4);
	cout << " ";
	SetConsolePosition(x - 2, y - 5);
	cout << " ";
	SetConsolePosition(x + 2, y - 5);
	cout << " ";
	
		SetConsolePosition(Base_x, Base_y - 5);
		//GSetConsoleAttribute(124);
		cout << " ";
	
	
}

bool Jiguang1::IsLighted(Man &man_in)
{
	int t = 0;
	for (int i = man_in.GetL_edge()-1; i <= man_in.GetR_edge()+2;i++)
	{ 
		if (i >= MaxL_edge&&i <= MaxR_edge)
		{
			t++;
			break;
		}
	}
	if (man_in.GetD_edge() <= MaxD_edge + 1 && man_in.GetD_edge() >= (MaxD_edge + MaxU_edge) / 2)t++;
	if (t==2 )return 1;
	return 0;
}

void Jiguang1::SetLight(int in)
{
	Light = in;
}

int Jiguang1::GetLight()
{
	return Light;
}

Jiguang1::~Jiguang1()
{
}

Jiguang6::Jiguang6()
{
}

void Jiguang6::InitialJiguang()
{
	state = 0;
}

void Jiguang6::PaintJiGuang(int x, int y,Man&man_in)
{
	SetEdge(x, y);
	if (state == 0)
	{
		GSetConsoleAttribute(128);
		SetConsolePosition(x - 2, y);
		cout << "◢";
		SetConsolePosition(x + 2, y);
		cout << "◤";
		SetConsolePosition(x, y - 1);
		cout << "◣";
		SetConsolePosition(x, y + 1);
		cout << "◥";
		state = 1;
	}
	//*GReadAndWrite();
	else if (state == 1)
	{
		SetConsolePosition(x - 2, y);
		cout << "◣";
		SetConsolePosition(x + 2, y);
		cout << "◥";
		SetConsolePosition(x, y - 1);
		cout << "◤";
		SetConsolePosition(x, y + 1);
		cout << "◢";
		state = 0;
	}

}

void Jiguang6::WrapJigung(int x, int y)
{
	SetEdge(x, y);
	GSetConsoleAttribute(128);
	SetConsolePosition(x - 2, y);
	cout << "  ";
	SetConsolePosition(x + 2, y);
	cout << "  ";
	SetConsolePosition(x, y - 1);
	cout << "  ";
	SetConsolePosition(x, y + 1);
	cout << "  ";
}

void Jiguang6::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = x -2;
	MaxR_edge = x + 2;
	MaxU_edge = y - 2;
	MaxD_edge = y+2;
}

Jiguang6::~Jiguang6()
{
}
//////
Jiguang5::Jiguang5()
{
}

void Jiguang5::InitialJiguang()
{
}

void Jiguang5::PaintJiGuang(int x, int y,Man&man_in)
{
	SetEdge(x, y);GSetConsoleAttribute(68);
	for (int i = 0; i < 5; i++)
	{
		SetConsolePosition(x, y-i);

		cout << "#";
	}
	GSetConsoleAttribute(128);

}

void Jiguang5::WrapJigung(int x, int y)
{
	SetEdge(x, y); GSetConsoleAttribute(128);
	for (int i = 0; i < 5; i++)
	{
		SetConsolePosition(x, y - i);

		cout << " ";
	}
}

void Jiguang5::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = x-1;
	MaxR_edge = x +1;
	MaxU_edge = y - 5;
	MaxD_edge = y;
}

Jiguang5::~Jiguang5()
{
}

Jiguang4::Jiguang4()
{
}

void Jiguang4::InitialJiguang()
{
}

void Jiguang4::PaintJiGuang(int x, int y, Man&man_in)
{
	SetEdge(x, y);
	//GSetConsoleAttribute(204);
	for (int i = x; i <= x+10; i += 2)
	{
		for (int j = y-4; j <= y; j++)
		{
			SetConsolePosition(i ,j);
			cout << "■";
		}
	}
}

void Jiguang4::WrapJigung(int x, int  y)
{
	SetEdge(x, y);
	//GSetConsoleAttribute(128);
	//GSetConsoleAttribute(204);
	for (int i = x; i <= x+10; i += 2)
	{
		for (int j =y-4; j <= y; j++)
		{
			SetConsolePosition(i, j);
			cout << "  ";
		}
	}
}

void Jiguang4::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = x;
	MaxR_edge = x + 10;
	MaxU_edge = y - 4;
	MaxD_edge = y;
}

Jiguang4::~Jiguang4()
{
}

Jiguang3::Jiguang3()
{
}

void Jiguang3::InitialJiguang()
{
}

void Jiguang3::PaintJiGuang(int x, int y, Man&man_in)
{
	SetEdge(x, y);
	for (int i = 0; i < 5; i++)
	{
		SetConsolePosition(x+i*2, y);
		cout << "▲";
	}
}

void Jiguang3::WrapJigung(int x, int y)
{
	SetEdge(x, y);
	for (int i = 0; i < 5; i++)
	{
		SetConsolePosition(x + i * 2, y);
		cout << "  ";
	}
}

void Jiguang3::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = x;
	MaxR_edge = x+10;
	MaxU_edge = y -2;
	MaxD_edge = y;
}

Jiguang3::~Jiguang3()
{
}



Jiguang2::Jiguang2()
{
}
void Jiguang2::InitialJiguang()
{
}
//基本框架
void Jiguang2::PaintJiGuang(int x, int y,Man&man_in)
{
	SetEdge(x, y);
	SetConsolePosition(x,y);
	cout << "┍";
	for (int i = 1; i <= 4; i++)
	{
		SetConsolePosition(x+i*2,y);
		cout << "─";
	}
	SetConsolePosition(x+8,y);
	cout << "┒";
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(x,y+1+i);
		cout << "│";
		SetConsolePosition(x+8,y + 1+i);
		cout << "│";
	}
	SetConsolePosition(x,y+4);
	cout << "┗";
	for (int i = 1; i <= 4; i++)
	{
		SetConsolePosition(x + i * 2,y+4);
		cout << "─";
	}
	SetConsolePosition(x+8,y+4);
	cout << "┛";
}

void Jiguang2::WrapJigung(int x, int y)
{
	SetEdge(x, y);
	SetConsolePosition(x, y);
	cout << "  ";
	for (int i = 1; i <= 4; i++)
	{
		SetConsolePosition(x + i * 2, y);
		cout << "  ";
	}
	SetConsolePosition(x + 8, y);
	cout << "  ";
	for (int i = 0; i < 3; i++)
	{
		SetConsolePosition(x, y + 1 + i);
		cout << "  ";
		SetConsolePosition(x + 8, y + 1 + i);
		cout << "  ";
	}
	SetConsolePosition(x, y + 4);
	cout << "  ";
	for (int i = 1; i <= 4; i++)
	{
		SetConsolePosition(x + i * 2, y + 4);
		cout << "  ";
	}
	SetConsolePosition(x + 8, y + 4);
	cout << "  ";
}

void Jiguang2::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge=Base_x;
	MaxR_edge=Base_x+8;
	MaxU_edge=Base_y;
	MaxD_edge=Base_y+4;
}

Jiguang2::~Jiguang2()
{
}

Jiguang7::Jiguang7()
{
	state = 0;
}

void Jiguang7::InitialJiguang()
{
	state = 0;
}

void Jiguang7::setstate(int in)
{
	state = in;
}

int Jiguang7::GetState()
{
	return state;
}

void Jiguang7::PaintJiGuang(int x, int y, Man &man_in)
{

	SetEdge(x, y);
	if (state == 0)
	{
		GSetConsoleAttribute(143);
		SetConsolePosition(x, y);
		cout << "█";
		SetConsolePosition(x + 2, y);
		cout << "█";
		SetConsolePosition(x + 2, y - 1);
		cout << " ";
		GSetConsoleAttribute(128);
		SetConsolePosition(x + 1, y - 1);
		cout << "▎";
		
	}
	else if (state == 1)
	{
		GSetConsoleAttribute(143);
		SetConsolePosition(x, y);
		cout << "█";
		SetConsolePosition(x + 2, y);
		cout << "█";
		SetConsolePosition(x + 1, y - 1);
		cout << " ";
		GSetConsoleAttribute(128);
		SetConsolePosition(x + 3, y - 1);
		cout << "▎";
	}
	GSetConsoleAttribute(128);
}

void Jiguang7::WrapJigung(int x, int y)
{
	SetEdge(x, y);
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "  ";
	SetConsolePosition(x + 2, y);
	cout << "  ";
	SetConsolePosition(x + 1, y - 1);
	cout << "  ";
	GSetConsoleAttribute(128);
	SetConsolePosition(x + 3, y - 1);
	cout << "  ";
}

bool Jiguang7::Isman_in(Man &man_in)
{
	int t = 0;
	for (int i = MaxL_edge; i <= MaxR_edge; i++)
	{
		if (i >= man_in.GetL_edge() && i <= man_in.GetR_edge())
		{
			t++;
			break;
		}
	}
	for (int i = MaxU_edge; i <= MaxD_edge; i++)
	{
		if (i >= man_in.GetU_edge() && i <= man_in.GetD_edge())
		{
			t++;
			break;
		}
	}
	if (t == 2)return 1;
	return 0;
}

void Jiguang7::SetEdge(int x, int y)
{
	Base_x = x;
	Base_y = y;
	MaxL_edge = Base_x;
	MaxR_edge = Base_x + 4;
	MaxU_edge = Base_y-2;
	MaxD_edge = Base_y ;
}

Jiguang7::~Jiguang7()
{
}

