#include "SetColor.h"
#include<Windows.h>
void SetAllBackgroundcolor()
{
	system("color 70");
}
