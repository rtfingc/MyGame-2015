#include "Paint.h"
#include"GameLevel.h"
#include<Windows.h>
#include<iostream>
#include<string>
using namespace std;
HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
COORD coord = { 0,0 };
CONSOLE_CURSOR_INFO info;
/*�������λ��*/
void SetCoord(int x, int y)
{

	coord.X = x;
	coord.Y = y;
}
/*������ƶ�����������*/
void SetConsolePosition(int x, int y)
{
	SetCoord(x, y);
	SetConsoleCursorPosition(hOutput, coord);
}
/*������ʼ�˵�����*/
void PaintStartMenue()
{
	//GetConsoleCursorInfo(hOutput, &info);
	SetConsolePosition(40+90, 12-8);
	cout <<"�µ���Ϸ";
	SetConsolePosition(40+90, 14-8);
	cout << "��ȡ�浵";
		SetConsolePosition(42+90, 16-8);
		cout << "����";
		SetConsolePosition(42+90, 18-8);
		cout << "�˳�";
}
/*�뿪��ʼ�˵�����*/
void WrapStartMenue()
{
	GetConsoleCursorInfo(hOutput, &info);
	SetConsolePosition(40-3+90, 12-8);
	cout << "             ";
	SetConsolePosition(40-3+90, 14-8);
	cout << "             ";
	SetConsolePosition(42-3+90, 16-8);
	cout << "             ";
	SetConsolePosition(42-3+90, 18-8);
	cout << "            ";
}
/*�ı����̨���ڵĴ�С*/
void ChangeTheWindow()
{
	HWND hwnd = GetForegroundWindow();
	int x = GetSystemMetrics(SM_CXSCREEN) ;
	int y = GetSystemMetrics(SM_CYSCREEN);
	SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 1536-215, 864-70, NULL);
	MoveWindow(hwnd, 0, 0, 1536-215, 864-70, 1);
	/*HWND hwnd = GetForegroundWindow();
	int x = GetSystemMetrics(SM_CXSCREEN);
	int y = GetSystemMetrics(SM_CYSCREEN);
	SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, x , y, NULL); 
	MoveWindow(hwnd, 0, 0, x, y, 1);*/
}


/*�������δ����*/
void Paintman(int x, int y)
{
	SetConsolePosition(35, 35);
	cout << "ggggg";
	GReadAndWrite();
	SetConsolePosition(x, y);
cout << "#";
x += 2;
SetConsolePosition(x, y);

cout << "#";
x -= 4;
SetConsolePosition(x, y);
cout << "#";
x += 2;
y--;
SetConsolePosition(x, y);
cout << "#";
y += 2;
SetConsolePosition(x, y);
cout << "#";

}
/*��ȥָ��λ�õ�����*/
void Wrapman(int x, int y)
{
	SetConsolePosition(x, y);
	cout << " ";
	x += 2;
	SetConsolePosition(x, y);

	cout << " ";
	x -= 4;
	SetConsolePosition(x, y);
	cout << " ";
	x += 2;
	y--;
	SetConsolePosition(x, y);
	cout << " ";
	y += 2;
	SetConsolePosition(x, y);
	cout << " ";
}
/*���λ�õĴ�ӡ*/
void PaintChose(int CurrentID)
{
	//GSetConsoleAttribute(128);
	SetConsolePosition(40-2+90, 12+CurrentID*2-8);
	cout << ">";
	SetConsolePosition(40+8+90, 12 + CurrentID * 2-8);
	cout <<"<";
}

/*ȥ��ָ��λ�õ�����ѡ����*/
void WrapPaintChose(int CurrentID)
{
	SetConsolePosition(40 - 3+90, 12 + CurrentID * 2-8);
	cout << "   ";
	SetConsolePosition(40 + 8+90, 12 + CurrentID * 2-8);
	cout << " ";
}

void PiantReadRecordMenue()
{
	SetConsolePosition(40+90, 12-8);
	cout << "�浵 1";
	SetConsolePosition(40+90, 14-8);
	cout << "�浵 2";
	SetConsolePosition(40+90, 16-8);
	cout << "�浵 3";
	SetConsolePosition(40+90, 18-8);
	cout << "�浵 4";
	SetConsolePosition(40+90, 20-8);
	cout << "�浵 5";
	SetConsolePosition(40+90, 22-8);
	cout << "�浵 6";
}
void WrapReadRecordMenue()
{
	SetConsolePosition(40+90, 12-8);
	cout << "       ";
	SetConsolePosition(40, 14-8);
	cout << "       ";
	SetConsolePosition(40+90, 16-8);
	cout << "       ";
	SetConsolePosition(40+90, 18-8);
	cout << "       ";
	SetConsolePosition(40+90, 20-8);
	cout << "       ";
	SetConsolePosition(40+90, 22-8);
	cout << "        ";
}
void PaintStopMenue()
{
	SetConsolePosition(40+90, 12-8);
	cout << "������Ϸ";
	SetConsolePosition(40+90, 14-8);
	cout << "����浵";
	SetConsolePosition(40+90, 16-8);
	cout << "��ȡ�浵";
	
	SetConsolePosition(41+90, 18-8);
	cout << "���˵�";
	SetConsolePosition(42+90, 20-8);
	cout << "����";
}
void WrapStopMenue()
{
	SetConsolePosition(41+90, 12-8);
	cout << "       ";
	SetConsolePosition(40+90, 14-8);
	cout << "           ";
	SetConsolePosition(40+90, 16-8);
	cout << "            ";

	SetConsolePosition(40+90, 18-8);
	cout << "         ";
	SetConsolePosition(42+90, 20-8);
	cout << "     ";
}

void TestPaintThedeng(int x, int y)
{
	GSetConsoleAttribute(128);
	SetConsolePosition(x, y);
	cout << "#";
}

void PaintTalkBackground()
{
	GSetConsoleAttribute(0);
	for (int i = 0; i < 160; i++)
	{
		for (int j = 30; j < 40; j++)
		{
			SetConsolePosition(i, j);
			cout << ' ';
		}
	}
}

/*��������*/
void PaintStart()
{
	int x, y;
	//GSetConsoleAttribute(128);
	//RenewTheScreen();
	//GReadAndWrite();
	//GSetConsoleAttribute(128);//Sleep(100);
	x = 3; y = 17 - 6;
	int speed = 20;
	for (int i = x; i <= 8; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

		//GSetConsoleAttribute(0);Sleep(100);
	}y++; //x++;
	//Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 30; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite(); //x += 2;
	for (int i = x; i <= 26; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y -= 2; x = 19; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 30; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 26; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 31; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	///////////////////////
	x = 14; y = 12 - 6;

	//////////////////////////////////
	for (int i = x; i < 22; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 22; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 21; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 1; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 21; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 1; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 21; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 21; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 20; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 20; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 19; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 19; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 18; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 17; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 29; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 1; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 27; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 16; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y -= 3; x = 22; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 32; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 29; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 40; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 34; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 45; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; //Sleep(speed); GReadAndWrite();
	//////////////////////////////////////////////
	x = 23; y = 20 - 6;
	for (int i = x; i <= 27; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 28; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 28; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 10; t++)
	{
		for (int i = x; i <= 27; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}
	x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 26; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 26; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++;
	x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 25; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 25; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 3; t++)
	{
		for (int i = x; i <= 24; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 3; t++)
	{
		x -= 2;
		for (int i = x; i <= 24 - t * 2 - 2; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	/////////////////////////////////////////////
	x = 4;
	y = 31 - 6;

	for (int i = x; i <= 20; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 16; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++;
	x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 12; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x == 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 11; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y -= 4; x = 12; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 27; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 18; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 27; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 23; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 32; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 34; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	/////////////////////////////////////
	x = 45; y = 11 - 6;
	for (int i = x; i <= 49; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";
		//Sleep(speed); GReadAndWrite();
	}y++;
	for (int i = x; i <= 51; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 49; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 3; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 48; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 1; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 47; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 46; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 46; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 5; t++)
	{
		x--;;
		for (int i = x; i <= 44 - t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			//Sleep(speed); GReadAndWrite();
		}y++;
	}
	for (int t = 0; t < 5; t++)
	{
		x--;;
		for (int i = x; i <= 38 - t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	//////////////////////////////////////////////////////////
	x = 47; y = 15 - 6;
	for (int t = 0; t < 5; t++)
	{
		x++;
		for (int i = x; i <= 50 + t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 3; t++)
	{
		x++;
		for (int i = x; i <= 56 + t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 2; t++)
	{
		x++;;
		for (int i = x; i <= 61 + t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 2; t++)
	{
		x++;;
		for (int i = x; i <= 64 + t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}
	x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 69; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2;
	for (int i = x; i <= 72; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2;
	for (int i = x; i <= 72; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 74; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	x += 2;
	for (int i = x; i <= 75; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	/////////////////////////////////////////////////////
	x = 54; y = 25 - 6;
	for (int i = x; i <= 55; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 55; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 54; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x -= 3; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 52; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 37; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 50; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 36; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 47; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 36; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 44; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();

	/////////////////////////////////////////////
	x = 46; y = 20 - 6;
	for (int t = 0; t < 4; t++)
	{
		x--;
		for (int i = x; i <= 48 - t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 3; t++)
	{
		x--;
		for (int i = x; i <= 44 - t; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}x = 38; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 42; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 42; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y += 3; x = 35; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 39; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 38; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 37; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 39; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 42; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 43; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 48; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 57; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 55; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 51; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y -= 3; x = 51; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 59; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 56; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 62; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 60; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 64; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 63; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 65; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; SetConsolePosition(65, y);
	cout << "#"; //Sleep(speed); GReadAndWrite();
	//////////////////////////////
	x = 68;
	y = 19 - 6;
	for (int i = x; i <= 74; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 78; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; for (int i = x; i <= 78; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 78; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 92; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 86; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();

	for (int t = 0; t < 3; t++)
	{
		for (int i = x; i <= 80; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}//Sleep(speed); GReadAndWrite();
	x += 2;
	for (int t = 0; t < 9; t++)
	{
		for (int i = x; i <= 78; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
	}
	x += 2; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 80; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++;
	x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 81; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 80; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 81; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	///////////////////////////
	x = 86; y = 22 - 6;
	for (int i = x; i <= 99; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 93; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 108; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 99; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 108; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	////////////////////////////
	x = 106; y = 22 - 6;
	for (int i = x; i <= 110; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int t = 0; t < 4; t++)
	{
		x++;
		for (int i = x; i <= 112; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; //Sleep(speed); GReadAndWrite();
	}
	for (int t = 0; t < 2; t++)
	{

		for (int i = x; i <= 114; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; //Sleep(speed); GReadAndWrite();
	}
	x += 3;
	for (int t = 0; t < 5; t++)
	{
		x--;
		for (int i = x; i <= 112; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; //Sleep(speed); GReadAndWrite();
	}
	for (int t = 0; t < 3; t++)
	{
		x--;
		for (int i = x; i <= 107; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; //Sleep(speed); GReadAndWrite();
	}
	////////////////////////////////////////////
	x = 77; y = 35 - 6;
	for (int i = x; i <= 100; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 78; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 106; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 95; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 112; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";
		//Sleep(speed); GReadAndWrite();
	}y++; x = 102;
	for (int i = x; i <= 113; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";
		//Sleep(speed); GReadAndWrite();
	}y++;
	/////////////////////////
	x = 85; y = 27 - 6;
	for (int i = x; i <= 92; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";
		//Sleep(speed); GReadAndWrite();
	}y++; x++;
	for (int i = x; i <= 89; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";
		//Sleep(speed); GReadAndWrite();
	}y++; x++;
	for (int i = x; i <= 89; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 89; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 94; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	/////////////////////////////////
	x = 91;
	y = 26 - 6;
	for (int i = x; i <= 96; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y--; x = 96; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 102; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 100; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 101; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 100; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 100; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x--; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 100; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; x = 94; //Sleep(speed); GReadAndWrite();
	for (int i = x; i <= 100; i++)
	{
		SetConsolePosition(i, y);
		cout << "#";

	}y++; //Sleep(speed); GReadAndWrite();
}
void PaintNewgameKuang()
{
	GSetConsoleAttribute(0);
	RenewTheScreen();
	GSetConsoleAttribute(128);
	for (int i = 20; i < 130; i++)
	{
		for (int j = 12; j < 32; j++)
		{
			SetConsolePosition(i, j);
			cout << " ";
		}
	}
}
void paintStartFilm()
{
		int x, y;
		//GSetConsoleAttribute(128);
		//RenewTheScreen();
		//GReadAndWrite();
		//GSetConsoleAttribute(128);//Sleep(100);
		x = 3; y = 17 - 6;
		int speed = 20;
		for (int i = x; i <= 8; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

			//GSetConsoleAttribute(0);Sleep(100);
		}y++; //x++;
		Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 30; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite(); //x += 2;
		for (int i = x; i <= 26; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y -= 2; x = 19; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 30; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 26; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 31; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		///////////////////////
		x = 14; y = 12 - 6;

		//////////////////////////////////
		for (int i = x; i < 22; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 22; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 21; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 1; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 21; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 1; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 21; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 21; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 20; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 20; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 19; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 19; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 18; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 17; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 29; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 1; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 27; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 16; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y -= 3; x = 22; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 32; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 29; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 40; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 34; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 45; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; Sleep(speed); GReadAndWrite();
		//////////////////////////////////////////////
		x = 23; y = 20 - 6;
		for (int i = x; i <= 27; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 28; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 28; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 10; t++)
		{
			for (int i = x; i <= 27; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}
		x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 26; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 26; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
		x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 25; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 25; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 3; t++)
		{
			for (int i = x; i <= 24; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 3; t++)
		{
			x -= 2;
			for (int i = x; i <= 24 - t * 2 - 2; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		/////////////////////////////////////////////
		x = 4;
		y = 31 - 6;

		for (int i = x; i <= 20; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 16; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
		x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 12; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x == 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 11; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y -= 4; x = 12; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 27; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 18; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 27; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 23; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 32; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 34; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		/////////////////////////////////////
		x = 45; y = 11 - 6;
		for (int i = x; i <= 49; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			Sleep(speed); GReadAndWrite();
		}y++;
		for (int i = x; i <= 51; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 49; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 3; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 48; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 1; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 47; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 46; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 46; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 5; t++)
		{
			x--;;
			for (int i = x; i <= 44 - t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";
				Sleep(speed); GReadAndWrite();
			}y++;
		}
		for (int t = 0; t < 5; t++)
		{
			x--;;
			for (int i = x; i <= 38 - t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		//////////////////////////////////////////////////////////
		x = 47; y = 15 - 6;
		for (int t = 0; t < 5; t++)
		{
			x++;
			for (int i = x; i <= 50 + t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 3; t++)
		{
			x++;
			for (int i = x; i <= 56 + t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 2; t++)
		{
			x++;;
			for (int i = x; i <= 61 + t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 2; t++)
		{
			x++;;
			for (int i = x; i <= 64 + t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}
		x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 69; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2;
		for (int i = x; i <= 72; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2;
		for (int i = x; i <= 72; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 74; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		x += 2;
		for (int i = x; i <= 75; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		/////////////////////////////////////////////////////
		x = 54; y = 25 - 6;
		for (int i = x; i <= 55; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 55; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 54; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x -= 3; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 52; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 37; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 50; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 36; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 47; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 36; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 44; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();

		/////////////////////////////////////////////
		x = 46; y = 20 - 6;
		for (int t = 0; t < 4; t++)
		{
			x--;
			for (int i = x; i <= 48 - t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 3; t++)
		{
			x--;
			for (int i = x; i <= 44 - t; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}x = 38; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 42; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 42; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y += 3; x = 35; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 39; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 38; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 37; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 39; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 42; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 43; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 48; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 57; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 55; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 51; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y -= 3; x = 51; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 59; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 56; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 62; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 60; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 64; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 63; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 65; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; SetConsolePosition(65, y);
		cout << "#"; Sleep(speed); GReadAndWrite();
		//////////////////////////////
		x = 68;
		y = 19 - 6;
		for (int i = x; i <= 74; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 78; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; for (int i = x; i <= 78; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 78; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 92; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 86; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();

		for (int t = 0; t < 3; t++)
		{
			for (int i = x; i <= 80; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}Sleep(speed); GReadAndWrite();
		x += 2;
		for (int t = 0; t < 9; t++)
		{
			for (int i = x; i <= 78; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++;
		}
		x += 2; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 80; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++;
		x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 81; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 80; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 81; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		///////////////////////////
		x = 86; y = 22 - 6;
		for (int i = x; i <= 99; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 93; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 108; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 99; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 108; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		////////////////////////////
		x = 106; y = 22 - 6;
		for (int i = x; i <= 110; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int t = 0; t < 4; t++)
		{
			x++;
			for (int i = x; i <= 112; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++; Sleep(speed); GReadAndWrite();
		}
		for (int t = 0; t < 2; t++)
		{

			for (int i = x; i <= 114; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++; x--; Sleep(speed); GReadAndWrite();
		}
		x += 3;
		for (int t = 0; t < 5; t++)
		{
			x--;
			for (int i = x; i <= 112; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++; Sleep(speed); GReadAndWrite();
		}
		for (int t = 0; t < 3; t++)
		{
			x--;
			for (int i = x; i <= 107; i++)
			{
				SetConsolePosition(i, y);
				cout << "#";

			}y++; Sleep(speed); GReadAndWrite();
		}
		////////////////////////////////////////////
		x = 77; y = 35 - 6;
		for (int i = x; i <= 100; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 78; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 106; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 95; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 112; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			Sleep(speed); GReadAndWrite();
		}y++; x = 102;
		for (int i = x; i <= 113; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			Sleep(speed); GReadAndWrite();
		}y++;
		/////////////////////////
		x = 85; y = 27 - 6;
		for (int i = x; i <= 92; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			Sleep(speed); GReadAndWrite();
		}y++; x++;
		for (int i = x; i <= 89; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";
			Sleep(speed); GReadAndWrite();
		}y++; x++;
		for (int i = x; i <= 89; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 89; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 94; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		/////////////////////////////////
		x = 91;
		y = 26 - 6;
		for (int i = x; i <= 96; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y--; x = 96; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 102; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 100; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 101; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 100; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 100; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x--; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 100; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; x = 94; Sleep(speed); GReadAndWrite();
		for (int i = x; i <= 100; i++)
		{
			SetConsolePosition(i, y);
			cout << "#";

		}y++; Sleep(speed); GReadAndWrite();
		////////////////////////
		//GReadAndWrite();

}
//�ײ�Ϊ32���ϱ�Ϊ12�����Ϊ20���ұ�Ϊ130
void paintStartFilm1()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();
	GSetConsoleAttribute(0);
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50, 32 - i);
		cout << "#";
		SetConsolePosition(51, 32 - i);
		cout << "#";
	}
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50 - 4 + i, 32 - 9);
		cout << "#";
	}
	SetConsolePosition(50, 32 - 11);
	GSetConsoleAttribute(142);
	cout << "��";
	////
	GSetConsoleAttribute(128);
	SetConsolePosition(56, 32 - 12);
	cout << "��";
	SetConsolePosition(56, 32 - 11);
	cout << "��";
	SetConsolePosition(57, 32 - 10);
	cout << "\\";
	SetConsolePosition(55, 32 - 12);
	cout << "\\";
	SetConsolePosition(54, 32 - 12);
	cout << "\\";
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "��˵ ,��ؼ���ֻض���������һ���ֻ�ʯ���� , ��һ�� ,��������������ֻ�ʯ ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35+i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
}

void paintStartFilm2()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();
	GSetConsoleAttribute(0);
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50, 32 - i);
		cout << "#";
		SetConsolePosition(51, 32 - i);
		cout << "#";
	}
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50 - 4 + i, 32 - 9);
		cout << "#";
	}
	SetConsolePosition(50, 32 - 11);
	GSetConsoleAttribute(142);
	cout << "��";
	////
	GSetConsoleAttribute(128);
	SetConsolePosition(56, 32 - 12);
	cout << "��";
	SetConsolePosition(56, 32 - 11);
	cout << "��";
	SetConsolePosition(56, 32 - 10);
	cout << "/";
	SetConsolePosition(58, 32 - 11);
	cout << "\\";
	SetConsolePosition(54, 32 - 11);
	cout << "--";
	SetConsolePosition(50, 32 - 12);
	cout << "~";
	SetConsolePosition(50 - 2, 32 - 10);
	cout << "~";
	SetConsolePosition(120, 14);
	cout << "��";
	SetConsolePosition(120 - 2, 14);
	cout << "��";
	SetConsolePosition(120, 16);
	cout << "//";
	SetConsolePosition(110, 15);
	cout << "��";
	SetConsolePosition(111, 16);
	cout << "��";
	SetConsolePosition(112, 17);
	cout << "��";
	GSetConsoleAttribute(15);
	string m = "ͻȻ ,Զ������һ����ֵ����� ����Ӧ����ȥ ��Ȼ���ֻ�ʯ ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
}

void paintStartFilm3()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();
	GSetConsoleAttribute(0);
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50 + 40, 32 - i);
		cout << "#";
		SetConsolePosition(51 + 40, 32 - i);
		cout << "#";
	}
	for (int i = 0; i < 10; i++)
	{
		SetConsolePosition(50 + 40 - 4 + i, 32 - 9);
		cout << "#";
	}
	for (int i = 0; i < 70; i++)
	{
		SetConsolePosition(60 + i, 31);
		cout << "#";
	}
	SetConsolePosition(50, 32 - 4);
	GSetConsoleAttribute(142);
	cout << "��";
	GReadAndWrite();
	GSetConsoleAttribute(15);
	string m = "�ֻ�ʯ�������� ���������½� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
}

void paintStartFilm4()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();

	SetConsolePosition(80, 32 - 17);
	GSetConsoleAttribute(142);
	cout << "��";
	GSetConsoleAttribute(0);
	for (int i = 0; i < 60; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			SetConsolePosition(20 + i, 32 - j);
			cout << "#";
		}
	}
	for (int i = 0; i < 50; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			SetConsolePosition(20 + i, 28 - j);
			cout << "#";
		}
	}
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			SetConsolePosition(20 + i, 24 - j);
			cout << "#";
		}
	}
	for (int i = 0; i < 35; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			SetConsolePosition(20 + i, 20 - j);
			cout << "#";
		}
	}
	SetConsolePosition(35, 24);
	GSetConsoleAttribute(12);
	cout << "��";
	SetConsolePosition(40, 28);
	cout << "��";
	GSetConsoleAttribute(15);
	SetConsolePosition(48, 24);
	cout << "��";
	GReadAndWrite();
	string m ="��ǧ��ǰ ,����������72ħ����һ��ħͷ��ӡ�ڵ��ϵ�ĳ�� ������һ�� �����ϵ�����һ��ʯͷ ......";
	string n = "�����ֻ�ʯ��������ͼ���Ʒ�ӡ �������ֻ�ʯ���������ֻ� ......";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 9);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	for (int i = 0; i < n.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (n[i] == ' ')continue;
		cout << n[i];
		GReadAndWrite();
		Sleep(40);
	}
}

void paintStartFilm5()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();
	GSetConsoleAttribute(0);
	for (int i = 0; i < 70; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			SetConsolePosition(60 + i, 32 - j);
			cout << "#";
		}
	}
	int x = 70; int y = 26 - 3;
	SetConsolePosition(x - 2, y);
	cout << "��";

	SetConsolePosition(x - 4, y);
	cout << "��";
	GSetConsoleAttribute(128);

	SetConsolePosition(x, y - 1);
	cout << "�v";
	SetConsolePosition(x, y);
	cout << "�v";
	SetConsolePosition(x, y + 1);
	cout << "�v";
	SetConsolePosition(x + 2, y);
	cout << "�v";
	SetConsolePosition(x + 2, y + 1);
	cout << "�v";
	SetConsolePosition(x + 4, y + 1);
	cout << "�v";
	SetConsolePosition(x - 4, y - 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 2);
	cout << "��";
	x = 75; y = 26 - 6;
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x, y + 1);
	cout << "��";
	//SetConsolePosition(19, 21);
	//cout << "|";
	//SetConsolePosition(22, 21);
	//cout << "|";
	SetConsolePosition(x - 1, y + 2);
	cout << " ";
	SetConsolePosition(x, y + 2);
	cout << "|";
	SetConsolePosition(x + 1, y + 2);
	cout << " ";

	GSetConsoleAttribute(15);
	string m = "�Ͻ������ ���������·�ӡħͷ �����û��ֻ�ʯ .....";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
}

void paintStartFilm6()
{
	GSetConsoleAttribute(128);
	PaintNewgameKuang();
	GSetConsoleAttribute(0);
	for (int i = 0; i < 70; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			SetConsolePosition(60 + i, 32 - j);
			cout << "#";
		}
	}
	int x = 70; int y = 26 - 3;
	SetConsolePosition(x - 2, y);
	cout << "��";

	SetConsolePosition(x - 4, y);
	cout << "��";
	GSetConsoleAttribute(128);

	SetConsolePosition(x, y - 1);
	cout << "�v";
	SetConsolePosition(x, y);
	cout << "�v";
	SetConsolePosition(x, y + 1);
	cout << "�v";
	SetConsolePosition(x + 2, y);
	cout << "�v";
	SetConsolePosition(x + 2, y + 1);
	cout << "�v";
	SetConsolePosition(x + 4, y + 1);
	cout << "�v";
	SetConsolePosition(x - 4, y - 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 1);
	cout << "��";
	SetConsolePosition(x - 4, y + 2);
	cout << "��";
	SetConsolePosition(x - 2, y - 1);
	cout << "�u";
	//
	x = 40; y = 31 - 6;
	SetConsolePosition(x, y);
	cout << "��";
	SetConsolePosition(x + 2, y);
	cout << "�{";
	SetConsolePosition(x + 4, y);
	cout << "--";
	SetConsolePosition(x + 1, y + 1);
	cout << "//";
	GReadAndWrite();

	GSetConsoleAttribute(15);
	string m = "���� ����ķ�ӡ֮·��ʼ�� .....";
	for (int i = 0; i < m.size(); i++)
	{
		SetConsolePosition(35 + i, 10);
		if (m[i] == ' ')continue;
		cout << m[i];
		GReadAndWrite();
		Sleep(40);
	}
	Sleep(500);
}

void paintEndFilm()
{
}




