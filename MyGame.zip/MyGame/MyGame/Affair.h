#pragma once
#ifndef AFFAIR_H
#define AFFAIR_H

#include<Windows.h>
#include"GameLevel.h"
#include<iostream>
using namespace std;
void AffairChose(int);

void Affair1();
void Affair2();
void Affair3();
void Affair4();
void Affair5();
void Affair6();
void Affair7();
void Affair8();
void Affair9();
void Affair10();
void Affair11();
void Affair12();
void Affair13();
#endif;
